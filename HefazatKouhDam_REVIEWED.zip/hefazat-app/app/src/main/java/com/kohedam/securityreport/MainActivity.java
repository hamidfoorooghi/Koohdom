package com.kohedam.securityreport;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextDirectionHeuristics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root;
    ArrayList<EditText> currentFormFields = new ArrayList<>();
    String user = "", role = "";
    final int GOLD = Color.rgb(201, 154, 36);
    final int DARK = Color.rgb(32, 33, 36);
    int pad = 16;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        login();
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(DARK);
        t.setPadding(pad, pad, pad, pad);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    EditText ed(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setPadding(pad, 10, pad, 10);
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        return e;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 12, 12, 20);
        root.setBackgroundColor(Color.rgb(247, 245, 240));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);
        TextView h = tv(title, 22);
        h.setTextColor(DARK);
        h.setGravity(Gravity.CENTER);
        h.setTypeface(null, 1);
        root.addView(h);
    }

    void login() {
        base("گزارش‌های حفاظت فیزیکی\nمجتمع طلای کوه‌دم – ایمپاسکو");
        root.addView(tv("ورود کاربران", 18));
        EditText u = ed("نام کاربری");
        EditText p = ed("رمز عبور");
        p.setInputType(129);
        root.addView(u);
        root.addView(p);
        Button b = btn("ورود");
        root.addView(b);
        root.addView(tv("کاربران نمونه: admin / 1234   |   shift / 1234   |   staff / 1234", 12));
        b.setOnClickListener(v -> {
            Cursor c = db.login(u.getText().toString().trim(), p.getText().toString());
            if (c.moveToFirst()) {
                user = c.getString(0);
                role = c.getString(1);
                c.close();
                home();
            } else {
                Toast.makeText(this, "نام کاربری یا رمز عبور اشتباه است", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void home() {
        base("داشبورد حفاظت فیزیکی");
        root.addView(tv("کاربر: " + user + "   |   نقش: " + role, 15));
        Button n = btn("＋ ثبت گزارش روزانه جدید");
        root.addView(n);
        n.setOnClickListener(v -> form(null));
        Button l = btn("📋 گزارش‌های ثبت‌شده");
        root.addView(l);
        l.setOnClickListener(v -> reports());
        Button m = btn("📊 کارکرد ماهانه");
        root.addView(m);
        m.setOnClickListener(v -> monthly());
        if ("مدیر".equals(role)) {
            Button us = btn("👥 مدیریت کاربران");
            root.addView(us);
            us.setOnClickListener(v -> users());
        }
        Button out = btn("خروج");
        root.addView(out);
        out.setOnClickListener(v -> login());
    }

    EditText add(String label, String value) {
        root.addView(tv(label, 14));
        EditText e = ed(label);
        if (value != null) e.setText(value);
        root.addView(e);
        currentFormFields.add(e);
        return e;
    }

    TextView section(String s) {
        TextView t = tv("▰ " + s, 18);
        t.setTextColor(GOLD);
        t.setTypeface(null, 1);
        root.addView(t);
        return t;
    }

    void form(Long id) {
        currentFormFields = new ArrayList<>();
        base(id == null ? "ثبت گزارش روزانه" : "ویرایش گزارش روزانه");

        final EditText date = add("تاریخ (شمسی)", Jalali.today());
        EditText start = add("ساعت شروع شیفت", "07:00");
        EditText end = add("ساعت پایان شیفت", "07:00");
        EditText chief = add("نام سرشیفت", user);
        EditText shift = add("شماره شیفت", "");

        section("۱. وضعیت پرسنل");
        EditText staff = add("نام و وضعیت ۳ نفر پرسنل", "");
        EditText replace = add("جایگزین در صورت غیبت", "");

        section("۲. ورود و خروج خودروها");
        final ArrayList<EditText[]> cars = new ArrayList<>();
        final LinearLayout carContainer = new LinearLayout(this);
        carContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(carContainer);

        Runnable addCar = () -> {
            int n = cars.size() + 1;
            TextView z = tv("خودرو " + n, 15);
            carContainer.addView(z);
            EditText plate = ed("شماره شهربانی / پلاک");
            EditText passengers = ed("نام راننده و سرنشینان");
            EditText inT = ed("ساعت ورود (مثلاً 08:15)");
            EditText outT = ed("ساعت خروج (مثلاً 09:40)");
            carContainer.addView(plate);
            carContainer.addView(passengers);
            carContainer.addView(inT);
            carContainer.addView(outT);
            cars.add(new EditText[]{plate, passengers, inT, outT});
        };

        Button addCarButton = btn("＋ افزودن خودرو");
        root.addView(addCarButton);
        addCarButton.setOnClickListener(v -> addCar.run());

        if (id != null) {
            Cursor old = db.db.rawQuery("SELECT cars FROM reports WHERE id=?", new String[]{String.valueOf(id)});
            if (old.moveToFirst()) {
                String raw = old.getString(0);
                if (raw != null && !raw.trim().isEmpty()) {
                    try {
                        JSONArray arr = new JSONArray(raw);
                        for (int i = 0; i < arr.length(); i++) {
                            addCar.run();
                            JSONObject o = arr.getJSONObject(i);
                            EditText[] a = cars.get(cars.size() - 1);
                            a[0].setText(o.optString("plate", ""));
                            a[1].setText(o.optString("passengers", ""));
                            a[2].setText(o.optString("in", ""));
                            a[3].setText(o.optString("out", ""));
                        }
                    } catch (Exception legacy) {
                        String[] rows = raw.split(";");
                        for (String row : rows) {
                            if (row.trim().isEmpty()) continue;
                            String[] vals = row.split("\\|", -1);
                            addCar.run();
                            EditText[] a = cars.get(cars.size() - 1);
                            for (int j = 0; j < Math.min(4, vals.length); j++) a[j].setText(vals[j]);
                        }
                    }
                }
            }
            old.close();
        }
        if (cars.isEmpty()) addCar.run();

        section("۳. اتاق طلا");
        EditText goldOpen = add("ساعت بازگشایی", "");
        EditText goldClose = add("ساعت بسته شدن", "");
        EditText goldReason = add("علت / توضیحات", "");

        section("۴. ورود مواد آتشباری");
        EditText matCount = add("تعداد خودرو", "");
        EditText matPlate = add("پلاک خودروها", "");
        EditText bill = add("شماره حواله / قبض", "");

        section("۵. سوخت و کیلومتر");
        EditText carKm = add("کیلومتر خودرو", "");
        EditText carFuel = add("سوخت خودرو (لیتر)", "");
        EditText motoKm = add("کیلومتر موتور", "");
        EditText motoFuel = add("سوخت موتور (لیتر)", "");
        EditText fuelStock = add("موجودی سوخت انبار", "");

        section("۶. کلیدها");
        EditText goldKeys = add("کلیدهای اتاق طلا", "");
        EditText otherKeys = add("سایر کلیدها", "");

        section("۷. بهداشت و سلامت");
        EditText health = add("وضعیت بهداشت پرسنل", "");
        EditText healthDesc = add("توضیحات بهداشتی", "");

        section("۸. نظافت اتاق‌ها");
        EditText clean = add("تمیز تحویل داده شد / تمیز تحویل گرفته شد", "");
        EditText building = add("نیازهای ساختمانی", "");

        section("۹. رویدادهای مهم");
        EditText events = add("شرح کامل رویدادها و گزارش‌های مهم", "");

        section("تحویل شیفت");
        EditText deliver = add("نام و امضای تحویل‌دهنده", "");
        EditText receiver = add("نام و امضای تحویل‌گیرنده", "");

        if (id != null) {
            Cursor existing = db.db.rawQuery(
                    "SELECT date,start,end,chief,shift,staff,replace,gold_open,gold_close,gold_reason," +
                            "mat_count,mat_plate,bill,car_km,car_fuel,moto_km,moto_fuel,fuel_stock," +
                            "gold_keys,other_keys,health,health_desc,clean,building,events,deliver,receiver " +
                            "FROM reports WHERE id=?",
                    new String[]{String.valueOf(id)});
            if (existing.moveToFirst()) {
                for (int i = 0; i < currentFormFields.size() && i < existing.getColumnCount(); i++) {
                    String value = existing.getString(i);
                    currentFormFields.get(i).setText(value == null ? "" : value);
                }
            }
            existing.close();
        }

        Button save = btn("💾 ذخیره گزارش");
        root.addView(save);
        Button cancel = btn("بازگشت");
        root.addView(cancel);
        cancel.setOnClickListener(v -> home());

        save.setOnClickListener(v -> {
            ContentValues cv = new ContentValues();
            cv.put("date", date.getText().toString());
            cv.put("start", start.getText().toString());
            cv.put("end", end.getText().toString());
            cv.put("chief", chief.getText().toString());
            cv.put("shift", shift.getText().toString());
            cv.put("staff", staff.getText().toString());
            cv.put("replace", replace.getText().toString());
            cv.put("gold_open", goldOpen.getText().toString());
            cv.put("gold_close", goldClose.getText().toString());
            cv.put("gold_reason", goldReason.getText().toString());
            cv.put("mat_count", matCount.getText().toString());
            cv.put("mat_plate", matPlate.getText().toString());
            cv.put("bill", bill.getText().toString());
            cv.put("car_km", carKm.getText().toString());
            cv.put("car_fuel", carFuel.getText().toString());
            cv.put("moto_km", motoKm.getText().toString());
            cv.put("moto_fuel", motoFuel.getText().toString());
            cv.put("fuel_stock", fuelStock.getText().toString());
            cv.put("gold_keys", goldKeys.getText().toString());
            cv.put("other_keys", otherKeys.getText().toString());
            cv.put("health", health.getText().toString());
            cv.put("health_desc", healthDesc.getText().toString());
            cv.put("clean", clean.getText().toString());
            cv.put("building", building.getText().toString());
            cv.put("events", events.getText().toString());
            cv.put("deliver", deliver.getText().toString());
            cv.put("receiver", receiver.getText().toString());
            cv.put("created_by", user);

            JSONArray cdata = new JSONArray();
            for (EditText[] a : cars) {
                String plate = a[0].getText().toString().trim();
                String passengers = a[1].getText().toString().trim();
                String cin = a[2].getText().toString().trim();
                String cout = a[3].getText().toString().trim();
                if (plate.isEmpty() && passengers.isEmpty() && cin.isEmpty() && cout.isEmpty()) continue;
                try {
                    JSONObject car = new JSONObject();
                    car.put("plate", plate);
                    car.put("passengers", passengers);
                    car.put("in", cin);
                    car.put("out", cout);
                    cdata.put(car);
                } catch (JSONException ignored) {}
            }
            cv.put("cars", cdata.toString());

            if (id == null) {
                db.db.insert("reports", null, cv);
            } else {
                db.db.update("reports", cv, "id=?", new String[]{"" + id});
            }
            Toast.makeText(this, "گزارش با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show();
            home();
        });
    }

    void reports() {
        base("گزارش‌های ثبت‌شده");
        EditText q = add("جست‌وجو بر اساس تاریخ / سرشیفت / رویداد", "");
        Button search = btn("جست‌وجو");
        root.addView(search);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Runnable load = () -> {
            list.removeAllViews();
            Cursor c = db.db.rawQuery("SELECT id,date,chief,shift FROM reports ORDER BY id DESC", null);
            while (c.moveToNext()) {
                long id = c.getLong(0);
                Button b = btn("تاریخ: " + c.getString(1) + " | سرشیفت: " + c.getString(2) + " | شیفت: " + c.getString(3));
                list.addView(b);
                b.setOnClickListener(v -> detail(id));
            }
            c.close();
        };
        load.run();

        search.setOnClickListener(v -> {
            list.removeAllViews();
            String s = q.getText().toString();
            Cursor c = db.db.rawQuery(
                    "SELECT id,date,chief,shift FROM reports WHERE date LIKE ? OR chief LIKE ? OR events LIKE ? ORDER BY id DESC",
                    new String[]{"%" + s + "%", "%" + s + "%", "%" + s + "%"});
            while (c.moveToNext()) {
                long id = c.getLong(0);
                Button b = btn("تاریخ: " + c.getString(1) + " | " + c.getString(2));
                list.addView(b);
                b.setOnClickListener(v2 -> detail(id));
            }
            c.close();
        });

        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    void detail(long id) {
        base("جزئیات گزارش");
        Cursor c = db.db.rawQuery("SELECT * FROM reports WHERE id=?", new String[]{"" + id});
        if (!c.moveToFirst()) {
            c.close();
            return;
        }
        StringBuilder s = new StringBuilder();
        for (int i = 1; i < c.getColumnCount(); i++) {
            String n = c.getColumnName(i);
            String val = c.getString(i);
            if (val != null && !val.isEmpty()) s.append(n).append(" : ").append(val).append("\n\n");
        }
        c.close();
        TextView t = tv(s.toString(), 14);
        root.addView(t);

        Button edit = btn("✏️ ویرایش گزارش");
        root.addView(edit);
        edit.setOnClickListener(v -> form(id));

        Button pdfBtn = btn("📄 خروجی PDF");
        root.addView(pdfBtn);
        pdfBtn.setOnClickListener(v -> pdf(id));

        Button csvBtn = btn("📊 خروجی Excel/CSV");
        root.addView(csvBtn);
        csvBtn.setOnClickListener(v -> csv(id));

        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> reports());
    }

    void csv(long id) {
        try {
            Cursor c = db.db.rawQuery("SELECT * FROM reports WHERE id=?", new String[]{"" + id});
            if (!c.moveToFirst()) {
                c.close();
                return;
            }
            File f = new File(getExternalFilesDir(null), "report_" + id + ".csv");
            FileWriter w = new FileWriter(f);
            for (int i = 0; i < c.getColumnCount(); i++) {
                if (i > 0) w.append(',');
                w.append('"').append(c.getColumnName(i)).append('"');
            }
            w.append('\n');
            for (int i = 0; i < c.getColumnCount(); i++) {
                if (i > 0) w.append(',');
                String v = c.getString(i);
                if (v == null) v = "";
                w.append('"').append(v.replace("\"", "\"\"")).append('"');
            }
            w.close();
            c.close();
            share(f, "text/csv");
        } catch (Exception e) {
            Toast.makeText(this, "خطا در خروجی: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void pdf(long id) {
        try {
            Cursor c = db.db.rawQuery("SELECT * FROM reports WHERE id=?", new String[]{"" + id});
            if (!c.moveToFirst()) {
                c.close();
                return;
            }
            StringBuilder all = new StringBuilder();
            all.append("گزارش حفاظت فیزیکی – مجتمع طلای کوه‌دم\n");
            all.append("شناسه گزارش: ").append(id).append("\n\n");
            for (int i = 1; i < c.getColumnCount(); i++) {
                String v = c.getString(i);
                if (v != null && !v.isEmpty()) {
                    all.append(c.getColumnName(i)).append(" : ").append(v).append("\n\n");
                }
            }
            c.close();

            PdfDocument d = new PdfDocument();
            int pageW = 595, pageH = 842, margin = 40;
            int pageNo = 1;
            PdfDocument.Page page = d.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create());
            Canvas canvas = page.getCanvas();
            TextPaint paint = new TextPaint();
            paint.setColor(Color.BLACK);
            paint.setTextSize(12);
            paint.setAntiAlias(true);

            int y = margin;
            String[] paragraphs = all.toString().split("\n");
            for (String para : paragraphs) {
                StaticLayout sl = StaticLayout.Builder
                        .obtain(para, 0, para.length(), paint, pageW - 2 * margin)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                        .setIncludePad(false)
                        .build();
                if (y + sl.getHeight() > pageH - margin) {
                    d.finishPage(page);
                    pageNo++;
                    page = d.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create());
                    canvas = page.getCanvas();
                    y = margin;
                }
                canvas.save();
                canvas.translate(margin, y);
                sl.draw(canvas);
                canvas.restore();
                y += sl.getHeight() + 6;
            }
            d.finishPage(page);

            File f = new File(getExternalFilesDir(null), "report_" + id + ".pdf");
            FileOutputStream fos = new FileOutputStream(f);
            d.writeTo(fos);
            fos.close();
            d.close();
            share(f, "application/pdf");
        } catch (Exception e) {
            Toast.makeText(this, "خطا در ساخت PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void share(File f, String mime) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری گزارش"));
        } catch (Exception e) {
            Toast.makeText(this, "خطا در اشتراک‌گذاری: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void monthly() {
        base("کارکرد ماهانه");
        String month = Jalali.month();
        root.addView(tv("ماه جاری: " + month, 16));
        Cursor c = db.db.rawQuery(
                "SELECT chief, COUNT(*) as cnt FROM reports WHERE date LIKE ? GROUP BY chief ORDER BY cnt DESC",
                new String[]{month + "%"});
        while (c.moveToNext()) {
            root.addView(tv(c.getString(0) + " : " + c.getInt(1) + " شیفت", 15));
        }
        c.close();
        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    void users() {
        base("مدیریت کاربران");
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Runnable load = () -> {
            list.removeAllViews();
            Cursor c = db.db.rawQuery("SELECT username, role FROM users", null);
            while (c.moveToNext()) {
                list.addView(tv(c.getString(0) + " (" + c.getString(1) + ")", 14));
            }
            c.close();
        };
        load.run();

        EditText nu = ed("نام کاربری جدید");
        EditText np = ed("رمز عبور");
        EditText nr = ed("نقش (مدیر / سرشیفت / پرسنل)");
        root.addView(nu);
        root.addView(np);
        root.addView(nr);
        Button add = btn("افزودن کاربر");
        root.addView(add);
        add.setOnClickListener(v -> {
            String username = nu.getText().toString().trim();
            String password = np.getText().toString();
            String userRole = nr.getText().toString().trim();
            if (username.isEmpty() || password.length() < 4) {
                Toast.makeText(this, "نام کاربری الزامی است و رمز باید حداقل ۴ نویسه باشد", Toast.LENGTH_LONG).show();
                return;
            }
            if (!("مدیر".equals(userRole) || "سرشیفت".equals(userRole) || "پرسنل".equals(userRole))) {
                Toast.makeText(this, "نقش باید دقیقاً مدیر، سرشیفت یا پرسنل باشد", Toast.LENGTH_LONG).show();
                return;
            }
            ContentValues x = new ContentValues();
            x.put("username", username);
            x.put("password", password);
            x.put("role", userRole);
            long result = db.db.insert("users", null, x);
            if (result == -1) {
                Toast.makeText(this, "این نام کاربری قبلاً ثبت شده است", Toast.LENGTH_LONG).show();
                return;
            }
            nu.setText("");
            np.setText("");
            nr.setText("");
            load.run();
            Toast.makeText(this, "کاربر اضافه شد", Toast.LENGTH_SHORT).show();
        });
        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    static class DB {
        SQLiteDatabase db;

        DB(Context c) {
            db = c.openOrCreateDatabase("hefazat.db", 0, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY, password TEXT, role TEXT)");
            db.execSQL("CREATE TABLE IF NOT EXISTS reports(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, start TEXT, end TEXT, chief TEXT, shift TEXT, " +
                    "staff TEXT, replace TEXT, gold_open TEXT, gold_close TEXT, gold_reason TEXT, " +
                    "mat_count TEXT, mat_plate TEXT, bill TEXT, car_km TEXT, car_fuel TEXT, " +
                    "moto_km TEXT, moto_fuel TEXT, fuel_stock TEXT, gold_keys TEXT, other_keys TEXT, " +
                    "health TEXT, health_desc TEXT, clean TEXT, building TEXT, events TEXT, " +
                    "deliver TEXT, receiver TEXT, created_by TEXT, cars TEXT)");
            Cursor c1 = db.rawQuery("SELECT COUNT(*) FROM users", null);
            c1.moveToFirst();
            if (c1.getInt(0) == 0) {
                ins("admin", "1234", "مدیر");
                ins("shift", "1234", "سرشیفت");
                ins("staff", "1234", "پرسنل");
            }
            c1.close();
        }

        void ins(String u, String p, String r) {
            ContentValues x = new ContentValues();
            x.put("username", u);
            x.put("password", p);
            x.put("role", r);
            db.insert("users", null, x);
        }

        Cursor login(String u, String p) {
            return db.rawQuery("SELECT username, role FROM users WHERE username=? AND password=?", new String[]{u, p});
        }
    }

    static class Jalali {
        static String today() {
            Calendar c = Calendar.getInstance();
            int[] j = toJ(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
            return year(j[0]) + "/" + f(j[1]) + "/" + f(j[2]);
        }

        static String month() {
            String s = today();
            return s.substring(0, 7);
        }

        static String f(int n) {
            String s = String.format(Locale.US, "%02d", n);
            return s.replace('0', '۰').replace('1', '۱').replace('2', '۲').replace('3', '۳').replace('4', '۴')
                    .replace('5', '۵').replace('6', '۶').replace('7', '۷').replace('8', '۸').replace('9', '۹');
        }
        static String year(int n) {
            String s = String.format(Locale.US, "%04d", n);
            return s.replace('0', '۰').replace('1', '۱').replace('2', '۲').replace('3', '۳').replace('4', '۴')
                    .replace('5', '۵').replace('6', '۶').replace('7', '۷').replace('8', '۸').replace('9', '۹');
        }

        static int[] toJ(int gy, int gm, int gd) {
            int[] gdm = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int gy2 = gy - 1600, gm2 = gm - 1, gd2 = gd - 1;
            int gdn = 365 * gy2 + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400;
            for (int i = 0; i < gm2; i++) gdn += gdm[i];
            if (gm2 > 1 && ((gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0)) gdn++;
            gdn += gd2;
            int jdn = gdn - 79;
            int jy = 979 + 33 * (jdn / 12053);
            jdn %= 12053;
            jy += 4 * (jdn / 1461);
            jdn %= 1461;
            if (jdn >= 366) {
                jy += (jdn - 1) / 365;
                jdn = (jdn - 1) % 365;
            }
            int jm, jd;
            if (jdn < 186) {
                jm = 1 + jdn / 31;
                jd = 1 + jdn % 31;
            } else {
                jm = 7 + (jdn - 186) / 30;
                jd = 1 + (jdn - 186) % 30;
            }
            return new int[]{jy, jm, jd};
        }
    }
}
