package com.kohedam.securityreport;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextDirectionHeuristics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root;
    ArrayList<EditText> currentFormFields = new ArrayList<>();
    String user = "", role = "";
    final int GOLD = Color.rgb(201, 154, 36);
    final int DARK = Color.rgb(32, 33, 36);
    int pad = 16;

    boolean isAdmin() { return "مدیر".equals(role); }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        login();
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(DARK);
        t.setPadding(pad, pad, pad, pad);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    EditText ed(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setPadding(pad, 10, pad, 10);
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        return e;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 12, 12, 20);
        root.setBackgroundColor(Color.rgb(247, 245, 240));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);
        TextView h = tv(title, 22);
        h.setTextColor(DARK);
        h.setGravity(Gravity.CENTER);
        h.setTypeface(null, 1);
        root.addView(h);
    }

    void login() {
        base("گزارش‌های حفاظت فیزیکی\nمجتمع طلای کوه‌دم – ایمپاسکو");
        root.addView(tv("ورود کاربران", 18));
        EditText u = ed("نام کاربری");
        EditText p = ed("رمز عبور");
        p.setInputType(129);
        root.addView(u);
        root.addView(p);
        Button b = btn("ورود");
        root.addView(b);
        b.setOnClickListener(v -> {
            Cursor c = db.login(u.getText().toString().trim(), p.getText().toString());
            if (c.moveToFirst()) {
                user = c.getString(0);
                role = c.getString(1);
                c.close();
                home();
            } else {
                Toast.makeText(this, "نام کاربری یا رمز عبور اشتباه است", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void home() {
        base("داشبورد حفاظت فیزیکی");
        root.addView(tv("کاربر: " + user + "   |   نقش: " + role, 15));
        Button n = btn("＋ ثبت گزارش روزانه جدید");
        root.addView(n);
        n.setOnClickListener(v -> form(null));
        Button l = btn("📋 گزارش‌های ثبت‌شده");
        root.addView(l);
        l.setOnClickListener(v -> reports());
        Button m = btn("📊 کارکرد ماهانه");
        root.addView(m);
        m.setOnClickListener(v -> monthly());
        if ("مدیر".equals(role)) {
            Button us = btn("👥 مدیریت کاربران");
            root.addView(us);
            us.setOnClickListener(v -> users());
        }
        Button out = btn("خروج");
        root.addView(out);
        out.setOnClickListener(v -> login());
    }

    EditText add(String label, String value) {
        root.addView(tv(label, 14));
        EditText e = ed(label);
        if (value != null) e.setText(value);
        root.addView(e);
        currentFormFields.add(e);
        return e;
    }

    EditText addDateField(String label, String value) {
        root.addView(tv(label, 14));
        EditText e = ed(label);
        e.setFocusable(false);
        e.setClickable(true);
        e.setText(value == null ? Jalali.today() : value);
        e.setOnClickListener(v -> showJalaliDatePicker(e));
        root.addView(e);
        currentFormFields.add(e);
        return e;
    }

    EditText addTimeField(String label, String value) {
        root.addView(tv(label, 14));
        EditText e = timeInput(label);
        e.setText(value == null ? "" : value);
        root.addView(e);
        currentFormFields.add(e);
        return e;
    }

    EditText timeInput(String hint) {
        EditText e = ed(hint);
        e.setFocusable(false);
        e.setClickable(true);
        e.setOnClickListener(v -> showTimePicker(e));
        return e;
    }

    void showTimePicker(EditText target) {
        int hour = 7, minute = 0;
        try {
            String[] parts = Jalali.toLatin(target.getText().toString()).split(":");
            hour = Math.max(0, Math.min(23, Integer.parseInt(parts[0])));
            minute = Math.max(0, Math.min(59, Integer.parseInt(parts[1])));
        } catch (Exception ignored) {}
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setPadding(12, 8, 12, 8);
        NumberPicker hp = new NumberPicker(this);
        NumberPicker mp = new NumberPicker(this);
        hp.setMinValue(0); hp.setMaxValue(23); hp.setValue(hour);
        mp.setMinValue(0); mp.setMaxValue(59); mp.setValue(minute);
        hp.setDisplayedValues(Jalali.numberValues(0, 23));
        mp.setDisplayedValues(Jalali.numberValues(0, 59));
        box.addView(hp, new LinearLayout.LayoutParams(0, wrapContent(), 1));
        TextView colon = tv(":", 22); colon.setGravity(Gravity.CENTER);
        box.addView(colon);
        box.addView(mp, new LinearLayout.LayoutParams(0, wrapContent(), 1));
        new AlertDialog.Builder(this).setTitle("انتخاب ساعت").setView(box)
                .setPositiveButton("تأیید", (d, w) -> target.setText(Jalali.f(hp.getValue()) + ":" + Jalali.f(mp.getValue())))
                .setNegativeButton("انصراف", null).show();
    }

    void showJalaliDatePicker(EditText target) {
        int y = 1405, m = 1, day = 1;
        try {
            String[] a = Jalali.toLatin(target.getText().toString()).split("/");
            y = Integer.parseInt(a[0]); m = Integer.parseInt(a[1]); day = Integer.parseInt(a[2]);
        } catch (Exception ignored) {
            String[] a = Jalali.toLatin(Jalali.today()).split("/");
            y = Integer.parseInt(a[0]); m = Integer.parseInt(a[1]); day = Integer.parseInt(a[2]);
        }
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setPadding(8, 8, 8, 8);
        NumberPicker yp = new NumberPicker(this);
        NumberPicker mp = new NumberPicker(this);
        NumberPicker dp = new NumberPicker(this);
        yp.setMinValue(1300); yp.setMaxValue(1500); yp.setValue(Math.max(1300, Math.min(1500, y)));
        yp.setDisplayedValues(Jalali.yearValues());
        mp.setMinValue(1); mp.setMaxValue(12); mp.setValue(Math.max(1, Math.min(12, m)));
        mp.setDisplayedValues(new String[]{"فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"});
        dp.setMinValue(1); dp.setMaxValue(Jalali.monthDays(yp.getValue(), mp.getValue()));
        dp.setValue(Math.max(1, Math.min(dp.getMaxValue(), day)));
        dp.setDisplayedValues(Jalali.numberValues(1, dp.getMaxValue()));
        NumberPicker.OnValueChangeListener updateDays = (picker, oldVal, newVal) -> {
            int max = Jalali.monthDays(yp.getValue(), mp.getValue());
            int current = Math.min(dp.getValue(), max);
            dp.setDisplayedValues(null);
            dp.setMinValue(1); dp.setMaxValue(max); dp.setValue(current);
            dp.setDisplayedValues(Jalali.numberValues(1, max));
        };
        yp.setOnValueChangedListener(updateDays);
        mp.setOnValueChangedListener(updateDays);
        box.addView(yp, new LinearLayout.LayoutParams(0, wrapContent(), 1));
        box.addView(mp, new LinearLayout.LayoutParams(0, wrapContent(), 1));
        box.addView(dp, new LinearLayout.LayoutParams(0, wrapContent(), 1));
        new AlertDialog.Builder(this).setTitle("انتخاب تاریخ شمسی").setView(box)
                .setPositiveButton("تأیید", (d, w) -> target.setText(Jalali.year(yp.getValue()) + "/" + Jalali.f(mp.getValue()) + "/" + Jalali.f(dp.getValue())))
                .setNegativeButton("انصراف", null).show();
    }

    int wrapContent() { return LinearLayout.LayoutParams.WRAP_CONTENT; }

    TextView section(String s) {
        TextView t = tv("▰ " + s, 18);
        t.setTextColor(GOLD);
        t.setTypeface(null, 1);
        root.addView(t);
        return t;
    }

    void form(Long id) {
        if (id != null && !isAdmin()) {
            Toast.makeText(this, "فقط مدیر اجازه ویرایش گزارش را دارد", Toast.LENGTH_LONG).show();
            reports();
            return;
        }
        currentFormFields = new ArrayList<>();
        base(id == null ? "ثبت گزارش روزانه" : "ویرایش گزارش روزانه");

        final EditText date = addDateField("تاریخ (شمسی)", Jalali.today());
        EditText start = addTimeField("ساعت شروع شیفت", "07:00");
        EditText end = addTimeField("ساعت پایان شیفت", "07:00");
        EditText chief = add("نام سرشیفت", user);
        EditText shift = add("شماره شیفت", "");

        section("۱. وضعیت پرسنل");
        EditText staff = add("نام و وضعیت ۳ نفر پرسنل", "");
        EditText replace = add("جایگزین در صورت غیبت", "");

        section("۲. ورود و خروج خودروها");
        final ArrayList<EditText[]> cars = new ArrayList<>();
        final LinearLayout carContainer = new LinearLayout(this);
        carContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(carContainer);

        Runnable addCar = () -> {
            int n = cars.size() + 1;
            TextView z = tv("خودرو " + n, 15);
            carContainer.addView(z);
            EditText plate = ed("شماره شهربانی / پلاک");
            EditText passengers = ed("نام راننده و سرنشینان");
            EditText inT = timeInput("ساعت ورود");
            EditText outT = timeInput("ساعت خروج");
            carContainer.addView(plate);
            carContainer.addView(passengers);
            carContainer.addView(inT);
            carContainer.addView(outT);
            cars.add(new EditText[]{plate, passengers, inT, outT});
        };

        Button addCarButton = btn("＋ افزودن خودرو");
        root.addView(addCarButton);
        addCarButton.setOnClickListener(v -> addCar.run());

        if (id != null) {
            Cursor old = db.db.rawQuery("SELECT cars FROM reports WHERE id=?", new String[]{String.valueOf(id)});
            if (old.moveToFirst()) {
                String raw = old.getString(0);
                if (raw != null && !raw.trim().isEmpty()) {
                    try {
                        JSONArray arr = new JSONArray(raw);
                        for (int i = 0; i < arr.length(); i++) {
                            addCar.run();
                            JSONObject o = arr.getJSONObject(i);
                            EditText[] a = cars.get(cars.size() - 1);
                            a[0].setText(o.optString("plate", ""));
                            a[1].setText(o.optString("passengers", ""));
                            a[2].setText(o.optString("in", ""));
                            a[3].setText(o.optString("out", ""));
                        }
                    } catch (Exception legacy) {
                        String[] rows = raw.split(";");
                        for (String row : rows) {
                            if (row.trim().isEmpty()) continue;
                            String[] vals = row.split("\\|", -1);
                            addCar.run();
                            EditText[] a = cars.get(cars.size() - 1);
                            for (int j = 0; j < Math.min(4, vals.length); j++) a[j].setText(vals[j]);
                        }
                    }
                }
            }
            old.close();
        }
        if (cars.isEmpty()) addCar.run();

        section("۳. اتاق طلا");
        EditText goldOpen = addTimeField("ساعت بازگشایی", "");
        EditText goldClose = addTimeField("ساعت بسته شدن", "");
        EditText goldReason = add("علت / توضیحات", "");

        section("۴. ورود مواد آتشباری");
        EditText matCount = add("تعداد خودرو", "");
        EditText matPlate = add("پلاک خودروها", "");
        EditText bill = add("شماره حواله / قبض", "");

        section("۵. سوخت و کیلومتر");
        EditText carKm = add("کیلومتر خودرو", "");
        EditText carFuel = add("سوخت خودرو (لیتر)", "");
        EditText motoKm = add("کیلومتر موتور", "");
        EditText motoFuel = add("سوخت موتور (لیتر)", "");
        EditText fuelStock = add("موجودی سوخت انبار", "");

        section("۶. کلیدها");
        EditText goldKeys = add("کلیدهای اتاق طلا", "");
        EditText otherKeys = add("سایر کلیدها", "");

        section("۷. بهداشت و سلامت");
        EditText health = add("وضعیت بهداشت پرسنل", "");
        EditText healthDesc = add("توضیحات بهداشتی", "");

        section("۸. نظافت اتاق‌ها");
        EditText clean = add("تمیز تحویل داده شد / تمیز تحویل گرفته شد", "");
        EditText building = add("نیازهای ساختمانی", "");

        section("۹. رویدادهای مهم");
        EditText events = add("شرح کامل رویدادها و گزارش‌های مهم", "");

        section("تحویل شیفت");
        EditText deliver = add("نام و امضای تحویل‌دهنده", "");
        EditText receiver = add("نام و امضای تحویل‌گیرنده", "");

        if (id != null) {
            Cursor existing = db.db.rawQuery(
                    "SELECT date,start,end,chief,shift,staff,replace,gold_open,gold_close,gold_reason," +
                            "mat_count,mat_plate,bill,car_km,car_fuel,moto_km,moto_fuel,fuel_stock," +
                            "gold_keys,other_keys,health,health_desc,clean,building,events,deliver,receiver " +
                            "FROM reports WHERE id=?",
                    new String[]{String.valueOf(id)});
            if (existing.moveToFirst()) {
                for (int i = 0; i < currentFormFields.size() && i < existing.getColumnCount(); i++) {
                    String value = existing.getString(i);
                    currentFormFields.get(i).setText(value == null ? "" : value);
                }
            }
            existing.close();
        }

        Button save = btn("💾 ذخیره گزارش");
        root.addView(save);
        Button cancel = btn("بازگشت");
        root.addView(cancel);
        cancel.setOnClickListener(v -> home());

        save.setOnClickListener(v -> {
            ContentValues cv = new ContentValues();
            cv.put("date", date.getText().toString());
            cv.put("start", start.getText().toString());
            cv.put("end", end.getText().toString());
            cv.put("chief", chief.getText().toString());
            cv.put("shift", shift.getText().toString());
            cv.put("staff", staff.getText().toString());
            cv.put("replace", replace.getText().toString());
            cv.put("gold_open", goldOpen.getText().toString());
            cv.put("gold_close", goldClose.getText().toString());
            cv.put("gold_reason", goldReason.getText().toString());
            cv.put("mat_count", matCount.getText().toString());
            cv.put("mat_plate", matPlate.getText().toString());
            cv.put("bill", bill.getText().toString());
            cv.put("car_km", carKm.getText().toString());
            cv.put("car_fuel", carFuel.getText().toString());
            cv.put("moto_km", motoKm.getText().toString());
            cv.put("moto_fuel", motoFuel.getText().toString());
            cv.put("fuel_stock", fuelStock.getText().toString());
            cv.put("gold_keys", goldKeys.getText().toString());
            cv.put("other_keys", otherKeys.getText().toString());
            cv.put("health", health.getText().toString());
            cv.put("health_desc", healthDesc.getText().toString());
            cv.put("clean", clean.getText().toString());
            cv.put("building", building.getText().toString());
            cv.put("events", events.getText().toString());
            cv.put("deliver", deliver.getText().toString());
            cv.put("receiver", receiver.getText().toString());
            if (id == null) cv.put("created_by", user);

            JSONArray cdata = new JSONArray();
            for (EditText[] a : cars) {
                String plate = a[0].getText().toString().trim();
                String passengers = a[1].getText().toString().trim();
                String cin = a[2].getText().toString().trim();
                String cout = a[3].getText().toString().trim();
                if (plate.isEmpty() && passengers.isEmpty() && cin.isEmpty() && cout.isEmpty()) continue;
                try {
                    JSONObject car = new JSONObject();
                    car.put("plate", plate);
                    car.put("passengers", passengers);
                    car.put("in", cin);
                    car.put("out", cout);
                    cdata.put(car);
                } catch (JSONException ignored) {}
            }
            cv.put("cars", cdata.toString());

            if (id == null) {
                db.db.insert("reports", null, cv);
            } else {
                if (!isAdmin()) {
                    Toast.makeText(this, "فقط مدیر اجازه ویرایش گزارش را دارد", Toast.LENGTH_LONG).show();
                    return;
                }
                db.db.update("reports", cv, "id=?", new String[]{"" + id});
            }
            Toast.makeText(this, "گزارش با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show();
            home();
        });
    }

    void reports() {
        base("گزارش‌های ثبت‌شده");
        EditText q = add("عبارت جست‌وجو را وارد کنید", "");
        root.addView(tv("جست‌وجو در کدام فیلد؟", 14));
        Spinner fieldFilter = new Spinner(this);
        String[] searchFields = {"همه فیلدها", "تاریخ", "سرشیفت", "رویداد", "شماره شیفت", "پرسنل", "ثبت‌کننده"};
        ArrayAdapter<String> fieldAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, searchFields);
        fieldAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fieldFilter.setAdapter(fieldAdapter);
        root.addView(fieldFilter);
        Spinner person = null;
        if (isAdmin()) {
            root.addView(tv("فیلتر بر اساس ثبت‌کننده گزارش", 14));
            person = new Spinner(this);
            ArrayList<String> people = new ArrayList<>();
            people.add("همه کاربران");
            Cursor usersCursor = db.db.rawQuery("SELECT username FROM users ORDER BY username", null);
            while (usersCursor.moveToNext()) people.add(usersCursor.getString(0));
            usersCursor.close();
            ArrayAdapter<String> peopleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, people);
            peopleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            person.setAdapter(peopleAdapter);
            root.addView(person);
        }
        final Spinner personFilter = person;
        Button search = btn("جست‌وجو / اعمال فیلتر");
        root.addView(search);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        final Runnable[] loadHolder = new Runnable[1];
        Runnable load = () -> {
            list.removeAllViews();
            String term = q.getText().toString().trim();
            StringBuilder sql = new StringBuilder(
                    "SELECT id,date,chief,shift,created_by FROM reports WHERE 1=1");
            ArrayList<String> args = new ArrayList<>();
            if (!isAdmin()) {
                sql.append(" AND created_by=?");
                args.add(user);
            } else if (personFilter != null && personFilter.getSelectedItemPosition() > 0) {
                sql.append(" AND created_by=?");
                args.add(String.valueOf(personFilter.getSelectedItem()));
            }
            if (!term.isEmpty()) {
                String like = "%" + term + "%";
                switch (fieldFilter.getSelectedItemPosition()) {
                    case 1: sql.append(" AND date LIKE ?"); args.add(like); break;
                    case 2: sql.append(" AND chief LIKE ?"); args.add(like); break;
                    case 3: sql.append(" AND events LIKE ?"); args.add(like); break;
                    case 4: sql.append(" AND shift LIKE ?"); args.add(like); break;
                    case 5: sql.append(" AND staff LIKE ?"); args.add(like); break;
                    case 6: sql.append(" AND created_by LIKE ?"); args.add(like); break;
                    default:
                        sql.append(" AND (date LIKE ? OR chief LIKE ? OR events LIKE ? OR shift LIKE ? OR staff LIKE ? OR created_by LIKE ?)");
                        for (int i = 0; i < 6; i++) args.add(like);
                        break;
                }
            }
            sql.append(" ORDER BY id DESC");
            Cursor c = db.db.rawQuery(sql.toString(), args.toArray(new String[0]));
            if (c.getCount() == 0) list.addView(tv("گزارشی برای نمایش پیدا نشد", 14));
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String owner = c.getString(4) == null ? "نامشخص" : c.getString(4);
                String label = "تاریخ: " + c.getString(1) + " | سرشیفت: " + c.getString(2)
                        + " | شیفت: " + c.getString(3);
                if (isAdmin()) label += " | ثبت‌کننده: " + owner;
                Button b = btn(label);
                list.addView(b);
                b.setOnClickListener(v -> detail(id));
            }
            c.close();
        };
        load.run();
        search.setOnClickListener(v -> load.run());
        if (personFilter != null) personFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { load.run(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    void detail(long id) {
        Cursor permission = db.db.rawQuery("SELECT created_by FROM reports WHERE id=?", new String[]{String.valueOf(id)});
        if (!permission.moveToFirst()) { permission.close(); reports(); return; }
        String owner = permission.getString(0);
        permission.close();
        if (!isAdmin() && !user.equals(owner)) {
            Toast.makeText(this, "شما فقط به گزارش‌های ثبت‌شده توسط خودتان دسترسی دارید", Toast.LENGTH_LONG).show();
            reports();
            return;
        }
        base("جزئیات گزارش");
        Cursor c = db.db.rawQuery("SELECT * FROM reports WHERE id=?", new String[]{"" + id});
        if (!c.moveToFirst()) {
            c.close();
            return;
        }
        StringBuilder s = new StringBuilder();
        for (int i = 1; i < c.getColumnCount(); i++) {
            String n = c.getColumnName(i);
            String val = c.getString(i);
            if (val != null && !val.isEmpty()) s.append(n).append(" : ").append(val).append("\n\n");
        }
        c.close();
        TextView t = tv(s.toString(), 14);
        root.addView(t);

        if (isAdmin()) {
            Button edit = btn("✏️ ویرایش گزارش");
            root.addView(edit);
            edit.setOnClickListener(v -> form(id));

            Button delete = btn("🗑 حذف گزارش");
            root.addView(delete);
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("حذف گزارش")
                    .setMessage("این گزارش برای همیشه حذف شود؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("حذف", (dialog, which) -> {
                        db.db.delete("reports", "id=?", new String[]{String.valueOf(id)});
                        Toast.makeText(this, "گزارش حذف شد", Toast.LENGTH_SHORT).show();
                        reports();
                    }).show());
        }

        Button pdfBtn = btn("📄 خروجی PDF");
        root.addView(pdfBtn);
        pdfBtn.setOnClickListener(v -> pdf(id));

        Button csvBtn = btn("📊 خروجی Excel/CSV");
        root.addView(csvBtn);
        csvBtn.setOnClickListener(v -> csv(id));

        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> reports());
    }

    void csv(long id) {
        try {
            Cursor c = db.db.rawQuery("SELECT * FROM reports WHERE id=?", new String[]{"" + id});
            if (!c.moveToFirst()) {
                c.close();
                return;
            }
            File f = new File(getExternalFilesDir(null), "report_" + id + ".csv");
            FileWriter w = new FileWriter(f);
            for (int i = 0; i < c.getColumnCount(); i++) {
                if (i > 0) w.append(',');
                w.append('"').append(c.getColumnName(i)).append('"');
            }
            w.append('\n');
            for (int i = 0; i < c.getColumnCount(); i++) {
                if (i > 0) w.append(',');
                String v = c.getString(i);
                if (v == null) v = "";
                w.append('"').append(v.replace("\"", "\"\"")).append('"');
            }
            w.close();
            c.close();
            share(f, "text/csv");
        } catch (Exception e) {
            Toast.makeText(this, "خطا در خروجی: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void pdf(long id) {
        try {
            Cursor c = db.db.rawQuery("SELECT * FROM reports WHERE id=?", new String[]{"" + id});
            if (!c.moveToFirst()) {
                c.close();
                return;
            }
            StringBuilder all = new StringBuilder();
            all.append("گزارش حفاظت فیزیکی – مجتمع طلای کوه‌دم\n");
            all.append("شناسه گزارش: ").append(id).append("\n\n");
            for (int i = 1; i < c.getColumnCount(); i++) {
                String v = c.getString(i);
                if (v != null && !v.isEmpty()) {
                    all.append(c.getColumnName(i)).append(" : ").append(v).append("\n\n");
                }
            }
            c.close();

            PdfDocument d = new PdfDocument();
            int pageW = 595, pageH = 842, margin = 40;
            int pageNo = 1;
            PdfDocument.Page page = d.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create());
            Canvas canvas = page.getCanvas();
            TextPaint paint = new TextPaint();
            paint.setColor(Color.BLACK);
            paint.setTextSize(12);
            paint.setAntiAlias(true);

            int y = margin;
            String[] paragraphs = all.toString().split("\n");
            for (String para : paragraphs) {
                StaticLayout sl = StaticLayout.Builder
                        .obtain(para, 0, para.length(), paint, pageW - 2 * margin)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                        .setIncludePad(false)
                        .build();
                if (y + sl.getHeight() > pageH - margin) {
                    d.finishPage(page);
                    pageNo++;
                    page = d.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create());
                    canvas = page.getCanvas();
                    y = margin;
                }
                canvas.save();
                canvas.translate(margin, y);
                sl.draw(canvas);
                canvas.restore();
                y += sl.getHeight() + 6;
            }
            d.finishPage(page);

            File f = new File(getExternalFilesDir(null), "report_" + id + ".pdf");
            FileOutputStream fos = new FileOutputStream(f);
            d.writeTo(fos);
            fos.close();
            d.close();
            share(f, "application/pdf");
        } catch (Exception e) {
            Toast.makeText(this, "خطا در ساخت PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void share(File f, String mime) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری گزارش"));
        } catch (Exception e) {
            Toast.makeText(this, "خطا در اشتراک‌گذاری: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void monthly() {
        base("کارکرد ماهانه");
        String month = Jalali.month();
        root.addView(tv("ماه جاری: " + month, 16));
        Cursor c = isAdmin()
                ? db.db.rawQuery("SELECT chief, COUNT(*) as cnt FROM reports WHERE date LIKE ? GROUP BY chief ORDER BY cnt DESC",
                        new String[]{month + "%"})
                : db.db.rawQuery("SELECT chief, COUNT(*) as cnt FROM reports WHERE date LIKE ? AND created_by=? GROUP BY chief ORDER BY cnt DESC",
                        new String[]{month + "%", user});
        while (c.moveToNext()) {
            root.addView(tv(c.getString(0) + " : " + c.getInt(1) + " شیفت", 15));
        }
        c.close();
        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    void users() {
        if (!isAdmin()) { home(); return; }
        base("مدیریت کاربران");
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Runnable load = () -> {
            list.removeAllViews();
            Cursor c = db.db.rawQuery("SELECT username, role FROM users ORDER BY username", null);
            while (c.moveToNext()) {
                String existingName = c.getString(0);
                String existingRole = c.getString(1);
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setOrientation(LinearLayout.HORIZONTAL);
                TextView label = tv(existingName + " (" + existingRole + ")", 14);
                row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
                Button edit = btn("ویرایش نام و رمز");
                row.addView(edit);
                Button delete = btn("حذف");
                row.addView(delete);
                list.addView(row);
                edit.setOnClickListener(v -> editUser(existingName, existingRole, loadHolder[0]));
                delete.setOnClickListener(v -> confirmDeleteUser(existingName, existingRole, loadHolder[0]));
            }
            c.close();
        };
        loadHolder[0] = load;
        load.run();

        EditText nu = ed("نام کاربری جدید");
        EditText np = ed("رمز عبور");
        np.setInputType(129);
        EditText nr = ed("نقش (مدیر / سرشیفت / پرسنل)");
        root.addView(tv("افزودن کاربر جدید", 16));
        root.addView(nu);
        root.addView(np);
        root.addView(nr);
        Button add = btn("افزودن کاربر");
        root.addView(add);
        add.setOnClickListener(v -> {
            String username = nu.getText().toString().trim();
            String password = np.getText().toString();
            String userRole = nr.getText().toString().trim();
            if (username.isEmpty() || password.length() < 4) {
                Toast.makeText(this, "نام کاربری الزامی است و رمز باید حداقل ۴ نویسه باشد", Toast.LENGTH_LONG).show();
                return;
            }
            if (!("مدیر".equals(userRole) || "سرشیفت".equals(userRole) || "پرسنل".equals(userRole))) {
                Toast.makeText(this, "نقش باید دقیقاً مدیر، سرشیفت یا پرسنل باشد", Toast.LENGTH_LONG).show();
                return;
            }
            ContentValues x = new ContentValues();
            x.put("username", username);
            x.put("password", password);
            x.put("role", userRole);
            long result = db.db.insert("users", null, x);
            if (result == -1) {
                Toast.makeText(this, "این نام کاربری قبلاً ثبت شده است", Toast.LENGTH_LONG).show();
                return;
            }
            nu.setText(""); np.setText(""); nr.setText("");
            load.run();
            Toast.makeText(this, "کاربر اضافه شد", Toast.LENGTH_SHORT).show();
        });
        Button back = btn("بازگشت");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    void confirmDeleteUser(String username, String userRole, Runnable reload) {
        if (!isAdmin()) { home(); return; }
        if (username.equals(user)) {
            Toast.makeText(this, "امکان حذف حسابی که با آن وارد شده‌اید وجود ندارد", Toast.LENGTH_LONG).show();
            return;
        }
        if ("مدیر".equals(userRole)) {
            Cursor admins = db.db.rawQuery("SELECT COUNT(*) FROM users WHERE role='مدیر'", null);
            admins.moveToFirst();
            int count = admins.getInt(0);
            admins.close();
            if (count <= 1) {
                Toast.makeText(this, "آخرین مدیر سیستم قابل حذف نیست", Toast.LENGTH_LONG).show();
                return;
            }
        }
        new AlertDialog.Builder(this).setTitle("حذف کاربر")
                .setMessage("کاربر «" + username + "» حذف شود؟ گزارش‌های قبلی او حفظ می‌شوند و فقط مدیر به آن‌ها دسترسی دارد.")
                .setNegativeButton("انصراف", null)
                .setPositiveButton("حذف", (dialog, which) -> {
                    db.db.delete("users", "username=?", new String[]{username});
                    Toast.makeText(this, "کاربر حذف شد", Toast.LENGTH_SHORT).show();
                    reload.run();
                }).show();
    }

    void editUser(String oldName, String oldRole, Runnable reload) {
        if (!isAdmin()) { home(); return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 8, 20, 0);
        EditText name = ed("نام کاربری"); name.setText(oldName);
        EditText password = ed("رمز جدید (خالی بماند = بدون تغییر)"); password.setInputType(129);
        Spinner rolePicker = new Spinner(this);
        String[] roles = {"مدیر", "سرشیفت", "پرسنل"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, roles);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rolePicker.setAdapter(adapter);
        for (int i = 0; i < roles.length; i++) if (roles[i].equals(oldRole)) rolePicker.setSelection(i);
        box.addView(tv("نام کاربری جدید", 14)); box.addView(name);
        box.addView(tv("رمز عبور جدید", 14)); box.addView(password);
        box.addView(tv("نقش", 14)); box.addView(rolePicker);
        new AlertDialog.Builder(this).setTitle("ویرایش کاربر")
                .setView(box)
                .setPositiveButton("ذخیره", (dialog, which) -> {
                    String newName = name.getText().toString().trim();
                    String newPassword = password.getText().toString();
                    String newRole = roles[rolePicker.getSelectedItemPosition()];
                    if (newName.isEmpty() || (!newPassword.isEmpty() && newPassword.length() < 4)) {
                        Toast.makeText(this, "نام کاربری الزامی است و رمز جدید باید حداقل ۴ نویسه باشد", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Cursor duplicate = db.db.rawQuery("SELECT COUNT(*) FROM users WHERE username=? AND username<>?", new String[]{newName, oldName});
                    duplicate.moveToFirst();
                    boolean exists = duplicate.getInt(0) > 0;
                    duplicate.close();
                    if (exists) {
                        Toast.makeText(this, "این نام کاربری قبلاً استفاده شده است", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (oldName.equals(user) && !"مدیر".equals(newRole)) {
                        Toast.makeText(this, "نقش حساب مدیرِ واردشده را نمی‌توان به کاربر عادی تغییر داد", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if ("مدیر".equals(oldRole) && !"مدیر".equals(newRole)) {
                        Cursor admins = db.db.rawQuery("SELECT COUNT(*) FROM users WHERE role='مدیر'", null);
                        admins.moveToFirst();
                        int adminCount = admins.getInt(0);
                        admins.close();
                        if (adminCount <= 1) {
                            Toast.makeText(this, "آخرین مدیر سیستم قابل تغییر نقش نیست", Toast.LENGTH_LONG).show();
                            return;
                        }
                    }
                    ContentValues values = new ContentValues();
                    values.put("username", newName);
                    values.put("role", newRole);
                    if (!newPassword.isEmpty()) values.put("password", newPassword);
                    int changed = db.db.update("users", values, "username=?", new String[]{oldName});
                    if (changed > 0) {
                        if (!oldName.equals(newName)) {
                            ContentValues ownerUpdate = new ContentValues();
                            ownerUpdate.put("created_by", newName);
                            db.db.update("reports", ownerUpdate, "created_by=?", new String[]{oldName});
                        }
                        if (user.equals(oldName)) { user = newName; role = newRole; }
                        reload.run();
                        Toast.makeText(this, "اطلاعات کاربر تغییر کرد", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("انصراف", null).show();
    }

    static class DB {
        SQLiteDatabase db;

        DB(Context c) {
            db = c.openOrCreateDatabase("hefazat.db", 0, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY, password TEXT, role TEXT)");
            db.execSQL("CREATE TABLE IF NOT EXISTS reports(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, start TEXT, end TEXT, chief TEXT, shift TEXT, " +
                    "staff TEXT, replace TEXT, gold_open TEXT, gold_close TEXT, gold_reason TEXT, " +
                    "mat_count TEXT, mat_plate TEXT, bill TEXT, car_km TEXT, car_fuel TEXT, " +
                    "moto_km TEXT, moto_fuel TEXT, fuel_stock TEXT, gold_keys TEXT, other_keys TEXT, " +
                    "health TEXT, health_desc TEXT, clean TEXT, building TEXT, events TEXT, " +
                    "deliver TEXT, receiver TEXT, created_by TEXT, cars TEXT)");
            Cursor c1 = db.rawQuery("SELECT COUNT(*) FROM users", null);
            c1.moveToFirst();
            if (c1.getInt(0) == 0) {
                ins("admin", "1234", "مدیر");
            }
            c1.close();
        }

        void ins(String u, String p, String r) {
            ContentValues x = new ContentValues();
            x.put("username", u);
            x.put("password", p);
            x.put("role", r);
            db.insert("users", null, x);
        }

        Cursor login(String u, String p) {
            return db.rawQuery("SELECT username, role FROM users WHERE username=? AND password=?", new String[]{u, p});
        }
    }

    static class Jalali {
        static String today() {
            Calendar c = Calendar.getInstance();
            int[] j = toJ(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
            return year(j[0]) + "/" + f(j[1]) + "/" + f(j[2]);
        }

        static String month() {
            String s = today();
            return s.substring(0, 7);
        }

        static String f(int n) {
            String s = String.format(Locale.US, "%02d", n);
            return s.replace('0', '۰').replace('1', '۱').replace('2', '۲').replace('3', '۳').replace('4', '۴')
                    .replace('5', '۵').replace('6', '۶').replace('7', '۷').replace('8', '۸').replace('9', '۹');
        }
        static String year(int n) {
            String s = String.format(Locale.US, "%04d", n);
            return s.replace('0', '۰').replace('1', '۱').replace('2', '۲').replace('3', '۳').replace('4', '۴')
                    .replace('5', '۵').replace('6', '۶').replace('7', '۷').replace('8', '۸').replace('9', '۹');
        }

        static String toLatin(String value) {
            if (value == null) return "";
            String s = value;
            char[] fa = {'۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'};
            char[] ar = {'٠','١','٢','٣','٤','٥','٦','٧','٨','٩'};
            for (int i = 0; i < 10; i++) { s = s.replace(fa[i], (char)('0' + i)); s = s.replace(ar[i], (char)('0' + i)); }
            return s;
        }

        static String[] numberValues(int min, int max) {
            String[] values = new String[max - min + 1];
            for (int i = min; i <= max; i++) values[i - min] = f(i);
            return values;
        }

        static String[] yearValues() {
            String[] values = new String[201];
            for (int i = 1300; i <= 1500; i++) values[i - 1300] = year(i);
            return values;
        }

        static int monthDays(int year, int month) {
            if (month <= 6) return 31;
            if (month <= 11) return 30;
            return isLeapYear(year) ? 30 : 29;
        }

        static boolean isLeapYear(int jy) {
            int[] breaks = {-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178};
            int jp = breaks[0], jump = 0;
            for (int i = 1; i < breaks.length; i++) {
                int jm = breaks[i];
                jump = jm - jp;
                if (jy < jm) break;
                jp = jm;
            }
            int n = jy - jp;
            if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33;
            int leap = (((n + 1) % 33) - 1) % 4;
            if (leap == -1) leap = 4;
            return leap == 0;
        }

        static int[] toJ(int gy, int gm, int gd) {
            int[] gdm = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int gy2 = gy - 1600, gm2 = gm - 1, gd2 = gd - 1;
            int gdn = 365 * gy2 + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400;
            for (int i = 0; i < gm2; i++) gdn += gdm[i];
            if (gm2 > 1 && ((gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0)) gdn++;
            gdn += gd2;
            int jdn = gdn - 79;
            int jy = 979 + 33 * (jdn / 12053);
            jdn %= 12053;
            jy += 4 * (jdn / 1461);
            jdn %= 1461;
            if (jdn >= 366) {
                jy += (jdn - 1) / 365;
                jdn = (jdn - 1) % 365;
            }
            int jm, jd;
            if (jdn < 186) {
                jm = 1 + jdn / 31;
                jd = 1 + jdn % 31;
            } else {
                jm = 7 + (jdn - 186) / 30;
                jd = 1 + (jdn - 186) % 30;
            }
            return new int[]{jy, jm, jd};
        }
    }
}
