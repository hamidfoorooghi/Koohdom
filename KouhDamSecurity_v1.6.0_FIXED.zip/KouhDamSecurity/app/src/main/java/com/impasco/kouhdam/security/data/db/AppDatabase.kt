package com.impasco.kouhdam.security.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.impasco.kouhdam.security.data.dao.ReportDao
import com.impasco.kouhdam.security.data.dao.UserDao
import com.impasco.kouhdam.security.data.entity.*
import com.impasco.kouhdam.security.util.PasswordUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Report::class,
        Personnel::class,
        Vehicle::class,
        GoldRoomMovement::class,
        BlastingMaterial::class,
        Event::class,
        AuditLog::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun reportDao(): ReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // No table changes: this release hardens password hashing and disables destructive upgrades.
                db.execSQL("SELECT 1")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kouhdam_security.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed default admin user
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    seedDefaultUsers(database.userDao())
                                }
                            }
                        }
                    })
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDefaultUsers(userDao: UserDao) {
            if (userDao.count() == 0) {
                userDao.insert(
                    User(
                        username = "admin",
                        passwordHash = PasswordUtils.hash("admin123"),
                        fullName = "مدیر سیستم",
                        role = "ADMIN"
                    )
                )
            }
        }
    }
}
