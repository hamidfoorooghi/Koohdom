# سامانه گزارش حفاظت فیزیکی مجتمع طلای کوه‌دم

**Kouh Dam Physical Security Management System**  
سازمان: شرکت تهیه و تولید مواد معدنی ایران (IMPASCO)

## نسخه ۱.۶.۱

### ساخت محلی

```bash
chmod +x gradlew
./gradlew assembleDebug
```

APK خروجی:
`app/build/outputs/apk/debug/app-debug.apk`

### کاربران پیش‌فرض
| کاربر | رمز | نقش |
|-------|-----|-----|
| admin | admin123 | مدیر |
| operator | 123456 | کاربر عادی |

### نیازمندی‌های Build
- JDK 17
- Android Gradle Plugin 8.2.2
- Gradle 8.5 (via Wrapper)
- compileSdk / targetSdk 34
- minSdk 26

### قابلیت‌ها
- فرم ۱۱ تبی گزارش روزانه
- ثبت چندگانه پرسنل / خودرو / اتاق طلا / رویداد
- ویرایش گزارش
- جست‌وجوی پیشرفته
- مدیریت کاربران
- خروجی PDF / Excel / Word
- تاریخ شمسی
- Audit Log

### GitHub Actions
Workflow در `.github/workflows/build-apk.yml` و `blank.yml`  
Artifact: `KouhDamSecurity-v1.6.1-APK`
