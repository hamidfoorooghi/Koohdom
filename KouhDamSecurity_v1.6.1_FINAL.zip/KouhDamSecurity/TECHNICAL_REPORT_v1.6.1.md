# گزارش فنی — KouhDamSecurity v1.6.1

## اعتبارسنجی Gradle (انجام‌شده)

### نتیجه
- `gradle wrapper` با Gradle 8.5 رسمی: **BUILD SUCCESSFUL**
- `gradle tasks`: پیکربندی پروژه و لیست taskها **موفق**
- `assembleDebug` در این محیط: **ناموفق فقط به‌خاطر نبود Android SDK**  
  (`SDK location not found` — خطا مربوط به محیط است نه پروژه)

### هشدار رفع‌شده
- `android.defaults.buildfeatures.buildconfig=true` در `gradle.properties` در AGP 8.x منسوخ است. حذف شد.  
  `buildFeatures { buildConfig = true }` در `app/build.gradle.kts` کافی است.

### اصلاحات اضافی این مرحله
- Gradle Wrapper رسمی (اسکریپت کامل `gradlew` / `gradlew.bat`) تولید شد
- کلید meta-data مربوط به FileProvider به `androidx.core.FILE_PROVIDER_PATHS` تغییر کرد

## مشکلات قبلی (خلاصه)

| مشکل | اصلاح |
|------|--------|
| نبود Gradle Wrapper | Wrapper Gradle 8.5 اضافه شد |
| Workflow شکننده | تشخیص ریشه پروژه + `./gradlew` + Android SDK action |
| Race در seed کاربران Room | seed پس از ساخت INSTANCE + کاربر operator |
| نسخه | 1.6.1 / versionCode 3 |

## ماتریس سازگاری

| ابزار | نسخه | وضعیت |
|-------|------|--------|
| AGP | 8.2.2 | سازگار با Gradle 8.2+ |
| Gradle Wrapper | 8.5 | تأیید شده |
| Kotlin | 1.9.22 | سازگار |
| KSP | 1.9.22-1.0.17 | سازگار با Kotlin |
| JDK | 17 | الزامی برای AGP 8.2 |
| compileSdk/targetSdk | 34 | OK |
| minSdk | 26 | OK |
| Room | 2.6.1 + KSP | OK |

## نکات CI
1. بعد از extract روی لینوکس: `chmod +x gradlew`
2. JDK 17
3. Android SDK (platform 34)
4. دستور: `./gradlew --no-daemon clean assembleDebug`

## APK
ساخت واقعی APK در محیط فعلی ممکن نبود (SDK نیست). با Workflow روی GitHub Actions باید ساخته شود.
