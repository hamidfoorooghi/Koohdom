# گزارش فنی — KouhDamSecurity v1.6.1

## مشکلات شناسایی‌شده

### ۱. نبود Gradle Wrapper (علت اصلی خطای CI)
- **علائم:** `Gradle wrapper not found` در GitHub Actions
- **علت:** پروژه فقط `build.gradle.kts` و `settings.gradle.kts` داشت و فاقد `gradlew`، `gradlew.bat`، `gradle/wrapper/gradle-wrapper.jar` و `gradle-wrapper.properties` بود.
- **اصلاح:** Wrapper استاندارد Gradle 8.5 اضافه شد (سازگار با AGP 8.2.2).

### ۲. ناسازگاری احتمالی Workflow با ساختار پوشه
- Workflow قبلی فرض می‌کرد ریشه ریپو همان ریشه پروژه است و از `gradle` سیستم استفاده می‌کرد.
- **اصلاح:** تشخیص خودکار ریشه پروژه (`.` یا `KouhDamSecurity/`)، اجرای `./gradlew`، نصب Android SDK، و آپلود artifact با نام `KouhDamSecurity-v1.6.1-APK`.

### ۳. Race condition در Seed کاربران Room
- در `AppDatabase`، `onCreate` به `INSTANCE` وابسته بود که هنگام `build()` هنوز مقداردهی نشده بود → احتمال عدم ایجاد کاربر admin.
- **اصلاح:** seed پس از انتساب `INSTANCE` در coroutine؛ بازگرداندن کاربر `operator`.

### ۴. نسخه اپلیکیشن
- versionName به `1.6.1` و versionCode به `3` به‌روز شد.

## نسخه‌های ابزار (سازگار)

| ابزار | نسخه |
|-------|------|
| Android Gradle Plugin | 8.2.2 |
| Gradle (Wrapper) | 8.5 |
| Kotlin | 1.9.22 |
| KSP | 1.9.22-1.0.17 |
| JDK | 17 |
| compileSdk / targetSdk | 34 |
| minSdk | 26 |

## امنیت
- هش گذرواژه: PBKDF2-HMAC-SHA256 با salt تصادفی و ~210k iteration
- سازگاری عقب‌رو با SHA-256 قدیمی
- FileProvider برای اشتراک فایل خروجی
- رمزها فقط به صورت هش در دیتابیس

## تست‌ها
- ساختار پروژه و وجود Wrapper تأیید شد.
- **ساخت واقعی APK در این محیط ممکن نبود** (Android SDK نصب نیست).
- Workflow برای اجرا روی `ubuntu-latest` با JDK 17 و Android SDK آماده است.

## فایل‌های کلیدی اضافه‌شده/اصلاح‌شده
- `gradlew`, `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`
- `.github/workflows/build-apk.yml`
- `.github/workflows/blank.yml`
- `app/.../AppDatabase.kt`
- `app/build.gradle.kts` (version bump)
