# Keep Room entities
-keep class com.impasco.kouhdam.security.data.entity.** { *; }
