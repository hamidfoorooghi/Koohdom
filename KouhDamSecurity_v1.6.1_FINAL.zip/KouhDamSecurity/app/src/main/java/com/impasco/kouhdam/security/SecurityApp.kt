package com.impasco.kouhdam.security

import android.app.Application
import com.impasco.kouhdam.security.data.db.AppDatabase
import com.impasco.kouhdam.security.util.SessionManager

class SecurityApp : Application() {
    lateinit var database: AppDatabase
        private set
    lateinit var sessionManager: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        sessionManager = SessionManager(this)
    }
}
