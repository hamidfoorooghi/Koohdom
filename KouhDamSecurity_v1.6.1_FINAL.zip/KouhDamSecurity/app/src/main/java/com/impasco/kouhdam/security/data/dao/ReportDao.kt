package com.impasco.kouhdam.security.data.dao

import androidx.room.*
import com.impasco.kouhdam.security.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {

    // Reports
    @Query("SELECT * FROM reports ORDER BY createdAt DESC")
    fun getAllReports(): Flow<List<Report>>

    @Query("SELECT * FROM reports WHERE id = :id")
    suspend fun getReportById(id: Long): Report?

    @Query("SELECT * FROM reports WHERE createdByUserId = :userId ORDER BY createdAt DESC")
    fun getReportsByUser(userId: Long): Flow<List<Report>>

    @Query("SELECT * FROM reports WHERE reportDate = :date ORDER BY createdAt DESC")
    fun getReportsByDate(date: String): Flow<List<Report>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: Report): Long

    @Update
    suspend fun updateReport(report: Report)

    @Delete
    suspend fun deleteReport(report: Report)

    @Query("SELECT COUNT(*) FROM reports WHERE reportDate = :date")
    suspend fun countToday(date: String): Int

    // Advanced Search
    @Query("""
        SELECT DISTINCT r.* FROM reports r
        LEFT JOIN personnel p ON p.reportId = r.id
        LEFT JOIN vehicles v ON v.reportId = r.id
        LEFT JOIN gold_room_movements g ON g.reportId = r.id
        LEFT JOIN events e ON e.reportId = r.id
        LEFT JOIN blasting_materials b ON b.reportId = r.id
        WHERE
            (:dateFrom IS NULL OR r.reportDate >= :dateFrom)
            AND (:dateTo IS NULL OR r.reportDate <= :dateTo)
            AND (:shiftLeader IS NULL OR r.shiftLeader LIKE '%' || :shiftLeader || '%')
            AND (:reporter IS NULL OR r.reporterName LIKE '%' || :reporter || '%')
            AND (:shiftNumber IS NULL OR r.shiftNumber LIKE '%' || :shiftNumber || '%')
            AND (:personnelName IS NULL OR p.fullName LIKE '%' || :personnelName || '%')
            AND (:plate IS NULL OR v.plateNumber LIKE '%' || :plate || '%')
            AND (:goldVisitor IS NULL OR g.visitorName LIKE '%' || :goldVisitor || '%')
            AND (:keyword IS NULL OR
                r.reportDate LIKE '%' || :keyword || '%' OR r.shiftNumber LIKE '%' || :keyword || '%' OR
                r.shiftStart LIKE '%' || :keyword || '%' OR r.shiftEnd LIKE '%' || :keyword || '%' OR
                r.shiftLeader LIKE '%' || :keyword || '%' OR r.reporterName LIKE '%' || :keyword || '%' OR
                r.status LIKE '%' || :keyword || '%' OR r.vehicleKm LIKE '%' || :keyword || '%' OR
                r.vehicleFuelLiters LIKE '%' || :keyword || '%' OR r.motorcycleKm LIKE '%' || :keyword || '%' OR
                r.motorcycleFuelLiters LIKE '%' || :keyword || '%' OR r.fuelStock LIKE '%' || :keyword || '%' OR
                r.fuelNotes LIKE '%' || :keyword || '%' OR r.goldRoomKeysStatus LIKE '%' || :keyword || '%' OR
                r.otherKeysStatus LIKE '%' || :keyword || '%' OR r.keysDeliveredBy LIKE '%' || :keyword || '%' OR
                r.keysReceivedBy LIKE '%' || :keyword || '%' OR r.keysTime LIKE '%' || :keyword || '%' OR
                r.keysNotes LIKE '%' || :keyword || '%' OR r.healthStatus LIKE '%' || :keyword || '%' OR
                r.healthObservations LIKE '%' || :keyword || '%' OR r.healthProblems LIKE '%' || :keyword || '%' OR
                r.healthNotes LIKE '%' || :keyword || '%' OR r.roomsCleaning LIKE '%' || :keyword || '%' OR
                r.areaCleaning LIKE '%' || :keyword || '%' OR r.buildingStatus LIKE '%' || :keyword || '%' OR
                r.facilityProblems LIKE '%' || :keyword || '%' OR r.buildingNeeds LIKE '%' || :keyword || '%' OR
                r.cleaningNotes LIKE '%' || :keyword || '%' OR r.handoverFrom LIKE '%' || :keyword || '%' OR
                r.handoverTo LIKE '%' || :keyword || '%' OR r.handoverTime LIKE '%' || :keyword || '%' OR
                r.overallShiftStatus LIKE '%' || :keyword || '%' OR r.finalNotes LIKE '%' || :keyword || '%' OR
                p.fullName LIKE '%' || :keyword || '%' OR p.presenceStatus LIKE '%' || :keyword || '%' OR
                p.replacementName LIKE '%' || :keyword || '%' OR p.notes LIKE '%' || :keyword || '%' OR
                v.plateNumber LIKE '%' || :keyword || '%' OR v.vehicleType LIKE '%' || :keyword || '%' OR
                v.driverName LIKE '%' || :keyword || '%' OR v.passengers LIKE '%' || :keyword || '%' OR
                v.reason LIKE '%' || :keyword || '%' OR v.notes LIKE '%' || :keyword || '%' OR
                g.visitorName LIKE '%' || :keyword || '%' OR g.positionOrUnit LIKE '%' || :keyword || '%' OR
                g.reason LIKE '%' || :keyword || '%' OR g.companions LIKE '%' || :keyword || '%' OR
                g.responsiblePerson LIKE '%' || :keyword || '%' OR g.notes LIKE '%' || :keyword || '%' OR
                b.receiptNumber LIKE '%' || :keyword || '%' OR b.plates LIKE '%' || :keyword || '%' OR
                b.vehicleCount LIKE '%' || :keyword || '%' OR b.delivererInfo LIKE '%' || :keyword || '%' OR
                b.notes LIKE '%' || :keyword || '%' OR e.description LIKE '%' || :keyword || '%' OR
                e.eventDateTime LIKE '%' || :keyword || '%' OR e.location LIKE '%' || :keyword || '%' OR
                e.relatedPeople LIKE '%' || :keyword || '%' OR e.actionsTaken LIKE '%' || :keyword || '%' OR
                e.result LIKE '%' || :keyword || '%')
            AND (:userId IS NULL OR r.createdByUserId = :userId)
        ORDER BY r.createdAt DESC
    """)
    suspend fun searchReports(
        dateFrom: String?,
        dateTo: String?,
        shiftLeader: String?,
        reporter: String?,
        shiftNumber: String?,
        personnelName: String?,
        plate: String?,
        goldVisitor: String?,
        keyword: String?,
        userId: Long?
    ): List<Report>

    // Personnel
    @Query("SELECT * FROM personnel WHERE reportId = :reportId")
    suspend fun getPersonnel(reportId: Long): List<Personnel>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPersonnel(item: Personnel): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPersonnelList(items: List<Personnel>)

    @Delete
    suspend fun deletePersonnel(item: Personnel)

    @Query("DELETE FROM personnel WHERE reportId = :reportId")
    suspend fun clearPersonnel(reportId: Long)

    // Vehicles
    @Query("SELECT * FROM vehicles WHERE reportId = :reportId")
    suspend fun getVehicles(reportId: Long): List<Vehicle>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(item: Vehicle): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicleList(items: List<Vehicle>)

    @Delete
    suspend fun deleteVehicle(item: Vehicle)

    @Query("DELETE FROM vehicles WHERE reportId = :reportId")
    suspend fun clearVehicles(reportId: Long)

    // Gold Room
    @Query("SELECT * FROM gold_room_movements WHERE reportId = :reportId")
    suspend fun getGoldRoomMovements(reportId: Long): List<GoldRoomMovement>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoldRoom(item: GoldRoomMovement): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoldRoomList(items: List<GoldRoomMovement>)

    @Delete
    suspend fun deleteGoldRoom(item: GoldRoomMovement)

    @Query("DELETE FROM gold_room_movements WHERE reportId = :reportId")
    suspend fun clearGoldRoom(reportId: Long)

    // Blasting
    @Query("SELECT * FROM blasting_materials WHERE reportId = :reportId")
    suspend fun getBlasting(reportId: Long): List<BlastingMaterial>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlasting(item: BlastingMaterial): Long

    @Delete
    suspend fun deleteBlasting(item: BlastingMaterial)

    @Query("DELETE FROM blasting_materials WHERE reportId = :reportId")
    suspend fun clearBlasting(reportId: Long)

    // Events
    @Query("SELECT * FROM events WHERE reportId = :reportId")
    suspend fun getEvents(reportId: Long): List<Event>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(item: Event): Long

    @Delete
    suspend fun deleteEvent(item: Event)

    @Query("DELETE FROM events WHERE reportId = :reportId")
    suspend fun clearEvents(reportId: Long)

    // Audit
    @Insert
    suspend fun insertAudit(log: AuditLog)

    @Query("SELECT * FROM audit_logs WHERE reportId = :reportId ORDER BY timestamp DESC")
    suspend fun getAuditForReport(reportId: Long): List<AuditLog>

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAudits(): Flow<List<AuditLog>>
}
