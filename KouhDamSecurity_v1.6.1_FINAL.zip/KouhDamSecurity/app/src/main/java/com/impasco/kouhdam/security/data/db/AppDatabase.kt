package com.impasco.kouhdam.security.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.impasco.kouhdam.security.data.dao.ReportDao
import com.impasco.kouhdam.security.data.dao.UserDao
import com.impasco.kouhdam.security.data.entity.*
import com.impasco.kouhdam.security.util.PasswordUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Report::class,
        Personnel::class,
        Vehicle::class,
        GoldRoomMovement::class,
        BlastingMaterial::class,
        Event::class,
        AuditLog::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun reportDao(): ReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // No schema changes; version bump for hardened password hashing.
                db.execSQL("SELECT 1")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kouhdam_security.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                // Seed after instance is assigned (Room onCreate callback often races INSTANCE).
                CoroutineScope(Dispatchers.IO).launch {
                    seedDefaultUsers(instance.userDao())
                }
                instance
            }
        }

        private suspend fun seedDefaultUsers(userDao: UserDao) {
            if (userDao.count() > 0) return
            userDao.insert(
                User(
                    username = "admin",
                    passwordHash = PasswordUtils.hash("admin123"),
                    fullName = "مدیر سیستم",
                    role = "ADMIN"
                )
            )
            userDao.insert(
                User(
                    username = "operator",
                    passwordHash = PasswordUtils.hash("123456"),
                    fullName = "اپراتور شیفت",
                    role = "USER"
                )
            )
        }
    }
}
