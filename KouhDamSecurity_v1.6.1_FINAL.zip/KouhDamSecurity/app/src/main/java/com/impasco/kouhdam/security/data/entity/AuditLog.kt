package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reportId: Long? = null,
    val userId: Long,
    val userName: String,
    val action: String, // CREATE, UPDATE, DELETE, LOGIN, LOGOUT
    val details: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
