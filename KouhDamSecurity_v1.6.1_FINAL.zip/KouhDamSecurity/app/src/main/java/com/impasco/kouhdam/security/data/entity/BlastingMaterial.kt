package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "blasting_materials",
    foreignKeys = [
        ForeignKey(
            entity = Report::class,
            parentColumns = ["id"],
            childColumns = ["reportId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("reportId")]
)
data class BlastingMaterial(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reportId: Long,
    val vehicleCount: String? = null,
    val plates: String? = null,
    val receiptNumber: String? = null,
    val timeIn: String? = null,
    val timeOut: String? = null,
    val delivererInfo: String? = null,
    val notes: String? = null
)
