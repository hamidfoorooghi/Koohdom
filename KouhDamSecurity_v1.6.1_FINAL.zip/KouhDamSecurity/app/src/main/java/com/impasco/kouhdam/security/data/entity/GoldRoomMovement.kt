package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "gold_room_movements",
    foreignKeys = [
        ForeignKey(
            entity = Report::class,
            parentColumns = ["id"],
            childColumns = ["reportId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("reportId")]
)
data class GoldRoomMovement(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reportId: Long,
    val visitorName: String,
    val positionOrUnit: String? = null,
    val reason: String? = null,
    val timeIn: String? = null,
    val timeOut: String? = null,
    val companions: String? = null,
    val responsiblePerson: String? = null,
    val notes: String? = null
)
