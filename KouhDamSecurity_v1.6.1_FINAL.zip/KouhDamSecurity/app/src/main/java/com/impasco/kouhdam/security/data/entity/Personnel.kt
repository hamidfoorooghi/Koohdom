package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "personnel",
    foreignKeys = [
        ForeignKey(
            entity = Report::class,
            parentColumns = ["id"],
            childColumns = ["reportId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("reportId")]
)
data class Personnel(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reportId: Long,
    val fullName: String,
    val presenceStatus: String, // PRESENT / ABSENT
    val timeIn: String? = null,
    val timeOut: String? = null,
    val notes: String? = null,
    val replacementName: String? = null
)
