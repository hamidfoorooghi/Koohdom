package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reports")
data class Report(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    // Shift info
    val reportDate: String,          // Shamsi date e.g. 1403/08/15
    val shiftNumber: String,
    val shiftStart: String,
    val shiftEnd: String,
    val shiftLeader: String,
    val reporterName: String,

    // Status
    val status: String = "DRAFT",    // DRAFT or FINAL
    val createdByUserId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val updatedByUserId: Long? = null,

    // Fuel & other single fields
    val vehicleKm: String? = null,
    val vehicleFuelLiters: String? = null,
    val motorcycleKm: String? = null,
    val motorcycleFuelLiters: String? = null,
    val fuelStock: String? = null,
    val fuelNotes: String? = null,

    // Keys
    val goldRoomKeysStatus: String? = null,
    val otherKeysStatus: String? = null,
    val keysDeliveredBy: String? = null,
    val keysReceivedBy: String? = null,
    val keysTime: String? = null,
    val keysNotes: String? = null,

    // Health
    val healthStatus: String? = null,
    val healthObservations: String? = null,
    val healthProblems: String? = null,
    val healthNotes: String? = null,

    // Cleaning
    val roomsCleaning: String? = null,
    val areaCleaning: String? = null,
    val buildingStatus: String? = null,
    val facilityProblems: String? = null,
    val buildingNeeds: String? = null,
    val cleaningNotes: String? = null,

    // Handover
    val handoverFrom: String? = null,
    val handoverTo: String? = null,
    val handoverTime: String? = null,
    val overallShiftStatus: String? = null,
    val finalNotes: String? = null
)
