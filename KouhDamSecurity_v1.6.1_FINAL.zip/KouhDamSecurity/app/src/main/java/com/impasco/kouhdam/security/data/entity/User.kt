package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val fullName: String,
    val role: String, // "ADMIN" or "USER"
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
