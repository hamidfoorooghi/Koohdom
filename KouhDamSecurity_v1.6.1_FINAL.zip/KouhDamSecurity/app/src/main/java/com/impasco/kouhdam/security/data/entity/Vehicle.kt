package com.impasco.kouhdam.security.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "vehicles",
    foreignKeys = [
        ForeignKey(
            entity = Report::class,
            parentColumns = ["id"],
            childColumns = ["reportId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("reportId")]
)
data class Vehicle(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reportId: Long,
    val plateNumber: String,
    val vehicleType: String,
    val driverName: String,
    val passengers: String? = null,
    val reason: String? = null,
    val timeIn: String? = null,
    val timeOut: String? = null,
    val notes: String? = null
)
