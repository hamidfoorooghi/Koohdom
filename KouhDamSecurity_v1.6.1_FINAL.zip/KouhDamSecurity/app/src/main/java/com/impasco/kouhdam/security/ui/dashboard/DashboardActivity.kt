package com.impasco.kouhdam.security.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.databinding.ActivityDashboardBinding
import com.impasco.kouhdam.security.ui.login.LoginActivity
import com.impasco.kouhdam.security.ui.report.AdvancedSearchActivity
import com.impasco.kouhdam.security.ui.report.ReportFormActivity
import com.impasco.kouhdam.security.ui.report.ReportsListActivity
import com.impasco.kouhdam.security.ui.users.UserManagementActivity
import com.impasco.kouhdam.security.util.PersianDateHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val app by lazy { application as SecurityApp }
    private var statsJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!app.sessionManager.isLoggedIn()) {
            goToLogin()
            return
        }

        setupUi()
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val user = app.database.userDao().getById(app.sessionManager.getUserId())
            if (user == null || !user.isActive) {
                app.sessionManager.clear()
                goToLogin()
            } else {
                loadStats()
            }
        }
    }

    private fun setupUi() {
        val fullName = app.sessionManager.getFullName() ?: ""
        val role = if (app.sessionManager.isAdmin()) "مدیر سیستم" else "کاربر عادی"

        binding.tvWelcome.text = "خوش آمدید، $fullName"
        binding.tvRole.text = role
        binding.tvDate.text = "تاریخ امروز: ${PersianDateHelper.todayJalali().toDisplay()}"

        if (app.sessionManager.isAdmin()) {
            binding.btnUsers.visibility = View.VISIBLE
        }

        binding.btnNewReport.setOnClickListener {
            startActivity(Intent(this, ReportFormActivity::class.java))
        }

        binding.btnReportsList.setOnClickListener {
            startActivity(Intent(this, ReportsListActivity::class.java))
        }

        binding.btnSearch.setOnClickListener {
            startActivity(Intent(this, AdvancedSearchActivity::class.java))
        }

        binding.btnUsers.setOnClickListener {
            startActivity(Intent(this, UserManagementActivity::class.java))
        }

        binding.btnLogout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("خروج")
                .setMessage("آیا می‌خواهید از حساب کاربری خارج شوید؟")
                .setPositiveButton("خروج") { _, _ ->
                    app.sessionManager.clear()
                    goToLogin()
                }
                .setNegativeButton("انصراف", null)
                .show()
        }
    }

    private fun loadStats() {
        statsJob?.cancel()
        val today = PersianDateHelper.todayJalali().toFormatted()
        statsJob = lifecycleScope.launch {
            app.database.reportDao().getAllReports().collectLatest { list ->
                val visible = if (app.sessionManager.isAdmin()) list else list.filter { it.createdByUserId == app.sessionManager.getUserId() }
                val monthPrefix = today.substringBeforeLast('/')
                val monthCount = visible.count { it.reportDate.startsWith("$monthPrefix/") }
                val todayCount = visible.count { it.reportDate == today }
                binding.tvTodayCount.text = todayCount.toString()
                binding.tvMonthCount.text = monthCount.toString()
            }
        }
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
