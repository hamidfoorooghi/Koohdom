package com.impasco.kouhdam.security.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.databinding.ActivityLoginBinding
import com.impasco.kouhdam.security.ui.dashboard.DashboardActivity
import com.impasco.kouhdam.security.util.PasswordUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val app by lazy { application as SecurityApp }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If already logged in, go to dashboard
        if (app.sessionManager.isLoggedIn()) {
            startDashboard()
            return
        }

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener { attemptLogin() }
    }

    private fun attemptLogin() {
        val username = binding.etUsername.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString().orEmpty()

        if (username.isEmpty() || password.isEmpty()) {
            showError(getString(com.impasco.kouhdam.security.R.string.login_empty))
            return
        }

        binding.btnLogin.isEnabled = false
        binding.tvError.visibility = View.GONE

        lifecycleScope.launch {
            val user = withContext(Dispatchers.IO) {
                app.database.userDao().getByUsername(username)
            }

            if (user != null && user.isActive && PasswordUtils.verify(password, user.passwordHash)) {
                if (PasswordUtils.needsRehash(user.passwordHash)) {
                    withContext(Dispatchers.IO) {
                        app.database.userDao().update(user.copy(passwordHash = PasswordUtils.hash(password)))
                    }
                }
                app.sessionManager.saveUser(user)
                // Audit login
                withContext(Dispatchers.IO) {
                    app.database.reportDao().insertAudit(
                        com.impasco.kouhdam.security.data.entity.AuditLog(
                            userId = user.id,
                            userName = user.fullName,
                            action = "LOGIN",
                            details = "ورود موفق به سامانه"
                        )
                    )
                }
                startDashboard()
            } else {
                showError(getString(com.impasco.kouhdam.security.R.string.login_error))
                binding.btnLogin.isEnabled = true
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = View.VISIBLE
    }

    private fun startDashboard() {
        startActivity(Intent(this, DashboardActivity::class.java))
        finish()
    }
}
