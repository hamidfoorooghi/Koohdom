package com.impasco.kouhdam.security.ui.report

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.impasco.kouhdam.security.databinding.FragmentTabFieldsBinding

class FieldsTabFragment : Fragment() {

    enum class Type { FUEL, KEYS, HEALTH, CLEANING, HANDOVER }

    private var _binding: FragmentTabFieldsBinding? = null
    private val binding get() = _binding!!
    private lateinit var type: Type
    private lateinit var formData: ReportFormData
    private val editTexts = mutableMapOf<String, TextInputEditText>()

    companion object {
        fun newInstance(type: Type) = FieldsTabFragment().apply {
            arguments = Bundle().apply { putString("type", type.name) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        type = Type.valueOf(arguments?.getString("type") ?: "FUEL")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTabFieldsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        formData = (activity as? ReportFormActivity)?.formData ?: ReportFormData()
        buildFields()
        loadFromFormData()
    }

    private fun buildFields() {
        val container = binding.container
        container.removeAllViews()

        val card = MaterialCardView(requireContext()).apply {
            radius = 28f
            cardElevation = 4f
            setContentPadding(32, 32, 32, 32)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val inner = LinearLayout(requireContext()).apply { orientation = LinearLayout.VERTICAL }
        card.addView(inner)
        container.addView(card)

        fun field(key: String, hint: String) {
            val til = TextInputLayout(requireContext()).apply {
                this.hint = hint
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 20 }
            }
            val et = TextInputEditText(requireContext())
            til.addView(et)
            inner.addView(til)
            editTexts[key] = et
        }

        when (type) {
            Type.FUEL -> {
                field("vehicleKm", "کیلومتر خودرو")
                field("vehicleFuel", "سوخت خودرو (لیتر)")
                field("motorcycleKm", "کیلومتر موتورسیکلت")
                field("motorcycleFuel", "سوخت موتورسیکلت (لیتر)")
                field("fuelStock", "موجودی سوخت انبار")
                field("fuelNotes", "توضیحات")
            }
            Type.KEYS -> {
                field("goldRoomKeys", "وضعیت کلیدهای اتاق طلا")
                field("otherKeys", "وضعیت سایر کلیدها")
                field("keysDeliveredBy", "نام تحویل‌دهنده")
                field("keysReceivedBy", "نام تحویل‌گیرنده")
                field("keysTime", "ساعت تحویل")
                field("keysNotes", "توضیحات")
            }
            Type.HEALTH -> {
                field("healthStatus", "وضعیت بهداشت پرسنل")
                field("healthObservations", "موارد بهداشتی مشاهده‌شده")
                field("healthProblems", "مشکلات احتمالی")
                field("healthNotes", "توضیحات")
            }
            Type.CLEANING -> {
                field("roomsCleaning", "وضعیت نظافت اتاق‌ها")
                field("areaCleaning", "وضعیت نظافت محیط")
                field("buildingStatus", "وضعیت ساختمان")
                field("facilityProblems", "مشکلات تأسیساتی")
                field("buildingNeeds", "نیازهای ساختمانی")
                field("cleaningNotes", "توضیحات")
            }
            Type.HANDOVER -> {
                field("handoverFrom", "نام تحویل‌دهنده")
                field("handoverTo", "نام تحویل‌گیرنده")
                field("handoverTime", "ساعت تحویل")
                field("overallStatus", "وضعیت کلی شیفت")
                field("finalNotes", "توضیحات نهایی")
            }
        }
    }

    private fun loadFromFormData() {
        when (type) {
            Type.FUEL -> {
                editTexts["vehicleKm"]?.setText(formData.vehicleKm)
                editTexts["vehicleFuel"]?.setText(formData.vehicleFuel)
                editTexts["motorcycleKm"]?.setText(formData.motorcycleKm)
                editTexts["motorcycleFuel"]?.setText(formData.motorcycleFuel)
                editTexts["fuelStock"]?.setText(formData.fuelStock)
                editTexts["fuelNotes"]?.setText(formData.fuelNotes)
            }
            Type.KEYS -> {
                editTexts["goldRoomKeys"]?.setText(formData.goldRoomKeys)
                editTexts["otherKeys"]?.setText(formData.otherKeys)
                editTexts["keysDeliveredBy"]?.setText(formData.keysDeliveredBy)
                editTexts["keysReceivedBy"]?.setText(formData.keysReceivedBy)
                editTexts["keysTime"]?.setText(formData.keysTime)
                editTexts["keysNotes"]?.setText(formData.keysNotes)
            }
            Type.HEALTH -> {
                editTexts["healthStatus"]?.setText(formData.healthStatus)
                editTexts["healthObservations"]?.setText(formData.healthObservations)
                editTexts["healthProblems"]?.setText(formData.healthProblems)
                editTexts["healthNotes"]?.setText(formData.healthNotes)
            }
            Type.CLEANING -> {
                editTexts["roomsCleaning"]?.setText(formData.roomsCleaning)
                editTexts["areaCleaning"]?.setText(formData.areaCleaning)
                editTexts["buildingStatus"]?.setText(formData.buildingStatus)
                editTexts["facilityProblems"]?.setText(formData.facilityProblems)
                editTexts["buildingNeeds"]?.setText(formData.buildingNeeds)
                editTexts["cleaningNotes"]?.setText(formData.cleaningNotes)
            }
            Type.HANDOVER -> {
                editTexts["handoverFrom"]?.setText(formData.handoverFrom)
                editTexts["handoverTo"]?.setText(formData.handoverTo)
                editTexts["handoverTime"]?.setText(formData.handoverTime)
                editTexts["overallStatus"]?.setText(formData.overallStatus)
                editTexts["finalNotes"]?.setText(formData.finalNotes)
            }
        }
    }

    /** Call before saving to push values back into formData */
    fun syncToFormData() {
        when (type) {
            Type.FUEL -> {
                formData.vehicleKm = editTexts["vehicleKm"]?.text?.toString().orEmpty()
                formData.vehicleFuel = editTexts["vehicleFuel"]?.text?.toString().orEmpty()
                formData.motorcycleKm = editTexts["motorcycleKm"]?.text?.toString().orEmpty()
                formData.motorcycleFuel = editTexts["motorcycleFuel"]?.text?.toString().orEmpty()
                formData.fuelStock = editTexts["fuelStock"]?.text?.toString().orEmpty()
                formData.fuelNotes = editTexts["fuelNotes"]?.text?.toString().orEmpty()
            }
            Type.KEYS -> {
                formData.goldRoomKeys = editTexts["goldRoomKeys"]?.text?.toString().orEmpty()
                formData.otherKeys = editTexts["otherKeys"]?.text?.toString().orEmpty()
                formData.keysDeliveredBy = editTexts["keysDeliveredBy"]?.text?.toString().orEmpty()
                formData.keysReceivedBy = editTexts["keysReceivedBy"]?.text?.toString().orEmpty()
                formData.keysTime = editTexts["keysTime"]?.text?.toString().orEmpty()
                formData.keysNotes = editTexts["keysNotes"]?.text?.toString().orEmpty()
            }
            Type.HEALTH -> {
                formData.healthStatus = editTexts["healthStatus"]?.text?.toString().orEmpty()
                formData.healthObservations = editTexts["healthObservations"]?.text?.toString().orEmpty()
                formData.healthProblems = editTexts["healthProblems"]?.text?.toString().orEmpty()
                formData.healthNotes = editTexts["healthNotes"]?.text?.toString().orEmpty()
            }
            Type.CLEANING -> {
                formData.roomsCleaning = editTexts["roomsCleaning"]?.text?.toString().orEmpty()
                formData.areaCleaning = editTexts["areaCleaning"]?.text?.toString().orEmpty()
                formData.buildingStatus = editTexts["buildingStatus"]?.text?.toString().orEmpty()
                formData.facilityProblems = editTexts["facilityProblems"]?.text?.toString().orEmpty()
                formData.buildingNeeds = editTexts["buildingNeeds"]?.text?.toString().orEmpty()
                formData.cleaningNotes = editTexts["cleaningNotes"]?.text?.toString().orEmpty()
            }
            Type.HANDOVER -> {
                formData.handoverFrom = editTexts["handoverFrom"]?.text?.toString().orEmpty()
                formData.handoverTo = editTexts["handoverTo"]?.text?.toString().orEmpty()
                formData.handoverTime = editTexts["handoverTime"]?.text?.toString().orEmpty()
                formData.overallStatus = editTexts["overallStatus"]?.text?.toString().orEmpty()
                formData.finalNotes = editTexts["finalNotes"]?.text?.toString().orEmpty()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (::formData.isInitialized) syncToFormData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
