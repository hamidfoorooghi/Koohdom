package com.impasco.kouhdam.security.ui.report

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.impasco.kouhdam.security.R
import com.impasco.kouhdam.security.databinding.FragmentTabMultiBinding
import com.impasco.kouhdam.security.databinding.ItemMultiEntryBinding

class MultiEntryTabFragment : Fragment() {

    enum class Type { PERSONNEL, VEHICLE, GOLD_ROOM, BLASTING, EVENT }

    private var _binding: FragmentTabMultiBinding? = null
    private val binding get() = _binding!!
    private lateinit var type: Type
    private lateinit var formData: ReportFormData
    private lateinit var adapter: MultiAdapter

    companion object {
        fun newInstance(type: Type): MultiEntryTabFragment {
            return MultiEntryTabFragment().apply {
                arguments = Bundle().apply { putString("type", type.name) }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        type = Type.valueOf(arguments?.getString("type") ?: "PERSONNEL")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTabMultiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        formData = (activity as? ReportFormActivity)?.formData ?: ReportFormData()

        adapter = MultiAdapter(
            onDelete = { position ->
                when (type) {
                    Type.PERSONNEL -> formData.personnel.removeAt(position)
                    Type.VEHICLE -> formData.vehicles.removeAt(position)
                    Type.GOLD_ROOM -> formData.goldRoom.removeAt(position)
                    Type.BLASTING -> formData.blasting.removeAt(position)
                    Type.EVENT -> formData.events.removeAt(position)
                }
                refresh()
            }
        )
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter

        binding.btnAdd.text = when (type) {
            Type.PERSONNEL -> "افزودن پرسنل"
            Type.VEHICLE -> "افزودن خودرو"
            Type.GOLD_ROOM -> "افزودن تردد اتاق طلا"
            Type.BLASTING -> "افزودن مواد آتشباری"
            Type.EVENT -> "افزودن رویداد"
        }
        binding.btnAdd.setOnClickListener { showAddDialog() }
        refresh()
    }

    private fun refresh() {
        val items = when (type) {
            Type.PERSONNEL -> formData.personnel.map { it.fullName to "${it.status} | ${it.timeIn} - ${it.timeOut}" }
            Type.VEHICLE -> formData.vehicles.map { it.plate to "${it.type} | ${it.driver}" }
            Type.GOLD_ROOM -> formData.goldRoom.map { it.visitorName to "${it.unit} | ${it.timeIn}" }
            Type.BLASTING -> formData.blasting.map { it.receipt.ifBlank { "بدون شماره" } to it.plates }
            Type.EVENT -> formData.events.map { it.description.take(40) to it.dateTime }
        }
        adapter.submit(items)
        binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showAddDialog() {
        val container = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 8)
        }

        fun addField(hint: String): TextInputEditText {
            val til = TextInputLayout(requireContext()).apply {
                this.hint = hint
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 12 }
            }
            val et = TextInputEditText(requireContext())
            til.addView(et)
            container.addView(til)
            return et
        }

        val fields = mutableListOf<TextInputEditText>()

        when (type) {
            Type.PERSONNEL -> {
                fields += addField("نام و نام خانوادگی *")
                fields += addField("وضعیت (حاضر/غایب)")
                fields += addField("ساعت حضور")
                fields += addField("ساعت خروج")
                fields += addField("نیروی جایگزین")
                fields += addField("توضیحات")
            }
            Type.VEHICLE -> {
                fields += addField("شماره پلاک *")
                fields += addField("نوع خودرو")
                fields += addField("نام راننده")
                fields += addField("سرنشینان")
                fields += addField("علت ورود")
                fields += addField("ساعت ورود")
                fields += addField("ساعت خروج")
                fields += addField("توضیحات")
            }
            Type.GOLD_ROOM -> {
                fields += addField("نام مراجعه‌کننده *")
                fields += addField("سمت / واحد")
                fields += addField("علت ورود")
                fields += addField("ساعت ورود")
                fields += addField("ساعت خروج")
                fields += addField("همراهان")
                fields += addField("مسئول تحویل")
                fields += addField("توضیحات")
            }
            Type.BLASTING -> {
                fields += addField("تعداد خودرو")
                fields += addField("پلاک خودروها")
                fields += addField("شماره حواله")
                fields += addField("ساعت ورود")
                fields += addField("ساعت خروج")
                fields += addField("مشخصات تحویل‌دهنده")
                fields += addField("توضیحات")
            }
            Type.EVENT -> {
                fields += addField("شرح رویداد *")
                fields += addField("تاریخ و ساعت")
                fields += addField("محل وقوع")
                fields += addField("افراد مرتبط")
                fields += addField("اقدامات انجام‌شده")
                fields += addField("نتیجه")
            }
        }

        AlertDialog.Builder(requireContext())
            .setTitle(binding.btnAdd.text)
            .setView(container)
            .setPositiveButton("افزودن") { _, _ ->
                val values = fields.map { it.text?.toString()?.trim().orEmpty() }
                when (type) {
                    Type.PERSONNEL -> {
                        if (values[0].isBlank()) {
                            Toast.makeText(context, "نام الزامی است", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                        formData.personnel.add(
                            ReportFormData.PersonnelItem(
                                fullName = values[0],
                                status = values[1].ifBlank { "PRESENT" },
                                timeIn = values[2],
                                timeOut = values[3],
                                replacement = values[4],
                                notes = values[5]
                            )
                        )
                    }
                    Type.VEHICLE -> {
                        if (values[0].isBlank()) {
                            Toast.makeText(context, "پلاک الزامی است", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                        formData.vehicles.add(
                            ReportFormData.VehicleItem(
                                plate = values[0], type = values[1], driver = values[2],
                                passengers = values[3], reason = values[4],
                                timeIn = values[5], timeOut = values[6], notes = values[7]
                            )
                        )
                    }
                    Type.GOLD_ROOM -> {
                        if (values[0].isBlank()) {
                            Toast.makeText(context, "نام الزامی است", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                        formData.goldRoom.add(
                            ReportFormData.GoldRoomItem(
                                visitorName = values[0], unit = values[1], reason = values[2],
                                timeIn = values[3], timeOut = values[4], companions = values[5],
                                responsible = values[6], notes = values[7]
                            )
                        )
                    }
                    Type.BLASTING -> {
                        formData.blasting.add(
                            ReportFormData.BlastingItem(
                                vehicleCount = values[0], plates = values[1], receipt = values[2],
                                timeIn = values[3], timeOut = values[4], deliverer = values[5], notes = values[6]
                            )
                        )
                    }
                    Type.EVENT -> {
                        if (values[0].isBlank()) {
                            Toast.makeText(context, "شرح الزامی است", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                        formData.events.add(
                            ReportFormData.EventItem(
                                description = values[0], dateTime = values[1], location = values[2],
                                people = values[3], actions = values[4], result = values[5]
                            )
                        )
                    }
                }
                refresh()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Simple adapter
    private class MultiAdapter(
        private val onDelete: (Int) -> Unit
    ) : RecyclerView.Adapter<MultiAdapter.VH>() {

        private val items = mutableListOf<Pair<String, String>>()

        fun submit(list: List<Pair<String, String>>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val binding = ItemMultiEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(binding)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val (title, sub) = items[position]
            holder.binding.tvItemTitle.text = title
            holder.binding.tvItemSubtitle.text = sub
            holder.binding.btnDeleteItem.setOnClickListener { onDelete(position) }
        }

        override fun getItemCount() = items.size

        class VH(val binding: ItemMultiEntryBinding) : RecyclerView.ViewHolder(binding.root)
    }
}
