package com.impasco.kouhdam.security.ui.report

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.databinding.ActivityReportDetailBinding
import com.impasco.kouhdam.security.util.PersianExcelExporter
import com.impasco.kouhdam.security.util.PersianPdfExporter
import com.impasco.kouhdam.security.util.PersianWordExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReportDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportDetailBinding
    private val app by lazy { application as SecurityApp }
    private var reportId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        reportId = intent.getLongExtra("report_id", -1)
        if (reportId == -1L) {
            finish()
            return
        }

        loadReport()
    }

    override fun onResume() {
        super.onResume()
        if (reportId > 0) loadReport()
    }

    private fun loadReport() {
        lifecycleScope.launch {
            val report = withContext(Dispatchers.IO) {
                app.database.reportDao().getReportById(reportId)
            } ?: run { finish(); return@launch }
            if (!app.sessionManager.isAdmin() && report.createdByUserId != app.sessionManager.getUserId()) {
                Toast.makeText(this@ReportDetailActivity, "شما مجاز به مشاهده این گزارش نیستید", Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }

            val personnel = withContext(Dispatchers.IO) { app.database.reportDao().getPersonnel(reportId) }
            val vehicles = withContext(Dispatchers.IO) { app.database.reportDao().getVehicles(reportId) }
            val goldRoom = withContext(Dispatchers.IO) { app.database.reportDao().getGoldRoomMovements(reportId) }
            val blasting = withContext(Dispatchers.IO) { app.database.reportDao().getBlasting(reportId) }
            val events = withContext(Dispatchers.IO) { app.database.reportDao().getEvents(reportId) }

            binding.container.removeAllViews()

            val canEdit = app.sessionManager.isAdmin() || report.createdByUserId == app.sessionManager.getUserId()
            val pdfBundle = PersianPdfExporter.ReportBundle(report, personnel, vehicles, goldRoom, blasting, events)
            val excelBundle = PersianExcelExporter.ReportBundle(report, personnel, vehicles, goldRoom, blasting, events)
            val wordBundle = PersianWordExporter.ReportBundle(report, personnel, vehicles, goldRoom, blasting, events)

            // Row 1: Edit + PDF
            val row1 = LinearLayout(this@ReportDetailActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 8 }
                weightSum = 2f
            }

            if (canEdit) {
                row1.addView(MaterialButton(this@ReportDetailActivity).apply {
                    text = "ویرایش"
                    setBackgroundColor(0xFFC69A43.toInt())
                    setTextColor(0xFF101D32.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = 6
                    }
                    setOnClickListener {
                        startActivity(Intent(this@ReportDetailActivity, ReportFormActivity::class.java).apply {
                            putExtra("report_id", reportId)
                        })
                    }
                })
            }

            row1.addView(MaterialButton(this@ReportDetailActivity).apply {
                text = "PDF"
                setBackgroundColor(0xFF101D32.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = if (canEdit) 6 else 0
                }
                setOnClickListener { exportPdf(pdfBundle) }
            })
            binding.container.addView(row1)

            // Row 2: Excel + Word
            val row2 = LinearLayout(this@ReportDetailActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 16 }
                weightSum = 2f
            }

            row2.addView(MaterialButton(this@ReportDetailActivity).apply {
                text = "Excel"
                setBackgroundColor(0xFF2E7D32.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = 6
                }
                setOnClickListener { exportExcel(excelBundle) }
            })

            row2.addView(MaterialButton(this@ReportDetailActivity).apply {
                text = "Word"
                setBackgroundColor(0xFF1565C0.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = 6
                }
                setOnClickListener { exportWord(wordBundle) }
            })
            binding.container.addView(row2)

            section("اطلاعات شیفت") {
                row("تاریخ", report.reportDate)
                row("شماره شیفت", report.shiftNumber)
                row("ساعت", "${report.shiftStart} تا ${report.shiftEnd}")
                row("سرشیفت", report.shiftLeader)
                row("ثبت‌کننده", report.reporterName)
                row("وضعیت", if (report.status == "FINAL") "نهایی" else "پیش‌نویس")
            }

            if (personnel.isNotEmpty()) {
                section("پرسنل (${personnel.size} نفر)") {
                    personnel.forEach { p ->
                        row(p.fullName, "${p.presenceStatus} | ورود: ${p.timeIn.orEmpty()} | خروج: ${p.timeOut.orEmpty()} | جایگزین: ${p.replacementName.orEmpty()} | توضیحات: ${p.notes.orEmpty()}")
                    }
                }
            }

            if (vehicles.isNotEmpty()) {
                section("خودروها (${vehicles.size})") {
                    vehicles.forEach { v ->
                        row(v.plateNumber, "${v.vehicleType} | راننده: ${v.driverName} | سرنشینان: ${v.passengers.orEmpty()} | علت: ${v.reason.orEmpty()} | ورود: ${v.timeIn.orEmpty()} | خروج: ${v.timeOut.orEmpty()} | توضیحات: ${v.notes.orEmpty()}")
                    }
                }
            }

            if (goldRoom.isNotEmpty()) {
                section("تردد اتاق طلا (${goldRoom.size})") {
                    goldRoom.forEach { g ->
                        row(g.visitorName, "سمت/واحد: ${g.positionOrUnit.orEmpty()} | علت: ${g.reason.orEmpty()} | ورود: ${g.timeIn.orEmpty()} | خروج: ${g.timeOut.orEmpty()} | همراهان: ${g.companions.orEmpty()} | مسئول: ${g.responsiblePerson.orEmpty()} | توضیحات: ${g.notes.orEmpty()}")
                    }
                }
            }

            if (blasting.isNotEmpty()) {
                section("مواد آتشباری") {
                    blasting.forEach { b ->
                        row(b.receiptNumber ?: "بدون شماره", "تعداد خودرو: ${b.vehicleCount.orEmpty()} | پلاک‌ها: ${b.plates.orEmpty()} | ورود: ${b.timeIn.orEmpty()} | خروج: ${b.timeOut.orEmpty()} | تحویل‌دهنده: ${b.delivererInfo.orEmpty()} | توضیحات: ${b.notes.orEmpty()}")
                    }
                }
            }

            section("سوخت و کیلومتر") {
                row("کیلومتر خودرو", report.vehicleKm.orEmpty())
                row("سوخت خودرو", report.vehicleFuelLiters.orEmpty())
                row("کیلومتر موتور", report.motorcycleKm.orEmpty())
                row("سوخت موتور", report.motorcycleFuelLiters.orEmpty())
                row("موجودی انبار", report.fuelStock.orEmpty())
                row("توضیحات سوخت", report.fuelNotes.orEmpty())
            }

            section("کلیدها") {
                row("کلید اتاق طلا", report.goldRoomKeysStatus.orEmpty())
                row("سایر کلیدها", report.otherKeysStatus.orEmpty())
                row("تحویل‌دهنده", report.keysDeliveredBy.orEmpty())
                row("تحویل‌گیرنده", report.keysReceivedBy.orEmpty())
                row("ساعت تحویل", report.keysTime.orEmpty())
                row("توضیحات", report.keysNotes.orEmpty())
            }

            section("بهداشت") {
                row("وضعیت", report.healthStatus.orEmpty())
                row("مشاهدات", report.healthObservations.orEmpty())
                row("مشکلات", report.healthProblems.orEmpty())
                row("توضیحات", report.healthNotes.orEmpty())
            }

            section("نظافت و ساختمان") {
                row("اتاق‌ها", report.roomsCleaning.orEmpty())
                row("محیط", report.areaCleaning.orEmpty())
                row("ساختمان", report.buildingStatus.orEmpty())
                row("مشکلات تأسیسات", report.facilityProblems.orEmpty())
                row("نیازهای ساختمان", report.buildingNeeds.orEmpty())
                row("توضیحات", report.cleaningNotes.orEmpty())
            }

            if (events.isNotEmpty()) {
                section("رویدادهای مهم (${events.size})") {
                    events.forEach { e ->
                        row(e.description, "زمان: ${e.eventDateTime.orEmpty()} | مکان: ${e.location.orEmpty()} | افراد مرتبط: ${e.relatedPeople.orEmpty()} | اقدامات: ${e.actionsTaken.orEmpty()} | نتیجه: ${e.result.orEmpty()}")
                    }
                }
            }

            section("تحویل شیفت") {
                row("از", report.handoverFrom.orEmpty())
                row("به", report.handoverTo.orEmpty())
                row("ساعت", report.handoverTime.orEmpty())
                row("وضعیت کلی", report.overallShiftStatus.orEmpty())
                row("توضیحات", report.finalNotes.orEmpty())
            }
        }
    }

    private fun exportPdf(bundle: PersianPdfExporter.ReportBundle) {
        Toast.makeText(this, "در حال ساخت PDF...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    PersianPdfExporter(this@ReportDetailActivity).export(bundle)
                }
                shareFile(file, "application/pdf", "گزارش حفاظت - شیفت ${bundle.report.shiftNumber}")
                Toast.makeText(this@ReportDetailActivity, "PDF آماده شد", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@ReportDetailActivity, "خطا در PDF: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun exportExcel(bundle: PersianExcelExporter.ReportBundle) {
        Toast.makeText(this, "در حال ساخت Excel...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    PersianExcelExporter(this@ReportDetailActivity).export(bundle)
                }
                shareFile(
                    file,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "گزارش حفاظت - شیفت ${bundle.report.shiftNumber}"
                )
                Toast.makeText(this@ReportDetailActivity, "Excel آماده شد", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@ReportDetailActivity, "خطا در Excel: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun exportWord(bundle: PersianWordExporter.ReportBundle) {
        Toast.makeText(this, "در حال ساخت Word...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    PersianWordExporter(this@ReportDetailActivity).export(bundle)
                }
                shareFile(
                    file,
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "گزارش حفاظت - شیفت ${bundle.report.shiftNumber}"
                )
                Toast.makeText(this@ReportDetailActivity, "Word آماده شد", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@ReportDetailActivity, "خطا در Word: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareFile(file: File, mimeType: String, subject: String) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری فایل"))
    }

    private fun section(title: String, block: LinearLayout.() -> Unit) {
        val card = MaterialCardView(this).apply {
            radius = 28f
            cardElevation = 3f
            setContentPadding(28, 24, 28, 24)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val titleTv = TextView(this).apply {
            text = title
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF101D32.toInt())
            setPadding(0, 0, 0, 12)
        }
        inner.addView(titleTv)
        inner.block()
        card.addView(inner)
        binding.container.addView(card)
    }

    private fun LinearLayout.row(label: String, value: String) {
        if (value.isBlank()) return
        val tv = TextView(this@ReportDetailActivity).apply {
            text = "$label:  $value"
            textSize = 13f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 4, 0, 4)
        }
        addView(tv)
    }
}
