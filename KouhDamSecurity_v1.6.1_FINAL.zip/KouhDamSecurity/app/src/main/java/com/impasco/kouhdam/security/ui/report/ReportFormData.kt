package com.impasco.kouhdam.security.ui.report

import com.impasco.kouhdam.security.data.entity.*

/**
 * Holds all data entered across the 11 tabs while the form is open.
 * Survives tab switches.
 */
class ReportFormData {

    // Tab 0 - Shift
    var date: String = ""
    var shiftNumber: String = ""
    var shiftStart: String = ""
    var shiftEnd: String = ""
    var shiftLeader: String = ""
    var reporterName: String = ""

    // Tab 1 - Personnel (multi)
    val personnel = mutableListOf<PersonnelItem>()

    // Tab 2 - Vehicles (multi)
    val vehicles = mutableListOf<VehicleItem>()

    // Tab 3 - Gold Room (multi)
    val goldRoom = mutableListOf<GoldRoomItem>()

    // Tab 4 - Blasting (usually one, but keep list)
    val blasting = mutableListOf<BlastingItem>()

    // Tab 5 - Fuel
    var vehicleKm: String = ""
    var vehicleFuel: String = ""
    var motorcycleKm: String = ""
    var motorcycleFuel: String = ""
    var fuelStock: String = ""
    var fuelNotes: String = ""

    // Tab 6 - Keys
    var goldRoomKeys: String = ""
    var otherKeys: String = ""
    var keysDeliveredBy: String = ""
    var keysReceivedBy: String = ""
    var keysTime: String = ""
    var keysNotes: String = ""

    // Tab 7 - Health
    var healthStatus: String = ""
    var healthObservations: String = ""
    var healthProblems: String = ""
    var healthNotes: String = ""

    // Tab 8 - Cleaning
    var roomsCleaning: String = ""
    var areaCleaning: String = ""
    var buildingStatus: String = ""
    var facilityProblems: String = ""
    var buildingNeeds: String = ""
    var cleaningNotes: String = ""

    // Tab 9 - Events (multi)
    val events = mutableListOf<EventItem>()

    // Tab 10 - Handover
    var handoverFrom: String = ""
    var handoverTo: String = ""
    var handoverTime: String = ""
    var overallStatus: String = ""
    var finalNotes: String = ""

    // ---- Item classes for multi-entry tabs ----

    data class PersonnelItem(
        var fullName: String = "",
        var status: String = "PRESENT",
        var timeIn: String = "",
        var timeOut: String = "",
        var notes: String = "",
        var replacement: String = ""
    )

    data class VehicleItem(
        var plate: String = "",
        var type: String = "",
        var driver: String = "",
        var passengers: String = "",
        var reason: String = "",
        var timeIn: String = "",
        var timeOut: String = "",
        var notes: String = ""
    )

    data class GoldRoomItem(
        var visitorName: String = "",
        var unit: String = "",
        var reason: String = "",
        var timeIn: String = "",
        var timeOut: String = "",
        var companions: String = "",
        var responsible: String = "",
        var notes: String = ""
    )

    data class BlastingItem(
        var vehicleCount: String = "",
        var plates: String = "",
        var receipt: String = "",
        var timeIn: String = "",
        var timeOut: String = "",
        var deliverer: String = "",
        var notes: String = ""
    )

    data class EventItem(
        var description: String = "",
        var dateTime: String = "",
        var location: String = "",
        var people: String = "",
        var actions: String = "",
        var result: String = ""
    )

    fun toReport(userId: Long, isFinal: Boolean): Report {
        return Report(
            reportDate = date,
            shiftNumber = shiftNumber,
            shiftStart = shiftStart,
            shiftEnd = shiftEnd,
            shiftLeader = shiftLeader,
            reporterName = reporterName,
            status = if (isFinal) "FINAL" else "DRAFT",
            createdByUserId = userId,
            vehicleKm = vehicleKm.ifBlank { null },
            vehicleFuelLiters = vehicleFuel.ifBlank { null },
            motorcycleKm = motorcycleKm.ifBlank { null },
            motorcycleFuelLiters = motorcycleFuel.ifBlank { null },
            fuelStock = fuelStock.ifBlank { null },
            fuelNotes = fuelNotes.ifBlank { null },
            goldRoomKeysStatus = goldRoomKeys.ifBlank { null },
            otherKeysStatus = otherKeys.ifBlank { null },
            keysDeliveredBy = keysDeliveredBy.ifBlank { null },
            keysReceivedBy = keysReceivedBy.ifBlank { null },
            keysTime = keysTime.ifBlank { null },
            keysNotes = keysNotes.ifBlank { null },
            healthStatus = healthStatus.ifBlank { null },
            healthObservations = healthObservations.ifBlank { null },
            healthProblems = healthProblems.ifBlank { null },
            healthNotes = healthNotes.ifBlank { null },
            roomsCleaning = roomsCleaning.ifBlank { null },
            areaCleaning = areaCleaning.ifBlank { null },
            buildingStatus = buildingStatus.ifBlank { null },
            facilityProblems = facilityProblems.ifBlank { null },
            buildingNeeds = buildingNeeds.ifBlank { null },
            cleaningNotes = cleaningNotes.ifBlank { null },
            handoverFrom = handoverFrom.ifBlank { null },
            handoverTo = handoverTo.ifBlank { null },
            handoverTime = handoverTime.ifBlank { null },
            overallShiftStatus = overallStatus.ifBlank { null },
            finalNotes = finalNotes.ifBlank { null }
        )
    }
}
