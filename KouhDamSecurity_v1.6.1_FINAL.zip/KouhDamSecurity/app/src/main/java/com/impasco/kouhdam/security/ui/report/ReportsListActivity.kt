package com.impasco.kouhdam.security.ui.report

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.data.entity.Report
import com.impasco.kouhdam.security.databinding.ActivityReportsListBinding
import com.impasco.kouhdam.security.databinding.ItemReportBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ReportsListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportsListBinding
    private val app by lazy { application as SecurityApp }
    private lateinit var adapter: ReportsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportsListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = ReportsAdapter { report ->
            startActivity(Intent(this, ReportDetailActivity::class.java).apply {
                putExtra("report_id", report.id)
            })
        }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        lifecycleScope.launch {
            val flow = if (app.sessionManager.isAdmin()) {
                app.database.reportDao().getAllReports()
            } else {
                app.database.reportDao().getReportsByUser(app.sessionManager.getUserId())
            }
            flow.collectLatest { list ->
                adapter.submit(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                binding.recycler.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private class ReportsAdapter(
        private val onClick: (Report) -> Unit
    ) : RecyclerView.Adapter<ReportsAdapter.VH>() {

        private val items = mutableListOf<Report>()

        fun submit(list: List<Report>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemReportBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(b)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val r = items[position]
            holder.b.tvDate.text = r.reportDate
            holder.b.tvShift.text = "شیفت ${r.shiftNumber}  |  ${r.shiftStart} - ${r.shiftEnd}"
            holder.b.tvLeader.text = "سرشیفت: ${r.shiftLeader}  |  ثبت‌کننده: ${r.reporterName}"
            holder.b.tvStatus.text = if (r.status == "FINAL") "نهایی" else "پیش‌نویس"
            holder.b.tvStatus.setBackgroundColor(
                if (r.status == "FINAL") 0xFF1565C0.toInt() else 0xFFF9A825.toInt()
            )
            holder.itemView.setOnClickListener { onClick(r) }
        }

        override fun getItemCount() = items.size

        class VH(val b: ItemReportBinding) : RecyclerView.ViewHolder(b.root)
    }
}
