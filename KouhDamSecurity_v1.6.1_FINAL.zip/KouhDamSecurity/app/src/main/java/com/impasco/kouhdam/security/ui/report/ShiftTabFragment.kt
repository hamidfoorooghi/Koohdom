package com.impasco.kouhdam.security.ui.report

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.impasco.kouhdam.security.databinding.FragmentTabShiftBinding
import com.impasco.kouhdam.security.util.PersianDateHelper
import java.util.Calendar

class ShiftTabFragment : Fragment() {

    private var _binding: FragmentTabShiftBinding? = null
    private val binding get() = _binding!!
    private lateinit var formData: ReportFormData

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTabShiftBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        formData = (activity as? ReportFormActivity)?.formData ?: ReportFormData()

        if (formData.date.isBlank()) {
            binding.etDate.setText(PersianDateHelper.todayJalali().toFormatted())
        } else {
            binding.etDate.setText(formData.date)
        }
        binding.etShiftNumber.setText(formData.shiftNumber)
        binding.etShiftStart.setText(formData.shiftStart)
        binding.etShiftEnd.setText(formData.shiftEnd)
        binding.etShiftLeader.setText(formData.shiftLeader)
        binding.etReporter.setText(formData.reporterName)

        binding.etDate.isFocusable = false
        binding.etDate.isClickable = true
        binding.etDate.setOnClickListener { showPersianDatePicker() }
    }

    private fun showPersianDatePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            requireContext(),
            { _, year, month, day ->
                val jalali = PersianDateHelper.toJalali(
                    Calendar.getInstance().apply { set(year, month, day) }
                )
                binding.etDate.setText(jalali.toFormatted())
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    fun syncToFormData() {
        formData.date = binding.etDate.text?.toString()?.trim().orEmpty()
        formData.shiftNumber = binding.etShiftNumber.text?.toString()?.trim().orEmpty()
        formData.shiftStart = binding.etShiftStart.text?.toString()?.trim().orEmpty()
        formData.shiftEnd = binding.etShiftEnd.text?.toString()?.trim().orEmpty()
        formData.shiftLeader = binding.etShiftLeader.text?.toString()?.trim().orEmpty()
        formData.reporterName = binding.etReporter.text?.toString()?.trim().orEmpty()
    }

    override fun onPause() {
        super.onPause()
        if (::formData.isInitialized && _binding != null) syncToFormData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
