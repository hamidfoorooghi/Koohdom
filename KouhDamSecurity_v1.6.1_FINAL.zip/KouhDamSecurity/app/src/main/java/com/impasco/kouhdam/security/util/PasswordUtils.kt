package com.impasco.kouhdam.security.util

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PasswordUtils {
    private const val ITERATIONS = 210_000
    private const val KEY_LENGTH = 256
    private const val SALT_LENGTH = 16

    fun hash(password: String): String {
        require(password.isNotEmpty()) { "گذرواژه نمی‌تواند خالی باشد" }
        val salt = ByteArray(SALT_LENGTH).also { SecureRandom().nextBytes(it) }
        val derived = derive(password, salt, ITERATIONS)
        return "pbkdf2\$$ITERATIONS\$${salt.toHex()}\$${derived.toHex()}"
    }

    fun verify(password: String, stored: String): Boolean {
        if (stored.startsWith("pbkdf2$")) {
            val parts = stored.split('$')
            if (parts.size != 4) return false
            return try {
                val iterations = parts[1].toInt()
                if (iterations !in 100_000..1_000_000) return false
                val salt = parts[2].hexToBytes()
                val expected = parts[3].hexToBytes()
                MessageDigest.isEqual(derive(password, salt, iterations), expected)
            } catch (_: Exception) { false }
        }
        // Backward compatibility for accounts created by app versions using plain SHA-256.
        val legacy = MessageDigest.getInstance("SHA-256").digest(password.toByteArray(Charsets.UTF_8)).toHex()
        return MessageDigest.isEqual(legacy.toByteArray(), stored.lowercase().toByteArray())
    }

    fun needsRehash(stored: String): Boolean = !stored.startsWith("pbkdf2$")

    private fun derive(password: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, KEY_LENGTH)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes(): ByteArray {
        require(length % 2 == 0 && all { it in "0123456789abcdefABCDEF" })
        return chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }
}
