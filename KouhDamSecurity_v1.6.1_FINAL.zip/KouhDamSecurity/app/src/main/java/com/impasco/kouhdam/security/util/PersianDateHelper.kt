package com.impasco.kouhdam.security.util

import java.util.Calendar

/**
 * Simple Persian (Jalali) date helper.
 * Converts Gregorian <-> Jalali and formats dates.
 */
object PersianDateHelper {

    private val persianMonths = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    data class JalaliDate(val year: Int, val month: Int, val day: Int) {
        fun toFormatted(): String = "%04d/%02d/%02d".format(year, month, day)
        fun toDisplay(): String = "$day ${persianMonths[month - 1]} $year"
    }

    fun todayJalali(): JalaliDate = toJalali(Calendar.getInstance())

    fun toJalali(cal: Calendar): JalaliDate {
        val gy = cal.get(Calendar.YEAR)
        val gm = cal.get(Calendar.MONTH) + 1
        val gd = cal.get(Calendar.DAY_OF_MONTH)
        return gregorianToJalali(gy, gm, gd)
    }

    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Calendar {
        val g = jalaliToGregorianRaw(jy, jm, jd)
        return Calendar.getInstance().apply {
            set(g[0], g[1] - 1, g[2])
        }
    }

    fun parseJalali(dateStr: String): JalaliDate? {
        val parts = dateStr.trim().split("/", "-", ".")
        if (parts.size != 3) return null
        return try {
            JalaliDate(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
        } catch (e: Exception) {
            null
        }
    }

    // --- Conversion algorithms (standard) ---

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): JalaliDate {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy2 = gy
        if (gm > 2) gy2++
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
                ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return JalaliDate(jy, jm, jd)
    }

    private fun jalaliToGregorianRaw(jy: Int, jm: Int, jd: Int): IntArray {
        var jy2 = jy + 1595
        var days = -355668 + (365 * jy2) + ((jy2 / 33) * 8) + (((jy2 % 33) + 3) / 4) + jd +
                if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            gy += 100 * (--days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val gd = days + 1
        val salA = if ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0))
            intArrayOf(0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366)
        else
            intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365)
        var gm = 0
        while (gm < 13 && gd > salA[gm]) gm++
        return intArrayOf(gy, gm, gd - salA[gm - 1])
    }

    fun getMonthName(month: Int): String =
        if (month in 1..12) persianMonths[month - 1] else ""
}
