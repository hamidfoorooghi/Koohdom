package com.impasco.kouhdam.security.util

import android.content.Context
import android.content.SharedPreferences
import com.impasco.kouhdam.security.data.entity.User

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("kouhdam_session", Context.MODE_PRIVATE)

    fun saveUser(user: User) {
        prefs.edit()
            .putLong("user_id", user.id)
            .putString("username", user.username)
            .putString("full_name", user.fullName)
            .putString("role", user.role)
            .apply()
    }

    fun getUserId(): Long = prefs.getLong("user_id", -1)
    fun getUsername(): String? = prefs.getString("username", null)
    fun getFullName(): String? = prefs.getString("full_name", null)
    fun getRole(): String? = prefs.getString("role", null)
    fun isAdmin(): Boolean = getRole() == "ADMIN"
    fun isLoggedIn(): Boolean = getUserId() != -1L

    fun clear() {
        prefs.edit().clear().apply()
    }
}
