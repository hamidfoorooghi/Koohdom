package com.impasco.kouhdam.security.ui.report

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import com.google.android.material.tabs.TabLayoutMediator
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.data.entity.*
import com.impasco.kouhdam.security.databinding.ActivityReportFormBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ReportFormActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportFormBinding
    private val app by lazy { application as SecurityApp }
    private lateinit var pagerAdapter: ReportPagerAdapter

    val formData = ReportFormData()
    private var editingReportId: Long = -1L

    private val tabTitles = listOf(
        "تاریخ و شیفت", "پرسنل", "خودروها", "اتاق طلا", "آتشباری",
        "سوخت", "کلیدها", "بهداشت", "نظافت", "رویدادها", "تحویل شیفت"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportFormBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        editingReportId = intent.getLongExtra("report_id", -1L)

        if (editingReportId > 0) {
            binding.toolbar.title = "ویرایش گزارش"
            loadExistingReport(editingReportId)
        } else {
            formData.reporterName = app.sessionManager.getFullName().orEmpty()
            setupPager()
        }

        binding.btnSaveDraft.setOnClickListener { saveReport(isFinal = false) }
        binding.btnSaveFinal.setOnClickListener { saveReport(isFinal = true) }
    }

    private fun setupPager() {
        pagerAdapter = ReportPagerAdapter(this)
        binding.viewPager.adapter = pagerAdapter
        binding.viewPager.offscreenPageLimit = 5
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = tabTitles[position]
        }.attach()
    }

    private fun loadExistingReport(reportId: Long) {
        lifecycleScope.launch {
            val report = withContext(Dispatchers.IO) {
                app.database.reportDao().getReportById(reportId)
            } ?: run {
                Toast.makeText(this@ReportFormActivity, "گزارش یافت نشد", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            if (!app.sessionManager.isAdmin() && report.createdByUserId != app.sessionManager.getUserId()) {
                Toast.makeText(this@ReportFormActivity, "شما مجاز به ویرایش این گزارش نیستید", Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }

            // Fill formData from report
            formData.date = report.reportDate
            formData.shiftNumber = report.shiftNumber
            formData.shiftStart = report.shiftStart
            formData.shiftEnd = report.shiftEnd
            formData.shiftLeader = report.shiftLeader
            formData.reporterName = report.reporterName
            formData.vehicleKm = report.vehicleKm.orEmpty()
            formData.vehicleFuel = report.vehicleFuelLiters.orEmpty()
            formData.motorcycleKm = report.motorcycleKm.orEmpty()
            formData.motorcycleFuel = report.motorcycleFuelLiters.orEmpty()
            formData.fuelStock = report.fuelStock.orEmpty()
            formData.fuelNotes = report.fuelNotes.orEmpty()
            formData.goldRoomKeys = report.goldRoomKeysStatus.orEmpty()
            formData.otherKeys = report.otherKeysStatus.orEmpty()
            formData.keysDeliveredBy = report.keysDeliveredBy.orEmpty()
            formData.keysReceivedBy = report.keysReceivedBy.orEmpty()
            formData.keysTime = report.keysTime.orEmpty()
            formData.keysNotes = report.keysNotes.orEmpty()
            formData.healthStatus = report.healthStatus.orEmpty()
            formData.healthObservations = report.healthObservations.orEmpty()
            formData.healthProblems = report.healthProblems.orEmpty()
            formData.healthNotes = report.healthNotes.orEmpty()
            formData.roomsCleaning = report.roomsCleaning.orEmpty()
            formData.areaCleaning = report.areaCleaning.orEmpty()
            formData.buildingStatus = report.buildingStatus.orEmpty()
            formData.facilityProblems = report.facilityProblems.orEmpty()
            formData.buildingNeeds = report.buildingNeeds.orEmpty()
            formData.cleaningNotes = report.cleaningNotes.orEmpty()
            formData.handoverFrom = report.handoverFrom.orEmpty()
            formData.handoverTo = report.handoverTo.orEmpty()
            formData.handoverTime = report.handoverTime.orEmpty()
            formData.overallStatus = report.overallShiftStatus.orEmpty()
            formData.finalNotes = report.finalNotes.orEmpty()

            // Load multi-entry
            withContext(Dispatchers.IO) {
                app.database.reportDao().getPersonnel(reportId).forEach { p ->
                    formData.personnel.add(
                        ReportFormData.PersonnelItem(
                            p.fullName, p.presenceStatus,
                            p.timeIn.orEmpty(), p.timeOut.orEmpty(),
                            p.notes.orEmpty(), p.replacementName.orEmpty()
                        )
                    )
                }
                app.database.reportDao().getVehicles(reportId).forEach { v ->
                    formData.vehicles.add(
                        ReportFormData.VehicleItem(
                            v.plateNumber, v.vehicleType, v.driverName,
                            v.passengers.orEmpty(), v.reason.orEmpty(),
                            v.timeIn.orEmpty(), v.timeOut.orEmpty(), v.notes.orEmpty()
                        )
                    )
                }
                app.database.reportDao().getGoldRoomMovements(reportId).forEach { g ->
                    formData.goldRoom.add(
                        ReportFormData.GoldRoomItem(
                            g.visitorName, g.positionOrUnit.orEmpty(), g.reason.orEmpty(),
                            g.timeIn.orEmpty(), g.timeOut.orEmpty(),
                            g.companions.orEmpty(), g.responsiblePerson.orEmpty(), g.notes.orEmpty()
                        )
                    )
                }
                app.database.reportDao().getBlasting(reportId).forEach { b ->
                    formData.blasting.add(
                        ReportFormData.BlastingItem(
                            b.vehicleCount.orEmpty(), b.plates.orEmpty(), b.receiptNumber.orEmpty(),
                            b.timeIn.orEmpty(), b.timeOut.orEmpty(),
                            b.delivererInfo.orEmpty(), b.notes.orEmpty()
                        )
                    )
                }
                app.database.reportDao().getEvents(reportId).forEach { e ->
                    formData.events.add(
                        ReportFormData.EventItem(
                            e.description, e.eventDateTime.orEmpty(), e.location.orEmpty(),
                            e.relatedPeople.orEmpty(), e.actionsTaken.orEmpty(), e.result.orEmpty()
                        )
                    )
                }
            }

            setupPager()
        }
    }


    private fun saveReport(isFinal: Boolean) {
        if (::pagerAdapter.isInitialized) {
            pagerAdapter.getShiftFragment().syncToFormData()
            pagerAdapter.syncAllFieldTabs()
        }

        if (formData.date.isBlank() || formData.shiftNumber.isBlank() || formData.shiftLeader.isBlank()) {
            Toast.makeText(this, "لطفاً فیلدهای ضروری تب «تاریخ و شیفت» را تکمیل کنید", Toast.LENGTH_LONG).show()
            binding.viewPager.currentItem = 0
            return
        }

        val userId = app.sessionManager.getUserId()
        val isEdit = editingReportId > 0

        lifecycleScope.launch {
            try {
                val savedId = withContext(Dispatchers.IO) {
                    app.database.withTransaction {
                        val reportId: Long
                        if (isEdit) {
                            val existing = app.database.reportDao().getReportById(editingReportId)
                                ?: return@withTransaction -1L
                            val updated = formData.toReport(userId, isFinal).copy(
                                id = editingReportId,
                                createdByUserId = existing.createdByUserId,
                                createdAt = existing.createdAt,
                                updatedAt = System.currentTimeMillis(),
                                updatedByUserId = userId
                            )
                            app.database.reportDao().updateReport(updated)
                            app.database.reportDao().clearPersonnel(editingReportId)
                            app.database.reportDao().clearVehicles(editingReportId)
                            app.database.reportDao().clearGoldRoom(editingReportId)
                            app.database.reportDao().clearBlasting(editingReportId)
                            app.database.reportDao().clearEvents(editingReportId)
                            reportId = editingReportId
                        } else {
                            reportId = app.database.reportDao().insertReport(formData.toReport(userId, isFinal))
                        }

                        formData.personnel.forEach { p ->
                            app.database.reportDao().insertPersonnel(
                                Personnel(
                                    reportId = reportId, fullName = p.fullName, presenceStatus = p.status,
                                    timeIn = p.timeIn.ifBlank { null }, timeOut = p.timeOut.ifBlank { null },
                                    notes = p.notes.ifBlank { null }, replacementName = p.replacement.ifBlank { null }
                                )
                            )
                        }
                        formData.vehicles.forEach { v ->
                            app.database.reportDao().insertVehicle(
                                Vehicle(
                                    reportId = reportId, plateNumber = v.plate, vehicleType = v.type, driverName = v.driver,
                                    passengers = v.passengers.ifBlank { null }, reason = v.reason.ifBlank { null },
                                    timeIn = v.timeIn.ifBlank { null }, timeOut = v.timeOut.ifBlank { null },
                                    notes = v.notes.ifBlank { null }
                                )
                            )
                        }
                        formData.goldRoom.forEach { g ->
                            app.database.reportDao().insertGoldRoom(
                                GoldRoomMovement(
                                    reportId = reportId, visitorName = g.visitorName,
                                    positionOrUnit = g.unit.ifBlank { null }, reason = g.reason.ifBlank { null },
                                    timeIn = g.timeIn.ifBlank { null }, timeOut = g.timeOut.ifBlank { null },
                                    companions = g.companions.ifBlank { null },
                                    responsiblePerson = g.responsible.ifBlank { null },
                                    notes = g.notes.ifBlank { null }
                                )
                            )
                        }
                        formData.blasting.forEach { b ->
                            app.database.reportDao().insertBlasting(
                                BlastingMaterial(
                                    reportId = reportId,
                                    vehicleCount = b.vehicleCount.ifBlank { null },
                                    plates = b.plates.ifBlank { null },
                                    receiptNumber = b.receipt.ifBlank { null },
                                    timeIn = b.timeIn.ifBlank { null }, timeOut = b.timeOut.ifBlank { null },
                                    delivererInfo = b.deliverer.ifBlank { null }, notes = b.notes.ifBlank { null }
                                )
                            )
                        }
                        formData.events.forEach { e ->
                            app.database.reportDao().insertEvent(
                                Event(
                                    reportId = reportId, description = e.description,
                                    eventDateTime = e.dateTime.ifBlank { null },
                                    location = e.location.ifBlank { null },
                                    relatedPeople = e.people.ifBlank { null },
                                    actionsTaken = e.actions.ifBlank { null },
                                    result = e.result.ifBlank { null }
                                )
                            )
                        }
                        app.database.reportDao().insertAudit(
                            AuditLog(
                                reportId = reportId,
                                userId = userId,
                                userName = app.sessionManager.getFullName().orEmpty(),
                                action = when {
                                    isEdit && isFinal -> "UPDATE_FINAL"
                                    isEdit -> "UPDATE_DRAFT"
                                    isFinal -> "CREATE_FINAL"
                                    else -> "CREATE_DRAFT"
                                },
                                details = "شیفت ${formData.shiftNumber}"
                            )
                        )
                        reportId
                    }
                }

                if (savedId > 0L) {
                    editingReportId = savedId
                }

                Toast.makeText(
                    this@ReportFormActivity,
                    when {
                        isFinal -> "گزارش نهایی ثبت شد"
                        else -> "پیش‌نویس ذخیره شد — می‌توانید ادامه دهید یا «ثبت نهایی» بزنید"
                    },
                    Toast.LENGTH_LONG
                ).show()
                if (isFinal) finish()
            } catch (e: Exception) {
                Toast.makeText(
                    this@ReportFormActivity,
                    "خطا در ذخیره: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                e.printStackTrace()
            }
        }
    }
}
