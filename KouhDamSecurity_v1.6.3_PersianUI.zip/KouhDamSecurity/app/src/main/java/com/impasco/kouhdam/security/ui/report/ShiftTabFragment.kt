package com.impasco.kouhdam.security.ui.report

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.impasco.kouhdam.security.databinding.FragmentTabShiftBinding
import com.impasco.kouhdam.security.util.PersianDateHelper
import com.impasco.kouhdam.security.util.UiPickers

class ShiftTabFragment : Fragment() {

    private var _binding: FragmentTabShiftBinding? = null
    private val binding get() = _binding!!
    private lateinit var formData: ReportFormData

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTabShiftBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        formData = (activity as? ReportFormActivity)?.formData ?: ReportFormData()

        if (formData.date.isBlank()) {
            binding.etDate.setText(PersianDateHelper.todayJalali().toPersianFormatted())
        } else {
            val parsed = PersianDateHelper.parseJalali(formData.date)
            binding.etDate.setText(parsed?.toPersianFormatted() ?: PersianDateHelper.toPersianDigits(formData.date))
        }
        binding.etShiftNumber.setText(formData.shiftNumber)
        binding.etShiftStart.setText(formData.shiftStart)
        binding.etShiftEnd.setText(formData.shiftEnd)
        binding.etShiftLeader.setText(formData.shiftLeader)
        binding.etReporter.setText(formData.reporterName)

        UiPickers.attachDatePicker(requireContext(), binding.etDate)
        UiPickers.attachTimePicker(requireContext(), binding.etShiftStart)
        UiPickers.attachTimePicker(requireContext(), binding.etShiftEnd)
    }

    fun syncToFormData() {
        val rawDate = binding.etDate.text?.toString()?.trim().orEmpty()
        formData.date = PersianDateHelper.parseJalali(rawDate)?.toFormatted()
            ?: PersianDateHelper.toWesternDigits(rawDate)
        formData.shiftNumber = binding.etShiftNumber.text?.toString()?.trim().orEmpty()
        formData.shiftStart = PersianDateHelper.toWesternDigits(binding.etShiftStart.text?.toString()?.trim().orEmpty())
        formData.shiftEnd = PersianDateHelper.toWesternDigits(binding.etShiftEnd.text?.toString()?.trim().orEmpty())
        formData.shiftLeader = binding.etShiftLeader.text?.toString()?.trim().orEmpty()
        formData.reporterName = binding.etReporter.text?.toString()?.trim().orEmpty()
    }

    override fun onPause() {
        super.onPause()
        if (::formData.isInitialized && _binding != null) syncToFormData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
