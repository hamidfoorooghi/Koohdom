package com.impasco.kouhdam.security.ui.report

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.impasco.kouhdam.security.databinding.FragmentTabFieldsBinding
import com.impasco.kouhdam.security.util.UiPickers

class FieldsTabFragment : Fragment() {

    enum class Type { FUEL, KEYS, HEALTH, CLEANING, HANDOVER }

    private var _binding: FragmentTabFieldsBinding? = null
    private val binding get() = _binding!!
    private lateinit var type: Type
    private lateinit var formData: ReportFormData
    private val editTexts = mutableMapOf<String, TextInputEditText>()

    companion object {
        fun newInstance(type: Type) = FieldsTabFragment().apply {
            arguments = Bundle().apply { putString("type", type.name) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        type = Type.valueOf(arguments?.getString("type") ?: "FUEL")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTabFieldsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        formData = (activity as? ReportFormActivity)?.formData ?: ReportFormData()
        buildFields()
        loadFromFormData()
        attachPickers()
    }

    private fun attachPickers() {
        val timeKeys = setOf("keysTime", "handoverTime")
        editTexts.forEach { (key, et) ->
            if (key in timeKeys) {
                UiPickers.attachTimePicker(requireContext(), et)
            }
        }
    }

    private fun buildFields() {
        val container = binding.container
        container.removeAllViews()

        val card = MaterialCardView(requireContext()).apply {
            radius = 28f
            cardElevation = 4f
            setContentPadding(32, 32, 32, 32)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val inner = LinearLayout(requireContext()).apply { orientation = LinearLayout.VERTICAL }
        card.addView(inner)
        container.addView(card)

        fun field(key: String, hint: String) {
            val til = TextInputLayout(requireContext()).apply {
                this.hint = hint
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 20 }
            }
            val et = TextInputEditText(requireContext())
            til.addView(et)
            inner.addView(til)
            editTexts[key] = et
        }

        when (type) {
            Type.FUEL -> {
                field("vehicleKm", "کیلومتر خودرو")
                field("vehicleFuel", "سوخت خودرو (لیتر)")
                field("motorcycleKm", "کیلومتر موتورسیکلت")
                field("motorcycleFuel", "سوخت موتورسیکلت (لیتر)")
                field("fuelStock", "موجودی سوخت انبار")
                field("fuelNotes", "توضیحات")
            }
            Type.KEYS -> {
                field("goldRoomKeys", "وضعیت کلیدهای اتاق طلا")
                field("otherKeys", "وضعیت سایر کلیدها")
                field("keysDeliveredBy", "نام تحویل‌دهنده")
                field("keysReceivedBy", "نام تحویل‌گیرنده")
                field("keysTime", "ساعت تحویل")
                field("keysNotes", "توضیحات")
            }
            Type.HEALTH -> {
                field("healthStatus", "وضعیت بهداشت پرسنل")
                field("healthObservations", "موارد بهداشتی مشاهده‌شده")
                field("healthProblems", "مشکلات احتمالی")
                field("healthNotes", "توضیحات")
            }
            Type.CLEANING -> {
                field("roomsCleaning", "وضعیت نظافت اتاق‌ها")
                field("areaCleaning", "وضعیت نظافت محیط")
                field("buildingStatus", "وضعیت ساختمان")
                field("facilityProblems", "مشکلات تأسیساتی")
                field("buildingNeeds", "نیازهای ساختمانی")
                field("cleaningNotes", "توضیحات")
            }
            Type.HANDOVER -> {
                field("handoverFrom", "نام تحویل‌دهنده")
                field("handoverTo", "نام تحویل‌گیرنده")
                field("handoverTime", "ساعت تحویل")
                field("overallStatus", "وضعیت کلی شیفت")
                field("finalNotes", "توضیحات نهایی")
            }
        }
    }

    private fun loadFromFormData() {
        when (type) {
            Type.FUEL -> {
                editTexts["vehicleKm"]?.setText(formData.vehicleKm)
                editTexts["vehicleFuel"]?.setText(formData.vehicleFuel)
                editTexts["motorcycleKm"]?.setText(formData.motorcycleKm)
                editTexts["motorcycleFuel"]?.setText(formData.motorcycleFuel)
                editTexts["fuelStock"]?.setText(formData.fuelStock)
                editTexts["fuelNotes"]?.setText(formData.fuelNotes)
            }
            Type.KEYS -> {
                editTexts["goldRoomKeys"]?.setText(formData.goldRoomKeys)
                editTexts["otherKeys"]?.setText(formData.otherKeys)
                editTexts["keysDeliveredBy"]?.setText(formData.keysDeliveredBy)
                editTexts["keysReceivedBy"]?.setText(formData.keysReceivedBy)
                editTexts["keysTime"]?.setText(formData.keysTime)
                editTexts["keysNotes"]?.setText(formData.keysNotes)
            }
            Type.HEALTH -> {
                editTexts["healthStatus"]?.setText(formData.healthStatus)
                editTexts["healthObservations"]?.setText(formData.healthObservations)
                editTexts["healthProblems"]?.setText(formData.healthProblems)
                editTexts["healthNotes"]?.setText(formData.healthNotes)
            }
            Type.CLEANING -> {
                editTexts["roomsCleaning"]?.setText(formData.roomsCleaning)
                editTexts["areaCleaning"]?.setText(formData.areaCleaning)
                editTexts["buildingStatus"]?.setText(formData.buildingStatus)
                editTexts["facilityProblems"]?.setText(formData.facilityProblems)
                editTexts["buildingNeeds"]?.setText(formData.buildingNeeds)
                editTexts["cleaningNotes"]?.setText(formData.cleaningNotes)
            }
            Type.HANDOVER -> {
                editTexts["handoverFrom"]?.setText(formData.handoverFrom)
                editTexts["handoverTo"]?.setText(formData.handoverTo)
                editTexts["handoverTime"]?.setText(formData.handoverTime)
                editTexts["overallStatus"]?.setText(formData.overallStatus)
                editTexts["finalNotes"]?.setText(formData.finalNotes)
            }
        }
    }


    fun syncToFormData() {
        if (_binding == null) return
        if (!::formData.isInitialized) return
        editTexts.forEach { (key, et) ->
            val value = et.text?.toString()?.trim().orEmpty()
            when (key) {
                "vehicleKm" -> formData.vehicleKm = value
                "vehicleFuel" -> formData.vehicleFuel = value
                "motorcycleKm" -> formData.motorcycleKm = value
                "motorcycleFuel" -> formData.motorcycleFuel = value
                "fuelStock" -> formData.fuelStock = value
                "fuelNotes" -> formData.fuelNotes = value
                "goldRoomKeys" -> formData.goldRoomKeys = value
                "otherKeys" -> formData.otherKeys = value
                "keysDeliveredBy" -> formData.keysDeliveredBy = value
                "keysReceivedBy" -> formData.keysReceivedBy = value
                "keysTime" -> formData.keysTime = value
                "keysNotes" -> formData.keysNotes = value
                "healthStatus" -> formData.healthStatus = value
                "healthObservations" -> formData.healthObservations = value
                "healthProblems" -> formData.healthProblems = value
                "healthNotes" -> formData.healthNotes = value
                "roomsCleaning" -> formData.roomsCleaning = value
                "areaCleaning" -> formData.areaCleaning = value
                "buildingStatus" -> formData.buildingStatus = value
                "facilityProblems" -> formData.facilityProblems = value
                "buildingNeeds" -> formData.buildingNeeds = value
                "cleaningNotes" -> formData.cleaningNotes = value
                "handoverFrom" -> formData.handoverFrom = value
                "handoverTo" -> formData.handoverTo = value
                "handoverTime" -> formData.handoverTime = value
                "overallStatus" -> formData.overallStatus = value
                "finalNotes" -> formData.finalNotes = value
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (::formData.isInitialized) syncToFormData()
    }

    override fun onDestroyView() {
        syncToFormData()
        super.onDestroyView()
        _binding = null
    }
}
