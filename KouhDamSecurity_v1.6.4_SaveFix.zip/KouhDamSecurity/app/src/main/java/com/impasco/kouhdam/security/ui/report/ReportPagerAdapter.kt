package com.impasco.kouhdam.security.ui.report

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class ReportPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    private val shiftFragment = ShiftTabFragment()
    private val fieldFragments = mutableMapOf<Int, FieldsTabFragment>()

    override fun getItemCount(): Int = 11

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> shiftFragment
            1 -> MultiEntryTabFragment.newInstance(MultiEntryTabFragment.Type.PERSONNEL)
            2 -> MultiEntryTabFragment.newInstance(MultiEntryTabFragment.Type.VEHICLE)
            3 -> MultiEntryTabFragment.newInstance(MultiEntryTabFragment.Type.GOLD_ROOM)
            4 -> MultiEntryTabFragment.newInstance(MultiEntryTabFragment.Type.BLASTING)
            5 -> FieldsTabFragment.newInstance(FieldsTabFragment.Type.FUEL).also { fieldFragments[5] = it }
            6 -> FieldsTabFragment.newInstance(FieldsTabFragment.Type.KEYS).also { fieldFragments[6] = it }
            7 -> FieldsTabFragment.newInstance(FieldsTabFragment.Type.HEALTH).also { fieldFragments[7] = it }
            8 -> FieldsTabFragment.newInstance(FieldsTabFragment.Type.CLEANING).also { fieldFragments[8] = it }
            9 -> MultiEntryTabFragment.newInstance(MultiEntryTabFragment.Type.EVENT)
            10 -> FieldsTabFragment.newInstance(FieldsTabFragment.Type.HANDOVER).also { fieldFragments[10] = it }
            else -> ShiftTabFragment()
        }
    }

    fun getShiftFragment(): ShiftTabFragment = shiftFragment

    fun syncAllFieldTabs() {
        fieldFragments.values.forEach { fragment ->
            try {
                fragment.syncToFormData()
            } catch (_: Exception) {
                // view may be destroyed
            }
        }
    }
}
