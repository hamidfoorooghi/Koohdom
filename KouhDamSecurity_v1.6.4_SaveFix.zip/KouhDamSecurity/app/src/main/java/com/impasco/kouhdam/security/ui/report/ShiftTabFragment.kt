package com.impasco.kouhdam.security.ui.report

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.impasco.kouhdam.security.databinding.FragmentTabShiftBinding
import com.impasco.kouhdam.security.util.PersianDateHelper
import com.impasco.kouhdam.security.util.UiPickers

class ShiftTabFragment : Fragment() {

    private var _binding: FragmentTabShiftBinding? = null
    private val binding get() = _binding!!
    private var formData: ReportFormData? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTabShiftBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        formData = (activity as? ReportFormActivity)?.formData
        val data = formData ?: return

        if (data.date.isBlank()) {
            binding.etDate.setText(PersianDateHelper.todayJalali().toPersianFormatted())
        } else {
            val parsed = PersianDateHelper.parseJalali(data.date)
            binding.etDate.setText(
                parsed?.toPersianFormatted()
                    ?: PersianDateHelper.toPersianDigits(data.date)
            )
        }
        binding.etShiftNumber.setText(data.shiftNumber)
        binding.etShiftStart.setText(
            if (data.shiftStart.isBlank()) ""
            else PersianDateHelper.toPersianDigits(data.shiftStart)
        )
        binding.etShiftEnd.setText(
            if (data.shiftEnd.isBlank()) ""
            else PersianDateHelper.toPersianDigits(data.shiftEnd)
        )
        binding.etShiftLeader.setText(data.shiftLeader)
        binding.etReporter.setText(data.reporterName)

        UiPickers.attachDatePicker(requireContext(), binding.etDate)
        UiPickers.attachTimePicker(requireContext(), binding.etShiftStart)
        UiPickers.attachTimePicker(requireContext(), binding.etShiftEnd)
    }

    /** Safe: no-op if view destroyed (ViewPager off-screen). */
    fun syncToFormData() {
        val b = _binding ?: return
        val data = formData ?: (activity as? ReportFormActivity)?.formData ?: return

        val rawDate = b.etDate.text?.toString()?.trim().orEmpty()
        data.date = PersianDateHelper.parseJalali(rawDate)?.toFormatted()
            ?: PersianDateHelper.toWesternDigits(rawDate)
        data.shiftNumber = b.etShiftNumber.text?.toString()?.trim().orEmpty()
        data.shiftStart = PersianDateHelper.toWesternDigits(
            b.etShiftStart.text?.toString()?.trim().orEmpty()
        )
        data.shiftEnd = PersianDateHelper.toWesternDigits(
            b.etShiftEnd.text?.toString()?.trim().orEmpty()
        )
        data.shiftLeader = b.etShiftLeader.text?.toString()?.trim().orEmpty()
        data.reporterName = b.etReporter.text?.toString()?.trim().orEmpty()
    }

    override fun onPause() {
        super.onPause()
        syncToFormData()
    }

    override fun onDestroyView() {
        syncToFormData()
        super.onDestroyView()
        _binding = null
    }
}
