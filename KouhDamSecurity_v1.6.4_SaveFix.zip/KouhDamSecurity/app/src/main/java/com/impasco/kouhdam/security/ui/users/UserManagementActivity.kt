package com.impasco.kouhdam.security.ui.users

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.data.entity.User
import com.impasco.kouhdam.security.databinding.ActivityUserManagementBinding
import com.impasco.kouhdam.security.databinding.ItemUserBinding
import com.impasco.kouhdam.security.util.PasswordUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class UserManagementActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserManagementBinding
    private val app by lazy { application as SecurityApp }
    private lateinit var adapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!app.sessionManager.isAdmin()) {
            Toast.makeText(this, "دسترسی مجاز نیست", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        binding = ActivityUserManagementBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = UserAdapter(
            onEdit = { user -> showUserDialog(user) },
            onToggle = { user -> toggleUser(user) }
        )
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.btnAddUser.setOnClickListener { showUserDialog(null) }

        lifecycleScope.launch {
            app.database.userDao().getAll().collectLatest { list ->
                adapter.submit(list)
            }
        }
    }

    private fun showUserDialog(existing: User?) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 8)
        }

        fun field(hint: String, value: String = "", isPassword: Boolean = false): TextInputEditText {
            val til = TextInputLayout(this).apply {
                this.hint = hint
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 16 }
            }
            val et = TextInputEditText(this).apply {
                setText(value)
                if (isPassword) inputType =
                    android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            til.addView(et)
            container.addView(til)
            return et
        }

        val etFullName = field("نام و نام خانوادگی *", existing?.fullName.orEmpty())
        val etUsername = field("نام کاربری *", existing?.username.orEmpty())
        val etPassword = field(
            if (existing == null) "رمز عبور *" else "رمز عبور جدید (خالی = بدون تغییر)",
            "",
            isPassword = true
        )

        // Role selection
        val roles = arrayOf("USER", "ADMIN")
        val roleLabels = arrayOf("کاربر عادی", "مدیر سیستم")
        var selectedRole = existing?.role ?: "USER"
        val roleIndex = roles.indexOf(selectedRole).coerceAtLeast(0)

        val builder = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "افزودن کاربر" else "ویرایش کاربر")
            .setView(container)
            .setSingleChoiceItems(roleLabels, roleIndex) { _, which ->
                selectedRole = roles[which]
            }
            .setPositiveButton("ذخیره") { _, _ ->
                val fullName = etFullName.text?.toString()?.trim().orEmpty()
                val username = etUsername.text?.toString()?.trim().orEmpty()
                val password = etPassword.text?.toString().orEmpty()

                if (fullName.isBlank() || username.isBlank()) {
                    Toast.makeText(this, "نام و نام کاربری الزامی است", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (existing == null && password.isBlank()) {
                    Toast.makeText(this, "رمز عبور الزامی است", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (password.isNotBlank() && password.length < 8) {
                    Toast.makeText(this, "رمز عبور باید حداقل ۸ نویسه باشد", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                lifecycleScope.launch {
                    if (existing == null) {
                        // Check duplicate
                        val exists = app.database.userDao().getByUsername(username)
                        if (exists != null) {
                            Toast.makeText(this@UserManagementActivity, "نام کاربری تکراری است", Toast.LENGTH_SHORT).show()
                            return@launch
                        }
                        app.database.userDao().insert(
                            User(
                                username = username,
                                passwordHash = PasswordUtils.hash(password),
                                fullName = fullName,
                                role = selectedRole
                            )
                        )
                        Toast.makeText(this@UserManagementActivity, "کاربر افزوده شد", Toast.LENGTH_SHORT).show()
                    } else {
                        val updated = existing.copy(
                            fullName = fullName,
                            username = username,
                            role = selectedRole,
                            passwordHash = if (password.isNotBlank()) PasswordUtils.hash(password) else existing.passwordHash
                        )
                        app.database.userDao().update(updated)
                        Toast.makeText(this@UserManagementActivity, "کاربر به‌روزرسانی شد", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("انصراف", null)

        builder.show()
    }

    private fun toggleUser(user: User) {
        if (user.id == app.sessionManager.getUserId()) {
            Toast.makeText(this, "نمی‌توانید حساب خود را غیرفعال کنید", Toast.LENGTH_SHORT).show()
            return
        }
        val newActive = !user.isActive
        val msg = if (newActive) "فعال کردن کاربر؟" else "غیرفعال کردن کاربر؟"
        AlertDialog.Builder(this)
            .setTitle("تغییر وضعیت")
            .setMessage("$msg\n${user.fullName}")
            .setPositiveButton("تأیید") { _, _ ->
                lifecycleScope.launch {
                    app.database.userDao().update(user.copy(isActive = newActive))
                    Toast.makeText(
                        this@UserManagementActivity,
                        if (newActive) "کاربر فعال شد" else "کاربر غیرفعال شد",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private class UserAdapter(
        private val onEdit: (User) -> Unit,
        private val onToggle: (User) -> Unit
    ) : RecyclerView.Adapter<UserAdapter.VH>() {

        private val items = mutableListOf<User>()

        fun submit(list: List<User>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(b)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val u = items[position]
            holder.b.tvFullName.text = u.fullName
            holder.b.tvUsername.text = "نام کاربری: ${u.username}"
            holder.b.tvRole.text = if (u.role == "ADMIN") "مدیر سیستم" else "کاربر عادی"
            holder.b.tvRole.setTextColor(if (u.role == "ADMIN") 0xFFC69A43.toInt() else 0xFF5A6577.toInt())
            if (!u.isActive) {
                holder.b.tvFullName.alpha = 0.5f
                holder.b.tvUsername.text = "${holder.b.tvUsername.text} (غیرفعال)"
            } else {
                holder.b.tvFullName.alpha = 1f
            }
            holder.b.btnEdit.setOnClickListener { onEdit(u) }
            holder.b.btnToggle.setOnClickListener { onToggle(u) }
        }

        override fun getItemCount() = items.size
        class VH(val b: ItemUserBinding) : RecyclerView.ViewHolder(b.root)
    }
}
