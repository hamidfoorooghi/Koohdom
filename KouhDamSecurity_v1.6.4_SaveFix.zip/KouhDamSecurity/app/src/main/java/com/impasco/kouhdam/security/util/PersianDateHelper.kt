package com.impasco.kouhdam.security.util

import java.util.Calendar

/**
 * Persian (Jalali / Shamsi) date helper + Persian digit formatting.
 */
object PersianDateHelper {

    val persianMonths = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    private val westernDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    data class JalaliDate(val year: Int, val month: Int, val day: Int) {
        /** Storage: 1403/08/18 */
        fun toFormatted(): String = "%04d/%02d/%02d".format(year, month, day)

        /** Display Persian digits: ۱۴۰۳/۰۸/۱۸ */
        fun toPersianFormatted(): String = toPersianDigits(toFormatted())

        /** ۱۸ آبان ۱۴۰۳ */
        fun toDisplay(): String =
            toPersianDigits("$day ${persianMonths[(month - 1).coerceIn(0, 11)]} $year")
    }

    fun todayJalali(): JalaliDate = toJalali(Calendar.getInstance())

    fun toJalali(cal: Calendar): JalaliDate {
        return gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Calendar {
        val g = jalaliToGregorianRaw(jy, jm, jd)
        return Calendar.getInstance().apply { set(g[0], g[1] - 1, g[2]) }
    }

    fun parseJalali(dateStr: String): JalaliDate? {
        val normalized = toWesternDigits(dateStr.trim())
        val parts = normalized.split("/", "-", ".")
        if (parts.size != 3) return null
        return try {
            JalaliDate(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
        } catch (_: Exception) {
            null
        }
    }

    fun daysInMonth(year: Int, month: Int): Int = when {
        month in 1..6 -> 31
        month in 7..11 -> 30
        month == 12 -> if (isLeapJalali(year)) 30 else 29
        else -> 30
    }

    /** 33-year Jalali leap cycle */
    fun isLeapJalali(year: Int): Boolean {
        val mod = year % 33
        return mod in listOf(1, 5, 9, 13, 17, 22, 26, 30)
    }

    fun toPersianDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            val idx = westernDigits.indexOf(c)
            sb.append(if (idx >= 0) persianDigits[idx] else c)
        }
        return sb.toString()
    }

    fun toWesternDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            val idx = persianDigits.indexOf(c)
            sb.append(if (idx >= 0) westernDigits[idx] else c)
        }
        return sb.toString()
    }

    fun formatTimePersian(hour: Int, minute: Int): String =
        toPersianDigits("%02d:%02d".format(hour, minute))

    fun parseTime(text: String): Pair<Int, Int>? {
        val n = toWesternDigits(text.trim())
        val parts = n.split(":")
        if (parts.size != 2) return null
        return try {
            parts[0].toInt() to parts[1].toInt()
        } catch (_: Exception) {
            null
        }
    }

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): JalaliDate {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy2 = gy
        if (gm > 2) gy2++
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
            ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return JalaliDate(jy, jm, jd)
    }

    private fun jalaliToGregorianRaw(jy: Int, jm: Int, jd: Int): IntArray {
        var jy2 = jy + 1595
        var days = -355668 + (365 * jy2) + ((jy2 / 33) * 8) + (((jy2 % 33) + 3) / 4) + jd +
            if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            gy += 100 * (--days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val salA = intArrayOf(
            0, 31,
            if ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) 29 else 28,
            31, 30, 31, 30, 31, 31, 30, 31, 30, 31
        )
        var gm = 0
        while (gm < 13 && gd > salA[gm]) {
            gd -= salA[gm]
            gm++
        }
        return intArrayOf(gy, gm, gd)
    }
}
