package com.impasco.kouhdam.security.util

import android.content.Context
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/**
 * Persian-aware pickers:
 * - Shamsi (Jalali) date calendar with Persian digits
 * - Time with Persian digits
 * - Iranian national plate with Persian digits
 */
object UiPickers {

    val PLATE_LETTERS = arrayOf(
        "الف", "ب", "پ", "ت", "ث", "ج", "د", "ر", "ز",
        "س", "ش", "ص", "ط", "ع", "ف", "ق", "ک", "گ",
        "ل", "م", "ن", "و", "ه", "ی"
    )

    // -------------------- Date (Shamsi) --------------------

    fun attachDatePicker(context: Context, editText: EditText) {
        editText.isFocusable = false
        editText.isClickable = true
        editText.setOnClickListener {
            showPersianDatePicker(context, editText.text?.toString().orEmpty()) { jalali ->
                editText.setText(jalali.toPersianFormatted())
            }
        }
    }

    fun showPersianDatePicker(
        context: Context,
        initial: String = "",
        onSelected: (PersianDateHelper.JalaliDate) -> Unit
    ) {
        val today = PersianDateHelper.todayJalali()
        val current = PersianDateHelper.parseJalali(initial) ?: today

        val yearMin = today.year - 10
        val yearMax = today.year + 5

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 20), dp(context, 16), dp(context, 20), dp(context, 8))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val preview = TextView(context).apply {
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(context, 12))
            text = current.toDisplay()
        }
        root.addView(preview)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        // Day picker
        val dayPicker = NumberPicker(context).apply {
            minValue = 1
            maxValue = PersianDateHelper.daysInMonth(current.year, current.month)
            value = current.day.coerceIn(1, maxValue)
            displayedValues = persianNumberLabels(1, maxValue)
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 72), LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // Month picker (Persian names)
        val monthPicker = NumberPicker(context).apply {
            minValue = 1
            maxValue = 12
            value = current.month.coerceIn(1, 12)
            displayedValues = PersianDateHelper.persianMonths
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 130), LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // Year picker (Persian digits)
        val yearPicker = NumberPicker(context).apply {
            minValue = yearMin
            maxValue = yearMax
            value = current.year.coerceIn(yearMin, yearMax)
            displayedValues = (yearMin..yearMax).map { PersianDateHelper.toPersianDigits(it.toString()) }.toTypedArray()
            wrapSelectorWheel = false
            layoutParams = LinearLayout.LayoutParams(dp(context, 100), LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        fun refreshDayRange() {
            val y = yearPicker.value
            val m = monthPicker.value
            val max = PersianDateHelper.daysInMonth(y, m)
            val old = dayPicker.value
            dayPicker.displayedValues = null
            dayPicker.minValue = 1
            dayPicker.maxValue = max
            dayPicker.displayedValues = persianNumberLabels(1, max)
            dayPicker.value = old.coerceIn(1, max)
            preview.text = PersianDateHelper.JalaliDate(y, m, dayPicker.value).toDisplay()
        }

        dayPicker.setOnValueChangedListener { _, _, _ ->
            preview.text = PersianDateHelper.JalaliDate(
                yearPicker.value, monthPicker.value, dayPicker.value
            ).toDisplay()
        }
        monthPicker.setOnValueChangedListener { _, _, _ -> refreshDayRange() }
        yearPicker.setOnValueChangedListener { _, _, _ -> refreshDayRange() }

        // RTL visual: year | month | day
        row.addView(yearPicker)
        row.addView(monthPicker)
        row.addView(dayPicker)
        root.addView(row)

        val hint = TextView(context).apply {
            text = "تقویم شمسی — با اسکرول انتخاب کنید"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(context, 10), 0, 0)
        }
        root.addView(hint)

        AlertDialog.Builder(context)
            .setTitle("انتخاب تاریخ شمسی")
            .setView(root)
            .setPositiveButton("تأیید") { _, _ ->
                onSelected(
                    PersianDateHelper.JalaliDate(
                        yearPicker.value,
                        monthPicker.value,
                        dayPicker.value
                    )
                )
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // -------------------- Time --------------------

    fun attachTimePicker(context: Context, editText: EditText) {
        editText.isFocusable = false
        editText.isClickable = true
        editText.setOnClickListener {
            showPersianTimePicker(context, editText.text?.toString().orEmpty()) { h, m ->
                editText.setText(PersianDateHelper.formatTimePersian(h, m))
            }
        }
    }

    fun showPersianTimePicker(
        context: Context,
        initial: String = "",
        onSelected: (hour: Int, minute: Int) -> Unit
    ) {
        val parsed = PersianDateHelper.parseTime(initial)
        val hour0 = parsed?.first ?: 8
        val min0 = parsed?.second ?: 0

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 20), dp(context, 16), dp(context, 20), dp(context, 8))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val preview = TextView(context).apply {
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            text = PersianDateHelper.formatTimePersian(hour0, min0)
            setPadding(0, 0, 0, dp(context, 12))
        }
        root.addView(preview)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val hourPicker = NumberPicker(context).apply {
            minValue = 0
            maxValue = 23
            value = hour0.coerceIn(0, 23)
            displayedValues = persianNumberLabels(0, 23, pad = 2)
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 90), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val colon = TextView(context).apply {
            text = " : "
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val minutePicker = NumberPicker(context).apply {
            minValue = 0
            maxValue = 59
            value = min0.coerceIn(0, 59)
            displayedValues = persianNumberLabels(0, 59, pad = 2)
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 90), LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        fun refresh() {
            preview.text = PersianDateHelper.formatTimePersian(hourPicker.value, minutePicker.value)
        }
        hourPicker.setOnValueChangedListener { _, _, _ -> refresh() }
        minutePicker.setOnValueChangedListener { _, _, _ -> refresh() }

        // RTL-friendly: minute : hour  (optional); keep hour : minute for clarity
        row.addView(hourPicker)
        row.addView(colon)
        row.addView(minutePicker)
        root.addView(row)

        val hint = TextView(context).apply {
            text = "ساعت — دقیقه"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(context, 10), 0, 0)
        }
        root.addView(hint)

        AlertDialog.Builder(context)
            .setTitle("انتخاب ساعت")
            .setView(root)
            .setPositiveButton("تأیید") { _, _ ->
                onSelected(hourPicker.value, minutePicker.value)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // -------------------- Plate --------------------

    fun attachPlatePicker(context: Context, editText: EditText) {
        editText.isFocusable = false
        editText.isClickable = true
        editText.setOnClickListener {
            showIranianPlatePicker(context, editText.text?.toString().orEmpty()) { plate ->
                editText.setText(plate)
            }
        }
    }

    fun showIranianPlatePicker(
        context: Context,
        initial: String = "",
        onSelected: (String) -> Unit
    ) {
        val parsed = parsePlate(initial)

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 16), dp(context, 16), dp(context, 16), dp(context, 8))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val preview = TextView(context).apply {
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(context, 14))
            text = formatPlatePersian(parsed[0], parsed[1], parsed[2], parsed[3])
        }
        root.addView(preview)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val p1 = NumberPicker(context).apply {
            minValue = 1
            maxValue = 99
            value = parsed[0].toIntOrNull()?.coerceIn(1, 99) ?: 12
            displayedValues = persianNumberLabels(1, 99, pad = 2)
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 72), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val letterIdx = PLATE_LETTERS.indexOf(parsed[1]).let { if (it >= 0) it else PLATE_LETTERS.indexOf("ب").coerceAtLeast(0) }
        val pLetter = NumberPicker(context).apply {
            minValue = 0
            maxValue = PLATE_LETTERS.size - 1
            displayedValues = PLATE_LETTERS
            value = letterIdx
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 90), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val p2 = NumberPicker(context).apply {
            minValue = 1
            maxValue = 999
            value = parsed[2].toIntOrNull()?.coerceIn(1, 999) ?: 345
            displayedValues = persianNumberLabels(1, 999, pad = 3)
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 90), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val pRegion = NumberPicker(context).apply {
            minValue = 1
            maxValue = 99
            value = parsed[3].toIntOrNull()?.coerceIn(1, 99) ?: 11
            displayedValues = persianNumberLabels(1, 99, pad = 2)
            wrapSelectorWheel = true
            layoutParams = LinearLayout.LayoutParams(dp(context, 72), LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        fun refresh() {
            preview.text = formatPlatePersian(
                "%02d".format(p1.value),
                PLATE_LETTERS[pLetter.value],
                "%03d".format(p2.value),
                "%02d".format(pRegion.value)
            )
        }
        p1.setOnValueChangedListener { _, _, _ -> refresh() }
        pLetter.setOnValueChangedListener { _, _, _ -> refresh() }
        p2.setOnValueChangedListener { _, _, _ -> refresh() }
        pRegion.setOnValueChangedListener { _, _, _ -> refresh() }
        refresh()

        val bar = TextView(context).apply { text = "  |  "; textSize = 18f; gravity = Gravity.CENTER }

        // Visual like real plate (RTL): region | three letter two
        row.addView(pRegion)
        row.addView(bar)
        row.addView(p2)
        row.addView(pLetter)
        row.addView(p1)
        root.addView(row)

        val hint = TextView(context).apply {
            text = "پلاک ملی ایران — اعداد فارسی"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(context, 10), 0, 0)
        }
        root.addView(hint)

        AlertDialog.Builder(context)
            .setTitle("انتخاب پلاک خودرو")
            .setView(root)
            .setPositiveButton("تأیید") { _, _ ->
                val stored = storePlate(
                    "%02d".format(p1.value),
                    PLATE_LETTERS[pLetter.value],
                    "%03d".format(p2.value),
                    "%02d".format(pRegion.value)
                )
                // Show value also in Persian digits in the field
                onSelected(formatPlatePersian(
                    "%02d".format(p1.value),
                    PLATE_LETTERS[pLetter.value],
                    "%03d".format(p2.value),
                    "%02d".format(pRegion.value)
                ))
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    /** Display: ۱۲ ب ۳۴۵ | ۱۱ */
    fun formatPlatePersian(two: String, letter: String, three: String, region: String): String {
        return PersianDateHelper.toPersianDigits("$two $letter $three | $region")
    }

    fun storePlate(two: String, letter: String, three: String, region: String): String =
        "$two$letter$three-$region"

    fun parsePlate(raw: String): Array<String> {
        val cleaned = PersianDateHelper.toWesternDigits(raw.trim())
            .replace(" ", "")
            .replace("|", "-")
        val regex = Regex("""^(\d{1,2})([\u0600-\u06FF]+)(\d{1,3})-?(\d{0,2})$""")
        val m = regex.find(cleaned)
        if (m != null) {
            return arrayOf(
                m.groupValues[1].padStart(2, '0'),
                m.groupValues[2],
                m.groupValues[3].padStart(3, '0'),
                m.groupValues[4].ifBlank { "11" }.padStart(2, '0')
            )
        }
        return arrayOf("12", "ب", "345", "11")
    }

    // -------------------- helpers --------------------

    private fun persianNumberLabels(from: Int, to: Int, pad: Int = 0): Array<String> {
        return (from..to).map {
            val s = if (pad > 0) "%0${pad}d".format(it) else it.toString()
            PersianDateHelper.toPersianDigits(s)
        }.toTypedArray()
    }

    private fun dp(context: Context, value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
