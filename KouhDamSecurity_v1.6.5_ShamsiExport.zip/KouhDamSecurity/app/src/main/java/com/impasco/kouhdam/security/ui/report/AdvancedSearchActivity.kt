package com.impasco.kouhdam.security.ui.report

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.impasco.kouhdam.security.SecurityApp
import com.impasco.kouhdam.security.data.entity.Report
import com.impasco.kouhdam.security.databinding.ActivityAdvancedSearchBinding
import com.impasco.kouhdam.security.databinding.ItemReportBinding
import com.impasco.kouhdam.security.util.PersianDateHelper
import com.impasco.kouhdam.security.util.UiPickers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class AdvancedSearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdvancedSearchBinding
    private val app by lazy { application as SecurityApp }
    private lateinit var adapter: SearchAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdvancedSearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = SearchAdapter { report ->
            startActivity(Intent(this, ReportDetailActivity::class.java).apply {
                putExtra("report_id", report.id)
            })
        }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.etDateFrom.isFocusable = false
        binding.etDateFrom.isClickable = true
        binding.etDateFrom.setOnClickListener { showDatePicker(true) }
        binding.etDateTo.isFocusable = false
        binding.etDateTo.isClickable = true
        binding.etDateTo.setOnClickListener { showDatePicker(false) }

        binding.btnSearch.setOnClickListener { doSearch() }
        binding.btnClear.setOnClickListener { clearFilters() }
    }

    private fun showDatePicker(isFrom: Boolean) {
        val current = if (isFrom) binding.etDateFrom.text?.toString().orEmpty()
                      else binding.etDateTo.text?.toString().orEmpty()
        UiPickers.showPersianDatePicker(this, current) { jalali ->
            val formatted = jalali.toPersianFormatted()
            if (isFrom) binding.etDateFrom.setText(formatted)
            else binding.etDateTo.setText(formatted)
        }
    }

    private fun clearFilters() {
        binding.etDateFrom.text?.clear()
        binding.etDateTo.text?.clear()
        binding.etShiftLeader.text?.clear()
        binding.etReporter.text?.clear()
        binding.etShiftNumber.text?.clear()
        binding.etPersonnel.text?.clear()
        binding.etPlate.text?.clear()
        binding.etGoldVisitor.text?.clear()
        binding.etKeyword.text?.clear()
        adapter.submit(emptyList())
        binding.tvResultCount.visibility = View.GONE
        binding.tvEmpty.visibility = View.GONE
    }

    private fun doSearch() {
        fun textOrNull(et: android.widget.EditText): String? =
            et.text?.toString()?.trim()?.ifBlank { null }

        fun dateOrNull(et: android.widget.EditText): String? {
            val raw = et.text?.toString()?.trim().orEmpty()
            if (raw.isBlank()) return null
            return PersianDateHelper.parseJalali(raw)?.toFormatted()
                ?: PersianDateHelper.toWesternDigits(raw)
        }

        val dateFrom = dateOrNull(binding.etDateFrom)
        val dateTo = dateOrNull(binding.etDateTo)
        val leader = textOrNull(binding.etShiftLeader)
        val reporter = textOrNull(binding.etReporter)
        val shiftNum = textOrNull(binding.etShiftNumber)
        val personnel = textOrNull(binding.etPersonnel)
        val plate = textOrNull(binding.etPlate)
        val gold = textOrNull(binding.etGoldVisitor)
        val keyword = textOrNull(binding.etKeyword)

        val userId = if (app.sessionManager.isAdmin()) null else app.sessionManager.getUserId()

        binding.btnSearch.isEnabled = false

        lifecycleScope.launch {
            val results = withContext(Dispatchers.IO) {
                app.database.reportDao().searchReports(
                    dateFrom, dateTo, leader, reporter, shiftNum,
                    personnel, plate, gold, keyword, userId
                )
            }
            binding.btnSearch.isEnabled = true
            adapter.submit(results)
            binding.tvResultCount.visibility = View.VISIBLE
            binding.tvResultCount.text = "${results.size} نتیجه یافت شد"
            binding.tvEmpty.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE

            if (results.isEmpty()) {
                Toast.makeText(this@AdvancedSearchActivity, "نتیجه‌ای یافت نشد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private class SearchAdapter(
        private val onClick: (Report) -> Unit
    ) : RecyclerView.Adapter<SearchAdapter.VH>() {

        private val items = mutableListOf<Report>()

        fun submit(list: List<Report>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemReportBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(b)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val r = items[position]
            holder.b.tvDate.text = r.reportDate
            holder.b.tvShift.text = "شیفت ${r.shiftNumber}  |  ${r.shiftStart} - ${r.shiftEnd}"
            holder.b.tvLeader.text = "سرشیفت: ${r.shiftLeader}  |  ثبت‌کننده: ${r.reporterName}"
            holder.b.tvStatus.text = if (r.status == "FINAL") "نهایی" else "پیش‌نویس"
            holder.b.tvStatus.setBackgroundColor(
                if (r.status == "FINAL") 0xFF1565C0.toInt() else 0xFFF9A825.toInt()
            )
            holder.itemView.setOnClickListener { onClick(r) }
        }

        override fun getItemCount() = items.size
        class VH(val b: ItemReportBinding) : RecyclerView.ViewHolder(b.root)
    }
}
