package com.impasco.kouhdam.security.util

import android.content.Context
import android.os.Environment
import com.impasco.kouhdam.security.data.entity.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Generates a real multi-sheet .xlsx Excel file (Office Open XML)
 * without external dependencies. Suitable for Persian text.
 */
class PersianExcelExporter(private val context: Context) {

    data class ReportBundle(
        val report: Report,
        val personnel: List<Personnel>,
        val vehicles: List<Vehicle>,
        val goldRoom: List<GoldRoomMovement>,
        val blasting: List<BlastingMaterial>,
        val events: List<Event>
    )

    fun export(bundle: ReportBundle): File {
        val safeDate = bundle.report.reportDate.replace("/", "-").replace(" ", "_")
        val safeShift = bundle.report.shiftNumber.replace(" ", "_")
        val ext = "xlsx"
        val fileName = "report_${safeDate}_shift${safeShift}." + ext
        val dir = context.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, fileName)

        val sheets = buildSheets(bundle)

        ZipOutputStream(FileOutputStream(file)).use { zip ->
            // [Content_Types].xml
            zip.putNextEntry(ZipEntry("[Content_Types].xml"))
            zip.write(contentTypesXml(sheets.size).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // _rels/.rels
            zip.putNextEntry(ZipEntry("_rels/.rels"))
            zip.write(relsXml().toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // xl/workbook.xml
            zip.putNextEntry(ZipEntry("xl/workbook.xml"))
            zip.write(workbookXml(sheets.map { it.first }).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // xl/_rels/workbook.xml.rels
            zip.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
            zip.write(workbookRelsXml(sheets.size).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // xl/styles.xml
            zip.putNextEntry(ZipEntry("xl/styles.xml"))
            zip.write(stylesXml().toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // xl/sharedStrings.xml
            val allStrings = linkedSetOf<String>()
            sheets.forEach { (_, rows) ->
                rows.forEach { row -> row.forEach { allStrings.add(it) } }
            }
            val stringList = allStrings.toList()
            val stringIndex = stringList.withIndex().associate { (i, s) -> s to i }

            zip.putNextEntry(ZipEntry("xl/sharedStrings.xml"))
            zip.write(sharedStringsXml(stringList).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // worksheets
            sheets.forEachIndexed { index, (_, rows) ->
                zip.putNextEntry(ZipEntry("xl/worksheets/sheet${index + 1}.xml"))
                zip.write(sheetXml(rows, stringIndex).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
        return file
    }

    private fun buildSheets(b: ReportBundle): List<Pair<String, List<List<String>>>> {
        val r = b.report
        val sheets = mutableListOf<Pair<String, List<List<String>>>>()

        // Sheet 1: خلاصه گزارش
        sheets += "خلاصه گزارش" to listOf(
            listOf("عنوان", "مقدار"),
            listOf("سازمان", "شرکت تهیه و تولید مواد معدنی ایران (IMPASCO)"),
            listOf("محل", "مجتمع طلای کوه‌دم"),
            listOf("تاریخ گزارش", r.reportDate),
            listOf("شماره شیفت", r.shiftNumber),
            listOf("ساعت شروع", r.shiftStart),
            listOf("ساعت پایان", r.shiftEnd),
            listOf("سرشیفت", r.shiftLeader),
            listOf("ثبت‌کننده", r.reporterName),
            listOf("وضعیت", if (r.status == "FINAL") "نهایی" else "پیش‌نویس"),
            listOf("تعداد پرسنل", b.personnel.size.toString()),
            listOf("تعداد خودرو", b.vehicles.size.toString()),
            listOf("تعداد تردد اتاق طلا", b.goldRoom.size.toString()),
            listOf("تعداد رویداد", b.events.size.toString())
        )

        // Sheet 2: پرسنل
        val personnelRows = mutableListOf(
            listOf("نام و نام خانوادگی", "وضعیت", "ساعت حضور", "ساعت خروج", "جایگزین", "توضیحات")
        )
        b.personnel.forEach { p ->
            personnelRows += listOf(
                p.fullName,
                p.presenceStatus,
                p.timeIn.orEmpty(),
                p.timeOut.orEmpty(),
                p.replacementName.orEmpty(),
                p.notes.orEmpty()
            )
        }
        if (personnelRows.size == 1) personnelRows += listOf("-", "-", "-", "-", "-", "-")
        sheets += "پرسنل" to personnelRows

        // Sheet 3: خودروها
        val vehicleRows = mutableListOf(
            listOf("پلاک", "نوع خودرو", "راننده", "سرنشینان", "علت ورود", "ساعت ورود", "ساعت خروج", "توضیحات")
        )
        b.vehicles.forEach { v ->
            vehicleRows += listOf(
                v.plateNumber, v.vehicleType, v.driverName,
                v.passengers.orEmpty(), v.reason.orEmpty(),
                v.timeIn.orEmpty(), v.timeOut.orEmpty(), v.notes.orEmpty()
            )
        }
        if (vehicleRows.size == 1) vehicleRows += listOf("-", "-", "-", "-", "-", "-", "-", "-")
        sheets += "خودروها" to vehicleRows

        // Sheet 4: اتاق طلا
        val goldRows = mutableListOf(
            listOf("نام مراجعه‌کننده", "سمت/واحد", "علت", "ساعت ورود", "ساعت خروج", "همراهان", "مسئول", "توضیحات")
        )
        b.goldRoom.forEach { g ->
            goldRows += listOf(
                g.visitorName, g.positionOrUnit.orEmpty(), g.reason.orEmpty(),
                g.timeIn.orEmpty(), g.timeOut.orEmpty(),
                g.companions.orEmpty(), g.responsiblePerson.orEmpty(), g.notes.orEmpty()
            )
        }
        if (goldRows.size == 1) goldRows += listOf("-", "-", "-", "-", "-", "-", "-", "-")
        sheets += "اتاق طلا" to goldRows

        // Sheet 5: آتشباری
        val blastRows = mutableListOf(
            listOf("تعداد خودرو", "پلاک‌ها", "شماره حواله", "ساعت ورود", "ساعت خروج", "تحویل‌دهنده", "توضیحات")
        )
        b.blasting.forEach { bl ->
            blastRows += listOf(
                bl.vehicleCount.orEmpty(), bl.plates.orEmpty(), bl.receiptNumber.orEmpty(),
                bl.timeIn.orEmpty(), bl.timeOut.orEmpty(),
                bl.delivererInfo.orEmpty(), bl.notes.orEmpty()
            )
        }
        if (blastRows.size == 1) blastRows += listOf("-", "-", "-", "-", "-", "-", "-")
        sheets += "آتشباری" to blastRows

        // Sheet 6: سوخت
        sheets += "سوخت" to listOf(
            listOf("عنوان", "مقدار"),
            listOf("کیلومتر خودرو", r.vehicleKm.orEmpty()),
            listOf("سوخت خودرو (لیتر)", r.vehicleFuelLiters.orEmpty()),
            listOf("کیلومتر موتورسیکلت", r.motorcycleKm.orEmpty()),
            listOf("سوخت موتورسیکلت", r.motorcycleFuelLiters.orEmpty()),
            listOf("موجودی سوخت انبار", r.fuelStock.orEmpty()),
            listOf("توضیحات", r.fuelNotes.orEmpty())
        )

        // Sheet 7: کلیدها
        sheets += "کلیدها" to listOf(
            listOf("عنوان", "مقدار"),
            listOf("کلید اتاق طلا", r.goldRoomKeysStatus.orEmpty()),
            listOf("سایر کلیدها", r.otherKeysStatus.orEmpty()),
            listOf("تحویل‌دهنده", r.keysDeliveredBy.orEmpty()),
            listOf("تحویل‌گیرنده", r.keysReceivedBy.orEmpty()),
            listOf("ساعت تحویل", r.keysTime.orEmpty()),
            listOf("توضیحات", r.keysNotes.orEmpty())
        )

        // Sheet 8: سلامت و نظافت
        sheets += "سلامت و نظافت" to listOf(
            listOf("عنوان", "مقدار"),
            listOf("وضعیت بهداشت", r.healthStatus.orEmpty()),
            listOf("مشاهدات بهداشتی", r.healthObservations.orEmpty()),
            listOf("مشکلات بهداشتی", r.healthProblems.orEmpty()),
            listOf("نظافت اتاق‌ها", r.roomsCleaning.orEmpty()),
            listOf("نظافت محیط", r.areaCleaning.orEmpty()),
            listOf("وضعیت ساختمان", r.buildingStatus.orEmpty()),
            listOf("مشکلات تأسیساتی", r.facilityProblems.orEmpty()),
            listOf("نیازهای ساختمانی", r.buildingNeeds.orEmpty())
        )

        // Sheet 9: رویدادها
        val eventRows = mutableListOf(
            listOf("شرح رویداد", "تاریخ/ساعت", "محل", "افراد مرتبط", "اقدامات", "نتیجه")
        )
        b.events.forEach { e ->
            eventRows += listOf(
                e.description, e.eventDateTime.orEmpty(), e.location.orEmpty(),
                e.relatedPeople.orEmpty(), e.actionsTaken.orEmpty(), e.result.orEmpty()
            )
        }
        if (eventRows.size == 1) eventRows += listOf("-", "-", "-", "-", "-", "-")
        sheets += "رویدادها" to eventRows

        // Sheet 10: تحویل شیفت
        sheets += "تحویل شیفت" to listOf(
            listOf("عنوان", "مقدار"),
            listOf("تحویل‌دهنده", r.handoverFrom.orEmpty()),
            listOf("تحویل‌گیرنده", r.handoverTo.orEmpty()),
            listOf("ساعت تحویل", r.handoverTime.orEmpty()),
            listOf("وضعیت کلی شیفت", r.overallShiftStatus.orEmpty()),
            listOf("توضیحات نهایی", r.finalNotes.orEmpty())
        )

        return sheets
    }

    // ---- XML builders ----

    private fun xmlEscape(s: String): String =
        s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")

    private fun contentTypesXml(sheetCount: Int): String {
        val sheets = (1..sheetCount).joinToString("") {
            """<Override PartName="/xl/worksheets/sheet$it.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
$sheets
</Types>"""
    }

    private fun relsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private fun workbookXml(names: List<String>): String {
        val sheets = names.mapIndexed { i, name ->
            """<sheet name="${xmlEscape(name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>"""
        }.joinToString("")
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>$sheets</sheets>
</workbook>"""
    }

    private fun workbookRelsXml(count: Int): String {
        val rels = (1..count).joinToString("") {
            """<Relationship Id="rId$it" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$it.xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
$rels
<Relationship Id="rId${count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
<Relationship Id="rId${count + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>"""
    }

    private fun stylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
</fonts>
<fills count="2">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
</fills>
<borders count="1"><border/></borders>
<cellStyleXfs count="1"><xf/></cellStyleXfs>
<cellXfs count="2">
<xf xfId="0"/>
<xf fontId="1" xfId="0" applyFont="1"/>
</cellXfs>
</styleSheet>"""

    private fun sharedStringsXml(strings: List<String>): String {
        val items = strings.joinToString("") {
            "<si><t>${xmlEscape(it)}</t></si>"
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${strings.size}" uniqueCount="${strings.size}">
$items
</sst>"""
    }

    private fun sheetXml(rows: List<List<String>>, stringIndex: Map<String, Int>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sb.append("<sheetData>")
        rows.forEachIndexed { rowIdx, cols ->
            val r = rowIdx + 1
            sb.append("""<row r="$r">""")
            cols.forEachIndexed { colIdx, value ->
                val col = colName(colIdx)
                val idx = stringIndex[value] ?: 0
                val style = if (rowIdx == 0) """ s="1"""" else ""
                sb.append("""<c r="$col$r" t="s"$style><v>$idx</v></c>""")
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun colName(index: Int): String {
        var i = index
        var name = ""
        while (i >= 0) {
            name = ('A' + i % 26) + name
            i = i / 26 - 1
        }
        return name
    }
}
