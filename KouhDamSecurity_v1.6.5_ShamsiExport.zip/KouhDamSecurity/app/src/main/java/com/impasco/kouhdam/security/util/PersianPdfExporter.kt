package com.impasco.kouhdam.security.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.pdf.PdfDocument
import android.os.Environment
import com.impasco.kouhdam.security.data.entity.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Generates a formal Persian (RTL) PDF report for a security shift report.
 */
class PersianPdfExporter(private val context: Context) {

    private val pageWidth = 595  // A4
    private val pageHeight = 842
    private val margin = 40f
    private val contentWidth = pageWidth - 2 * margin

    private val titlePaint = Paint().apply {
        color = Color.rgb(16, 29, 50)
        textSize = 16f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    private val headerPaint = Paint().apply {
        color = Color.rgb(16, 29, 50)
        textSize = 13f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
        textAlign = Paint.Align.RIGHT
    }

    private val bodyPaint = Paint().apply {
        color = Color.rgb(30, 30, 30)
        textSize = 11f
        typeface = Typeface.DEFAULT
        isAntiAlias = true
        textAlign = Paint.Align.RIGHT
    }

    private val smallPaint = Paint().apply {
        color = Color.rgb(90, 90, 90)
        textSize = 9f
        typeface = Typeface.DEFAULT
        isAntiAlias = true
        textAlign = Paint.Align.RIGHT
    }

    private val linePaint = Paint().apply {
        color = Color.rgb(198, 154, 67)
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
    }

    private val thinLine = Paint().apply {
        color = Color.rgb(200, 200, 200)
        strokeWidth = 0.8f
        style = Paint.Style.STROKE
    }

    data class ReportBundle(
        val report: Report,
        val personnel: List<Personnel>,
        val vehicles: List<Vehicle>,
        val goldRoom: List<GoldRoomMovement>,
        val blasting: List<BlastingMaterial>,
        val events: List<Event>
    )

    fun export(bundle: ReportBundle): File {
        val doc = PdfDocument()
        var pageNum = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
        var page = doc.startPage(pageInfo)
        var canvas = page.canvas
        var y = margin

        fun newPage(): Float {
            doc.finishPage(page)
            pageNum++
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
            page = doc.startPage(pageInfo)
            canvas = page.canvas
            return margin + 10f
        }

        fun ensureSpace(needed: Float): Float {
            if (y + needed > pageHeight - margin - 30) {
                // footer
                drawFooter(canvas, pageNum)
                y = newPage()
            }
            return y
        }

        // ===== Header =====
        y = drawHeader(canvas, y, bundle.report)
        y += 8f
        canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
        y += 16f

        // ===== Shift Info =====
        y = ensureSpace(80f)
        y = drawSectionTitle(canvas, y, "اطلاعات شیفت")
        y = drawKeyValue(canvas, y, "تاریخ گزارش", bundle.report.reportDate)
        y = drawKeyValue(canvas, y, "شماره شیفت", bundle.report.shiftNumber)
        y = drawKeyValue(canvas, y, "ساعت شیفت", "${bundle.report.shiftStart} تا ${bundle.report.shiftEnd}")
        y = drawKeyValue(canvas, y, "سرشیفت", bundle.report.shiftLeader)
        y = drawKeyValue(canvas, y, "ثبت‌کننده", bundle.report.reporterName)
        y = drawKeyValue(canvas, y, "وضعیت", if (bundle.report.status == "FINAL") "نهایی" else "پیش‌نویس")
        y += 10f

        // ===== Personnel =====
        if (bundle.personnel.isNotEmpty()) {
            y = ensureSpace(40f + bundle.personnel.size * 16f)
            y = drawSectionTitle(canvas, y, "وضعیت پرسنل (${bundle.personnel.size} نفر)")
            bundle.personnel.forEach { p ->
                y = ensureSpace(18f)
                val status = when (p.presenceStatus.uppercase()) {
                    "PRESENT", "حاضر" -> "حاضر"
                    "ABSENT", "غایب" -> "غایب"
                    else -> p.presenceStatus
                }
                val line = "${p.fullName}  |  $status  |  ${p.timeIn.orEmpty()} - ${p.timeOut.orEmpty()}"
                y = drawBodyLine(canvas, y, line)
            }
            y += 8f
        }

        // ===== Vehicles =====
        if (bundle.vehicles.isNotEmpty()) {
            y = ensureSpace(40f + bundle.vehicles.size * 18f)
            y = drawSectionTitle(canvas, y, "تردد خودروها (${bundle.vehicles.size})")
            bundle.vehicles.forEach { v ->
                y = ensureSpace(20f)
                y = drawBodyLine(canvas, y, "پلاک: ${v.plateNumber}  |  ${v.vehicleType}  |  راننده: ${v.driverName}")
                y = drawBodyLine(canvas, y, "  سرنشینان: ${v.passengers.orEmpty()} | علت: ${v.reason.orEmpty()} | ورود: ${v.timeIn.orEmpty()} - خروج: ${v.timeOut.orEmpty()}", small = true)
                if (!v.notes.isNullOrBlank()) y = drawBodyLine(canvas, y, "  توضیحات: ${v.notes}", small = true)
            }
            y += 8f
        }

        // ===== Gold Room =====
        if (bundle.goldRoom.isNotEmpty()) {
            y = ensureSpace(40f + bundle.goldRoom.size * 20f)
            y = drawSectionTitle(canvas, y, "تردد اتاق طلا (${bundle.goldRoom.size})")
            bundle.goldRoom.forEach { g ->
                y = ensureSpace(22f)
                y = drawBodyLine(canvas, y, "${g.visitorName}  |  ${g.positionOrUnit.orEmpty()}")
                y = drawBodyLine(canvas, y, "  علت: ${g.reason.orEmpty()} | ورود: ${g.timeIn.orEmpty()} - خروج: ${g.timeOut.orEmpty()}", small = true)
                y = drawBodyLine(canvas, y, "  همراهان: ${g.companions.orEmpty()} | مسئول: ${g.responsiblePerson.orEmpty()} | توضیحات: ${g.notes.orEmpty()}", small = true)
            }
            y += 8f
        }

        // ===== Blasting =====
        if (bundle.blasting.isNotEmpty()) {
            y = ensureSpace(40f)
            y = drawSectionTitle(canvas, y, "مواد آتشباری")
            bundle.blasting.forEach { b ->
                y = ensureSpace(20f)
                y = drawBodyLine(canvas, y, "حواله: ${b.receiptNumber.orEmpty()}  |  پلاک: ${b.plates.orEmpty()}")
                y = drawBodyLine(canvas, y, "  تعداد خودرو: ${b.vehicleCount.orEmpty()} | ${b.timeIn.orEmpty()} - ${b.timeOut.orEmpty()} | ${b.delivererInfo.orEmpty()}", small = true)
                if (!b.notes.isNullOrBlank()) y = drawBodyLine(canvas, y, "  توضیحات: ${b.notes}", small = true)
            }
            y += 8f
        }

        // ===== Fuel =====
        y = ensureSpace(70f)
        y = drawSectionTitle(canvas, y, "سوخت و کیلومتر")
        y = drawKeyValue(canvas, y, "کیلومتر خودرو", bundle.report.vehicleKm.orEmpty())
        y = drawKeyValue(canvas, y, "سوخت خودرو (لیتر)", bundle.report.vehicleFuelLiters.orEmpty())
        y = drawKeyValue(canvas, y, "کیلومتر موتور", bundle.report.motorcycleKm.orEmpty())
        y = drawKeyValue(canvas, y, "سوخت موتور (لیتر)", bundle.report.motorcycleFuelLiters.orEmpty())
        y = drawKeyValue(canvas, y, "موجودی سوخت انبار", bundle.report.fuelStock.orEmpty())
        if (!bundle.report.fuelNotes.isNullOrBlank()) {
            y = drawKeyValue(canvas, y, "توضیحات", bundle.report.fuelNotes.orEmpty())
        }
        y += 8f

        // ===== Keys =====
        y = ensureSpace(70f)
        y = drawSectionTitle(canvas, y, "کلیدها")
        y = drawKeyValue(canvas, y, "کلید اتاق طلا", bundle.report.goldRoomKeysStatus.orEmpty())
        y = drawKeyValue(canvas, y, "سایر کلیدها", bundle.report.otherKeysStatus.orEmpty())
        y = drawKeyValue(canvas, y, "تحویل‌دهنده", bundle.report.keysDeliveredBy.orEmpty())
        y = drawKeyValue(canvas, y, "تحویل‌گیرنده", bundle.report.keysReceivedBy.orEmpty())
        y = drawKeyValue(canvas, y, "ساعت تحویل", bundle.report.keysTime.orEmpty())
        y = drawKeyValue(canvas, y, "توضیحات کلیدها", bundle.report.keysNotes.orEmpty())
        y += 8f

        // ===== Health =====
        y = ensureSpace(50f)
        y = drawSectionTitle(canvas, y, "بهداشت و سلامت")
        y = drawKeyValue(canvas, y, "وضعیت", bundle.report.healthStatus.orEmpty())
        y = drawKeyValue(canvas, y, "مشاهدات", bundle.report.healthObservations.orEmpty())
        y = drawKeyValue(canvas, y, "مشکلات", bundle.report.healthProblems.orEmpty())
        y = drawKeyValue(canvas, y, "توضیحات", bundle.report.healthNotes.orEmpty())
        y += 8f

        // ===== Cleaning =====
        y = ensureSpace(60f)
        y = drawSectionTitle(canvas, y, "نظافت و وضعیت ساختمان")
        y = drawKeyValue(canvas, y, "اتاق‌ها", bundle.report.roomsCleaning.orEmpty())
        y = drawKeyValue(canvas, y, "محیط", bundle.report.areaCleaning.orEmpty())
        y = drawKeyValue(canvas, y, "ساختمان", bundle.report.buildingStatus.orEmpty())
        y = drawKeyValue(canvas, y, "تأسیسات", bundle.report.facilityProblems.orEmpty())
        y = drawKeyValue(canvas, y, "نیازهای ساختمان", bundle.report.buildingNeeds.orEmpty())
        y = drawKeyValue(canvas, y, "توضیحات نظافت", bundle.report.cleaningNotes.orEmpty())
        y += 8f

        // ===== Events =====
        if (bundle.events.isNotEmpty()) {
            y = ensureSpace(40f + bundle.events.size * 24f)
            y = drawSectionTitle(canvas, y, "رویدادهای مهم (${bundle.events.size})")
            bundle.events.forEach { e ->
                y = ensureSpace(28f)
                y = drawBodyLine(canvas, y, e.description)
                val meta = listOfNotNull(
                    e.eventDateTime?.takeIf { it.isNotBlank() },
                    e.location?.takeIf { it.isNotBlank() }
                ).joinToString(" | ")
                if (meta.isNotBlank()) y = drawBodyLine(canvas, y, "  $meta", small = true)
                if (!e.relatedPeople.isNullOrBlank()) y = drawBodyLine(canvas, y, "  افراد مرتبط: ${e.relatedPeople}", small = true)
                if (!e.actionsTaken.isNullOrBlank()) y = drawBodyLine(canvas, y, "  اقدامات: ${e.actionsTaken}", small = true)
                if (!e.result.isNullOrBlank()) y = drawBodyLine(canvas, y, "  نتیجه: ${e.result}", small = true)
            }
            y += 8f
        }

        // ===== Handover =====
        y = ensureSpace(70f)
        y = drawSectionTitle(canvas, y, "تحویل شیفت")
        y = drawKeyValue(canvas, y, "تحویل‌دهنده", bundle.report.handoverFrom.orEmpty())
        y = drawKeyValue(canvas, y, "تحویل‌گیرنده", bundle.report.handoverTo.orEmpty())
        y = drawKeyValue(canvas, y, "ساعت تحویل", bundle.report.handoverTime.orEmpty())
        y = drawKeyValue(canvas, y, "وضعیت کلی شیفت", bundle.report.overallShiftStatus.orEmpty())
        y = drawKeyValue(canvas, y, "توضیحات نهایی", bundle.report.finalNotes.orEmpty())
        y += 24f

        // Signature area
        y = ensureSpace(60f)
        y = drawSectionTitle(canvas, y, "امضا")
        y += 8f
        val sigY = y + 30f
        canvas.drawLine(margin + 20, sigY, margin + 180, sigY, thinLine)
        canvas.drawLine(pageWidth - margin - 180, sigY, pageWidth - margin - 20, sigY, thinLine)
        bodyPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("تحویل‌دهنده", margin + 100, sigY + 14, bodyPaint)
        canvas.drawText("تحویل‌گیرنده", pageWidth - margin - 100f, sigY + 14, bodyPaint)
        bodyPaint.textAlign = Paint.Align.RIGHT

        drawFooter(canvas, pageNum)
        doc.finishPage(page)

        // Save file
        val safeDate = bundle.report.reportDate.replace("/", "-").replace(" ", "_")
        val safeShift = bundle.report.shiftNumber.replace(" ", "_")
        val ext = "pdf"
        val fileName = "report_${safeDate}_shift${safeShift}." + ext
        val dir = context.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, fileName)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun drawHeader(canvas: Canvas, startY: Float, report: Report): Float {
        var y = startY
        try {
            val logo = BitmapFactory.decodeResource(context.resources, com.impasco.kouhdam.security.R.drawable.logo_impasco)
            if (logo != null) {
                val scaled = Bitmap.createScaledBitmap(logo, 58, 58, true)
                canvas.drawBitmap(scaled, pageWidth - margin - 58f, y - 4f, Paint(Paint.ANTI_ALIAS_FLAG))
                if (scaled !== logo) scaled.recycle()
                logo.recycle()
            }
        } catch (_: Exception) { /* continue with text-only heading if the logo cannot be decoded */ }
        titlePaint.textSize = 14f
        canvas.drawText("شرکت تهیه و تولید مواد معدنی ایران (IMPASCO)", pageWidth / 2f, y + 14, titlePaint)
        y += 20f
        titlePaint.textSize = 15f
        canvas.drawText("مجتمع طلای کوه‌دم", pageWidth / 2f, y + 14, titlePaint)
        y += 22f
        titlePaint.textSize = 13f
        canvas.drawText("گزارش روزانه حفاظت فیزیکی", pageWidth / 2f, y + 12, titlePaint)
        y += 18f
        smallPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("تاریخ گزارش: ${report.reportDate}  |  شیفت: ${report.shiftNumber}", pageWidth / 2f, y + 10, smallPaint)
        smallPaint.textAlign = Paint.Align.RIGHT
        return y + 14f
    }

    private fun drawSectionTitle(canvas: Canvas, y: Float, title: String): Float {
        headerPaint.textSize = 12f
        canvas.drawText(title, pageWidth - margin, y + 12, headerPaint)
        canvas.drawLine(margin, y + 16, pageWidth - margin, y + 16, linePaint)
        return y + 26f
    }

    private fun drawKeyValue(canvas: Canvas, y: Float, key: String, value: String): Float {
        if (value.isBlank()) return y
        val text = "$key:  $value"
        return drawBodyLine(canvas, y, text)
    }

    private fun drawBodyLine(canvas: Canvas, y: Float, text: String, small: Boolean = false): Float {
        val paint = if (small) smallPaint else bodyPaint
        // Simple wrap for long lines
        val maxWidth = contentWidth - 10
        if (paint.measureText(text) <= maxWidth) {
            canvas.drawText(text, pageWidth - margin, y + paint.textSize, paint)
            return y + paint.textSize + 6f
        }
        // Basic wrap
        var remaining = text
        var cy = y
        while (remaining.isNotEmpty()) {
            var end = remaining.length
            while (end > 0 && paint.measureText(remaining.substring(0, end)) > maxWidth) end--
            if (end == 0) end = 1
            val chunk = remaining.substring(0, end)
            canvas.drawText(chunk, pageWidth - margin, cy + paint.textSize, paint)
            cy += paint.textSize + 4f
            remaining = remaining.substring(end).trimStart()
        }
        return cy + 2f
    }

    private fun drawFooter(canvas: Canvas, pageNum: Int) {
        val footerY = pageHeight - 22f
        canvas.drawLine(margin, footerY - 8, pageWidth - margin, footerY - 8, thinLine)
        smallPaint.textAlign = Paint.Align.CENTER
        val now = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date())
        canvas.drawText("صفحه $pageNum  |  سامانه گزارش حفاظت فیزیکی کوه‌دم  |  $now", pageWidth / 2f, footerY, smallPaint)
        smallPaint.textAlign = Paint.Align.RIGHT
    }
}
