package com.impasco.kouhdam.security.util

import android.content.Context
import android.os.Environment
import com.impasco.kouhdam.security.data.entity.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Generates a real .docx Word file (Office Open XML) with Persian RTL content.
 * No external dependencies.
 */
class PersianWordExporter(private val context: Context) {

    data class ReportBundle(
        val report: Report,
        val personnel: List<Personnel>,
        val vehicles: List<Vehicle>,
        val goldRoom: List<GoldRoomMovement>,
        val blasting: List<BlastingMaterial>,
        val events: List<Event>
    )

    fun export(bundle: ReportBundle): File {
        val safeDate = bundle.report.reportDate.replace("/", "-").replace(" ", "_")
        val safeShift = bundle.report.shiftNumber.replace(" ", "_")
        val ext = "docx"
        val fileName = "report_${safeDate}_shift${safeShift}." + ext
        val dir = context.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, fileName)

        val bodyXml = buildDocumentBody(bundle)

        ZipOutputStream(FileOutputStream(file)).use { zip ->
            zip.putNextEntry(ZipEntry("[Content_Types].xml"))
            zip.write(CONTENT_TYPES.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("_rels/.rels"))
            zip.write(RELS.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("word/_rels/document.xml.rels"))
            zip.write(DOC_RELS.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("word/styles.xml"))
            zip.write(STYLES.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("word/document.xml"))
            zip.write(bodyXml.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        return file
    }

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("\"", "&quot;").replace("'", "&apos;")

    private fun p(text: String, bold: Boolean = false, center: Boolean = false, size: Int = 22): String {
        val bTag = if (bold) "<w:b/>" else ""
        val align = if (center) """<w:jc w:val="center"/>""" else """<w:jc w:val="right"/>"""
        return """
<w:p>
  <w:pPr>
    <w:bidi/>
    $align
    <w:spacing w:after="80"/>
  </w:pPr>
  <w:r>
    <w:rPr>
      $bTag
      <w:sz w:val="$size"/>
      <w:szCs w:val="$size"/>
      <w:rtl/>
    </w:rPr>
    <w:t xml:space="preserve">${esc(text)}</w:t>
  </w:r>
</w:p>"""
    }

    private fun heading(text: String): String = p(text, bold = true, size = 26)

    private fun kv(key: String, value: String): String {
        if (value.isBlank()) return ""
        return p("$key: $value")
    }

    private fun spacer(): String = """<w:p><w:pPr><w:spacing w:after="60"/></w:pPr></w:p>"""

    private fun buildDocumentBody(b: ReportBundle): String {
        val r = b.report
        val sb = StringBuilder()

        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<w:body>
""")

        // Header
        sb.append(p("شرکت تهیه و تولید مواد معدنی ایران (IMPASCO)", bold = true, center = true, size = 28))
        sb.append(p("مجتمع طلای کوه‌دم", bold = true, center = true, size = 26))
        sb.append(p("گزارش روزانه حفاظت فیزیکی", bold = true, center = true, size = 24))
        sb.append(p("تاریخ: ${r.reportDate}  |  شیفت: ${r.shiftNumber}", center = true, size = 20))
        sb.append(spacer())

        // Shift
        sb.append(heading("۱. اطلاعات شیفت"))
        sb.append(kv("تاریخ گزارش", r.reportDate))
        sb.append(kv("شماره شیفت", r.shiftNumber))
        sb.append(kv("ساعت شیفت", "${r.shiftStart} تا ${r.shiftEnd}"))
        sb.append(kv("سرشیفت", r.shiftLeader))
        sb.append(kv("ثبت‌کننده", r.reporterName))
        sb.append(kv("وضعیت", if (r.status == "FINAL") "نهایی" else "پیش‌نویس"))
        sb.append(spacer())

        // Personnel
        if (b.personnel.isNotEmpty()) {
            sb.append(heading("۲. وضعیت پرسنل (${b.personnel.size} نفر)"))
            b.personnel.forEachIndexed { i, p ->
                val status = when (p.presenceStatus.uppercase()) {
                    "PRESENT", "حاضر" -> "حاضر"
                    "ABSENT", "غایب" -> "غایب"
                    else -> p.presenceStatus
                }
                sb.append(p("${i + 1}. ${p.fullName} — $status — ${p.timeIn.orEmpty()} تا ${p.timeOut.orEmpty()}"))
                if (!p.replacementName.isNullOrBlank()) sb.append(p("   جایگزین: ${p.replacementName}"))
                if (!p.notes.isNullOrBlank()) sb.append(p("   توضیحات: ${p.notes}"))
            }
            sb.append(spacer())
        }

        // Vehicles
        if (b.vehicles.isNotEmpty()) {
            sb.append(heading("۳. تردد خودروها (${b.vehicles.size})"))
            b.vehicles.forEachIndexed { i, v ->
                sb.append(p("${i + 1}. پلاک ${v.plateNumber} | ${v.vehicleType} | راننده: ${v.driverName}"))
                if (!v.reason.isNullOrBlank() || !v.timeIn.isNullOrBlank()) {
                    sb.append(p("   سرنشینان: ${v.passengers.orEmpty()} | علت: ${v.reason.orEmpty()} | ${v.timeIn.orEmpty()} - ${v.timeOut.orEmpty()}"))
                }
                if (!v.notes.isNullOrBlank()) sb.append(p("   توضیحات: ${v.notes}"))
            }
            sb.append(spacer())
        }

        // Gold Room
        if (b.goldRoom.isNotEmpty()) {
            sb.append(heading("۴. تردد اتاق طلا (${b.goldRoom.size})"))
            b.goldRoom.forEachIndexed { i, g ->
                sb.append(p("${i + 1}. ${g.visitorName} | ${g.positionOrUnit.orEmpty()}"))
                sb.append(p("   علت: ${g.reason.orEmpty()} | ${g.timeIn.orEmpty()} - ${g.timeOut.orEmpty()}"))
                if (!g.responsiblePerson.isNullOrBlank()) sb.append(p("   مسئول: ${g.responsiblePerson}"))
                if (!g.companions.isNullOrBlank()) sb.append(p("   همراهان: ${g.companions}"))
                if (!g.notes.isNullOrBlank()) sb.append(p("   توضیحات: ${g.notes}"))
            }
            sb.append(spacer())
        }

        // Blasting
        if (b.blasting.isNotEmpty()) {
            sb.append(heading("۵. مواد آتشباری"))
            b.blasting.forEachIndexed { i, bl ->
                sb.append(p("${i + 1}. حواله: ${bl.receiptNumber.orEmpty()} | پلاک: ${bl.plates.orEmpty()}"))
                sb.append(p("   تعداد خودرو: ${bl.vehicleCount.orEmpty()} | ${bl.timeIn.orEmpty()} - ${bl.timeOut.orEmpty()} | ${bl.delivererInfo.orEmpty()}"))
                if (!bl.notes.isNullOrBlank()) sb.append(p("   توضیحات: ${bl.notes}"))
            }
            sb.append(spacer())
        }

        // Fuel
        sb.append(heading("۶. سوخت و کیلومتر"))
        sb.append(kv("کیلومتر خودرو", r.vehicleKm.orEmpty()))
        sb.append(kv("سوخت خودرو (لیتر)", r.vehicleFuelLiters.orEmpty()))
        sb.append(kv("کیلومتر موتور", r.motorcycleKm.orEmpty()))
        sb.append(kv("سوخت موتور (لیتر)", r.motorcycleFuelLiters.orEmpty()))
        sb.append(kv("سوخت موتور (لیتر)", r.motorcycleFuelLiters.orEmpty()))
        sb.append(kv("موجودی سوخت انبار", r.fuelStock.orEmpty()))
        sb.append(kv("توضیحات", r.fuelNotes.orEmpty()))
        sb.append(spacer())

        // Keys
        sb.append(heading("۷. کلیدها"))
        sb.append(kv("کلید اتاق طلا", r.goldRoomKeysStatus.orEmpty()))
        sb.append(kv("سایر کلیدها", r.otherKeysStatus.orEmpty()))
        sb.append(kv("تحویل‌دهنده", r.keysDeliveredBy.orEmpty()))
        sb.append(kv("تحویل‌گیرنده", r.keysReceivedBy.orEmpty()))
        sb.append(kv("ساعت تحویل", r.keysTime.orEmpty()))
        sb.append(kv("توضیحات کلیدها", r.keysNotes.orEmpty()))
        sb.append(spacer())

        // Health
        sb.append(heading("۸. بهداشت و سلامت"))
        sb.append(kv("وضعیت", r.healthStatus.orEmpty()))
        sb.append(kv("مشاهدات", r.healthObservations.orEmpty()))
        sb.append(kv("مشکلات", r.healthProblems.orEmpty()))
        sb.append(kv("توضیحات", r.healthNotes.orEmpty()))
        sb.append(spacer())

        // Cleaning
        sb.append(heading("۹. نظافت و وضعیت ساختمان"))
        sb.append(kv("اتاق‌ها", r.roomsCleaning.orEmpty()))
        sb.append(kv("محیط", r.areaCleaning.orEmpty()))
        sb.append(kv("ساختمان", r.buildingStatus.orEmpty()))
        sb.append(kv("تأسیسات", r.facilityProblems.orEmpty()))
        sb.append(kv("نیازها", r.buildingNeeds.orEmpty()))
        sb.append(kv("توضیحات نظافت", r.cleaningNotes.orEmpty()))
        sb.append(spacer())

        // Events
        if (b.events.isNotEmpty()) {
            sb.append(heading("۱۰. رویدادهای مهم (${b.events.size})"))
            b.events.forEachIndexed { i, e ->
                sb.append(p("${i + 1}. ${e.description}", bold = true))
                if (!e.eventDateTime.isNullOrBlank() || !e.location.isNullOrBlank()) {
                    sb.append(p("   ${e.eventDateTime.orEmpty()} | ${e.location.orEmpty()}"))
                }
                if (!e.relatedPeople.isNullOrBlank()) sb.append(p("   افراد مرتبط: ${e.relatedPeople}"))
                if (!e.actionsTaken.isNullOrBlank()) sb.append(p("   اقدامات: ${e.actionsTaken}"))
                if (!e.result.isNullOrBlank()) sb.append(p("   نتیجه: ${e.result}"))
            }
            sb.append(spacer())
        }

        // Handover
        sb.append(heading("۱۱. تحویل شیفت"))
        sb.append(kv("تحویل‌دهنده", r.handoverFrom.orEmpty()))
        sb.append(kv("تحویل‌گیرنده", r.handoverTo.orEmpty()))
        sb.append(kv("ساعت تحویل", r.handoverTime.orEmpty()))
        sb.append(kv("وضعیت کلی شیفت", r.overallShiftStatus.orEmpty()))
        sb.append(kv("توضیحات نهایی", r.finalNotes.orEmpty()))
        sb.append(spacer())
        sb.append(spacer())

        // Signature
        sb.append(heading("امضا"))
        sb.append(p("تحویل‌دهنده: ........................        تحویل‌گیرنده: ........................"))
        sb.append(spacer())
        sb.append(p("سامانه گزارش حفاظت فیزیکی کوه‌دم", center = true, size = 18))

        sb.append("""
<w:sectPr>
  <w:pgSz w:w="11906" w:h="16838"/>
  <w:pgMar w:top="720" w:right="720" w:bottom="720" w:left="720"/>
  <w:bidi/>
</w:sectPr>
</w:body>
</w:document>""")

        return sb.toString()
    }

    companion object {
        private val CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

        private val RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

        private val DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        private val STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:style w:type="paragraph" w:default="1" w:styleId="Normal">
  <w:name w:val="Normal"/>
  <w:qFormat/>
  <w:pPr><w:bidi/></w:pPr>
  <w:rPr><w:rFonts w:ascii="Tahoma" w:cs="Tahoma"/><w:lang w:bidi="fa-IR"/></w:rPr>
</w:style>
</w:styles>"""
    }
}
